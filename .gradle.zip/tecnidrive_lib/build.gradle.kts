plugins {
}

    android {
    namespace = "com.presentacion.tecnidrive_lib"

    defaultConfig {
    minSdk = 24

      testInstrumentationRunner = "android.support.test.runner.AndroidJUnitRunner"
    }

    }

  dependencies {
  }