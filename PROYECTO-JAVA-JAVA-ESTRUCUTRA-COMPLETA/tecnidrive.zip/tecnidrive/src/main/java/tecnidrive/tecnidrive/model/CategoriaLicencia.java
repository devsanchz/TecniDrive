package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "categoria_licencia")
public class CategoriaLicencia {

    // Sin @GeneratedValue: igual que en Rol, los IDs ya vienen definidos
    // a mano (1='A1', 2='A2', etc.), no se generan automáticamente
    @Id
    @Column(name = "id_categoria")
    private Integer idCategoria;

    @Column(name = "tipo_categoria", length = 3, nullable = false)
    private String tipoCategoria;
}