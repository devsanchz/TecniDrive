package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "servicio_vehiculo")
public class ServicioVehiculo {

    @Id
    @Column(name = "id_tipo_servicio")
    private Integer idTipoServicio;

    @Column(name = "texto_servicio", length = 20, nullable = false)
    private String textoServicio;
}