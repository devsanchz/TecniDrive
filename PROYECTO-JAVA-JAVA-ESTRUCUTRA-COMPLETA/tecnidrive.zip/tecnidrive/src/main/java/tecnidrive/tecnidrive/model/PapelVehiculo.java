package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "papeles_vehiculo")
public class PapelVehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_papel")
    private Integer idPapel;

    @Column(name = "fecha_vencimiento", nullable = false)
    private LocalDate fechaVencimiento;

    @Column(name = "estado_papel", nullable = false)
    private Boolean estadoPapel;

    // ¿Qué tipo de documento es? (SOAT o Tecnomecánica)
    @ManyToOne
    @JoinColumn(name = "tipo_documento_id_documento", nullable = false)
    private TipoDocumento tipoDocumento;

    // ¿De qué vehículo es este papel?
    @ManyToOne
    @JoinColumn(name = "vehiculo_placa", nullable = false)
    private Vehiculo vehiculo;
}