package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "modelos")
public class Modelo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_modelo")
    private Integer idModelo;

    @Column(name = "nombre_modelo", length = 28, nullable = false)
    private String nombreModelo;

    // @ManyToOne: muchos modelos pueden pertenecer a la misma marca.
    // @JoinColumn le dice a JPA qué columna de ESTA tabla (modelos)
    // guarda la referencia hacia la tabla marcas
    @ManyToOne
    @JoinColumn(name = "marcas_id_marca", nullable = false)
    private Marca marca;
}