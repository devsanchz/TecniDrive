package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "calificacion_taller")
public class CalificacionTaller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_calificacion")
    private Integer idCalificacion;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "puntuacion", nullable = false)
    private Integer puntuacion;

    @Column(name = "comentario", columnDefinition = "TEXT")
    private String comentario;

    // @Enumerated(EnumType.STRING): le dice a Hibernate que guarde el
    // enum como texto ('pendiente', 'aprobada', etc.), no como número.
    // Sin STRING, por defecto Hibernate guardaría 0, 1, 2 — lo cual
    // no coincidiría con tu columna ENUM de MySQL
    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false)
    private EstadoCalificacion estado;

    @ManyToOne
    @JoinColumn(name = "taller_id_taller", nullable = false)
    private Taller taller;

    @ManyToOne
    @JoinColumn(name = "propietarios_id_propietario", nullable = false)
    private Propietario propietario;
}
