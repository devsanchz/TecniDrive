package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

// El segundo parámetro genérico es String, porque la llave primaria
// de Vehiculo es la placa (no un Integer como en el resto de tus modelos)
public interface VehiculoRepository extends JpaRepository<Vehiculo, String> {

    // Query method: necesario para el CRUD real, cuando un propietario
    // quiera ver únicamente SUS vehículos, no los de todos
    List<Vehiculo> findByPropietario_IdPersona(Integer idPersona);
}