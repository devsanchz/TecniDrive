package tecnidrive.tecnidrive.model;

// Representa: ENUM('en_atencion','en_cierre','finalizada')
public enum EstadoMantenimiento {
    en_atencion,
    en_cierre,
    finalizada
}