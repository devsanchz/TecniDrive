package tecnidrive.tecnidrive.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
@Embeddable
public class CitaHasServicioId implements Serializable {

    @Column(name = "cita_taller_id_cita")
    private Integer idCita;

    @Column(name = "taller_id_taller")
    private Integer idTaller;

    @Column(name = "servicios_id_servicio")
    private Integer idServicio;
}