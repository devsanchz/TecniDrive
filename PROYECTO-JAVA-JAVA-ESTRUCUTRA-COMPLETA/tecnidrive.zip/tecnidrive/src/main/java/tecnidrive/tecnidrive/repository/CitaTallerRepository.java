package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CitaTaller;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitaTallerRepository extends JpaRepository<CitaTaller, Integer> {

    // Para "mis citas" del propietario, a través de su vehículo
    List<CitaTaller> findByVehiculo_Propietario_IdPersona(Integer idPersona);

    // Para la agenda del taller (mecánico)
    List<CitaTaller> findByTaller_IdTaller(Integer idTaller);
}
