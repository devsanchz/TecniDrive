package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "categoria_has_propietario")
public class CategoriaHasPropietario {

    // @EmbeddedId: en vez de un @Id simple, usamos la clase que agrupa
    // las dos llaves foráneas como si fueran una sola "super llave"
    @EmbeddedId
    private CategoriaHasPropietarioId id;

    @Column(name = "vigencia_lice", nullable = false)
    private LocalDate vigenciaLice;

    @Column(name = "estado_lice", nullable = false)
    private Boolean estadoLice;
}