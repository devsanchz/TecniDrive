package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "cita_taller")
public class CitaTaller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cita")
    private Integer idCita;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "fecha_cita", nullable = false)
    private LocalDateTime fechaCita;

    @Column(name = "problema_contexto", length = 255)
    private String problemaContexto;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado_cita", nullable = false)
    private EstadoCita estadoCita;

    @Column(name = "codigo_confirmacion", length = 10, unique = true)
    private String codigoConfirmacion;

    @Column(name = "fecha_inicio_atencion")
    private LocalDate fechaInicioAtencion;

    // Nullable por naturaleza: solo tiene valor si la cita fue cancelada
    @Enumerated(EnumType.STRING)
    @Column(name = "cancelado_por")
    private CanceladoPor canceladoPor;

    @Column(name = "motivo_cancelacion", length = 100)
    private String motivoCancelacion;

    @ManyToOne
    @JoinColumn(name = "taller_id_taller", nullable = false)
    private Taller taller;

    // La relación funciona igual sin importar que la PK de Vehiculo
    // sea un String (la placa) en vez de un Integer
    @ManyToOne
    @JoinColumn(name = "vehiculo_placa", nullable = false)
    private Vehiculo vehiculo;
}