package tecnidrive.tecnidrive.model;

// Representa exactamente los 3 valores del ENUM en MySQL:
// ENUM('pendiente','aprobada','rechazada')
public enum EstadoCalificacion {
    pendiente,
    aprobada,
    rechazada
}