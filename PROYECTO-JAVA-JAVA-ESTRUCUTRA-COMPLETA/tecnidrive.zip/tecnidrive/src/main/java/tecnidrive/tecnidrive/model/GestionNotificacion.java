package tecnidrive.tecnidrive.model;

public class GestionNotificacion {

}
