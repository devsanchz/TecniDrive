package tecnidrive.tecnidrive.repository;

//👹Mi parte
import tecnidrive.tecnidrive.model.Rol;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RolRepository extends JpaRepository<Rol, Integer> {
}