package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "tipos_vehiculo")
public class TipoVehiculo {

    @Id
    @Column(name = "id_tipo_vehi")
    private Integer idTipoVehi;

    @Column(name = "texto_tipo_vehi", length = 20, nullable = false)
    private String textoTipoVehi;
}