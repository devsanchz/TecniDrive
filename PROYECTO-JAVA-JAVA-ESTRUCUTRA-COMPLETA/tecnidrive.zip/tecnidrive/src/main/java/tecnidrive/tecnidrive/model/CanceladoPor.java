package tecnidrive.tecnidrive.model;

// Representa: ENUM('propietario', 'mecanico')
public enum CanceladoPor {
    propietario,
    mecanico
}
