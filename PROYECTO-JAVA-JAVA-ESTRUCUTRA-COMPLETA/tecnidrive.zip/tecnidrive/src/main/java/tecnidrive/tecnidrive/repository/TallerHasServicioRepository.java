package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.TallerHasServicio;
import tecnidrive.tecnidrive.model.TallerHasServicioId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TallerHasServicioRepository extends JpaRepository<TallerHasServicio, TallerHasServicioId> {

    // Para listar todos los servicios (con su precio) que ofrece un taller específico
    List<TallerHasServicio> findById_IdTaller(Integer idTaller);
}