package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "taller")
public class Taller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_taller")
    private Integer idTaller;

    @Column(name = "foto_taller", length = 255)
    private String fotoTaller;

    @Column(name = "nombre_taller", length = 80, nullable = false)
    private String nombreTaller;

    @Column(name = "descripcion_taller", length = 150, nullable = false)
    private String descripcionTaller;

    @Column(name = "direccion_taller", length = 80, nullable = false)
    private String direccionTaller;

    @Column(name = "horario_taller", length = 150, nullable = false)
    private String horarioTaller;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "estado_taller", nullable = false)
    private Boolean estadoTaller;

    @Column(name = "motivo_estado", length = 100)
    private String motivoEstado;

    @ManyToOne
    @JoinColumn(name = "mecanicos_id_mecanico", nullable = false)
    private Mecanico mecanico;

    // AGREGADO: relación con Especialidad, igual patrón que Persona-Rol.
    // Como taller_especialidad NO tiene columnas propias (solo las 2 FK),
    // se resuelve con @ManyToMany simple, sin necesidad de @EmbeddedId
    @ManyToMany
    @JoinTable(
        name = "taller_especialidad",
        joinColumns = @JoinColumn(name = "taller_id_taller"),
        inverseJoinColumns = @JoinColumn(name = "especialidades_id_especialidad")
    )
    private Set<Especialidad> especialidades;
}