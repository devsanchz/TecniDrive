package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CitaHasServicio;
import tecnidrive.tecnidrive.model.CitaHasServicioId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitaHasServicioRepository extends JpaRepository<CitaHasServicio, CitaHasServicioId> {

    // Para saber qué servicios eligió una cita específica
    List<CitaHasServicio> findById_IdCita(Integer idCita);
}