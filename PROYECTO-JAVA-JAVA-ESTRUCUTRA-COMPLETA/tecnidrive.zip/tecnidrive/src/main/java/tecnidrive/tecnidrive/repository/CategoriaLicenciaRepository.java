package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CategoriaLicencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaLicenciaRepository extends JpaRepository<CategoriaLicencia, Integer> {
}