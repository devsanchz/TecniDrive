package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CalificacionTaller;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CalificacionTallerRepository extends JpaRepository<CalificacionTaller, Integer> {

    // Para mostrar todas las calificaciones de un taller específico
    List<CalificacionTaller> findByTaller_IdTaller(Integer idTaller);
}