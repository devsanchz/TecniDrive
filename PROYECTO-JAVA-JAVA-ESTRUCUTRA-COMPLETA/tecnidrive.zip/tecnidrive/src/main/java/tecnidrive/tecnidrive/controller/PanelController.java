package tecnidrive.tecnidrive.controller;

import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.service.MecanicoService;
import tecnidrive.tecnidrive.service.PersonaService;
import tecnidrive.tecnidrive.service.PropietarioService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PanelController {

    @Autowired
    private PersonaService personaService;

    @Autowired
    private PropietarioService propietarioService;

    @Autowired
    private MecanicoService mecanicoService;

    @GetMapping("/panel-admin")
    public String panelAdmin(HttpSession session, Model model) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Persona persona = personaService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(persona));
        model.addAttribute("rolTexto", session.getAttribute("rol"));
        model.addAttribute("email", persona.getEmail());
        model.addAttribute("avatarColor", persona.getAvatarColor());

        // CORRECCIÓN: ahora los HTML viven en subcarpetas por rol dentro de templates/
        return "admin/panel-admin";
    }

    @GetMapping("/panel-propietario")
    public String panelPropietario(HttpSession session, Model model) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Propietario propietario = propietarioService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(propietario));
        model.addAttribute("rolTexto", session.getAttribute("rol"));
        model.addAttribute("email", propietario.getEmail());
        model.addAttribute("avatarColor", propietario.getAvatarColor());
        model.addAttribute("telefono", propietario.getTelefonoPropietario());

        return "propietario/panel-propietario";
    }

    @GetMapping("/panel-mecanico")
    public String panelMecanico(HttpSession session, Model model) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Mecanico mecanico = mecanicoService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(mecanico));
        model.addAttribute("rolTexto", session.getAttribute("rol"));
        model.addAttribute("email", mecanico.getEmail());
        model.addAttribute("avatarColor", mecanico.getAvatarColor());
        model.addAttribute("telefono", mecanico.getTelefonoMecanico());

        return "mecanico/panel-mecanico";
    }

    private String construirNombreCompleto(Persona persona) {
        String nombre = persona.getPrimerNombre();
        if (persona.getSegundoNombre() != null && !persona.getSegundoNombre().isBlank()) {
            nombre += " " + persona.getSegundoNombre();
        }
        nombre += " " + persona.getPrimerApellido() + " " + persona.getSegundoApellido();
        return nombre;
    }
}