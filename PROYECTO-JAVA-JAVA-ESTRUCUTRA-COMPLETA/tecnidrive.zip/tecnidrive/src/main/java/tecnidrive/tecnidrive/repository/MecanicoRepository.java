package tecnidrive.tecnidrive.repository;

//👹Mi parte
import tecnidrive.tecnidrive.model.Mecanico;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MecanicoRepository extends JpaRepository<Mecanico, Integer> {
}
