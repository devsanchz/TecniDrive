package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.TipoVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoVehiculoRepository extends JpaRepository<TipoVehiculo, Integer> {
}
