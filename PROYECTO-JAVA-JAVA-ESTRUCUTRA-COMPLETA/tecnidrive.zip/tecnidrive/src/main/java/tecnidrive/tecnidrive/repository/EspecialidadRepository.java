package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.Especialidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspecialidadRepository extends JpaRepository<Especialidad, Integer> {
}