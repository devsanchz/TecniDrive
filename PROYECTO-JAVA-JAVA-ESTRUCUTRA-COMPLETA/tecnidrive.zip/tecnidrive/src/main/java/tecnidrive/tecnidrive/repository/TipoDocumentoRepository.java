package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.TipoDocumento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoDocumentoRepository extends JpaRepository<TipoDocumento, Integer> {
}