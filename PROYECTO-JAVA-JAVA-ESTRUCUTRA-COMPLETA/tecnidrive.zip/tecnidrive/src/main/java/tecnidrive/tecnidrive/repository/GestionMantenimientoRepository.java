package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.GestionMantenimiento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GestionMantenimientoRepository extends JpaRepository<GestionMantenimiento, Integer> {

    // Para encontrar la ficha de una cita específica
    Optional<GestionMantenimiento> findByCitaTaller_IdCita(Integer idCita);
}