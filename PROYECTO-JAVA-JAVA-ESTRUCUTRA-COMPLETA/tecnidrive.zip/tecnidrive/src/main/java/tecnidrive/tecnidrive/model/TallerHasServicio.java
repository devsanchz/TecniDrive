package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "taller_has_servicios")
public class TallerHasServicio {

    @EmbeddedId
    private TallerHasServicioId id;

    // BigDecimal es el tipo correcto en Java para dinero/decimales exactos,
    // equivalente a DECIMAL(10,2) en MySQL. No usamos double/float aquí
    // porque esos tipos pueden perder precisión con decimales
    @Column(name = "precio_servicio", nullable = false)
    private BigDecimal precioServicio;
}