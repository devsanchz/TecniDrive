package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.repository.PropietarioRepository;

import java.util.List;

@Service
public class PropietarioService {

    // CORRECCIÓN final: cambiamos de inyección por constructor a @Autowired en el
    // campo, para que quede igual al resto del proyecto (mismo criterio que
    // en PersonaService y en los Controllers)
    @Autowired
    private PropietarioRepository propietarioRepository;

    // CORRECCIÓN: renombrado de "listarPropietarios" a "listarTodos" y de // "buscarporId" a "obtenerPorId",
    // solo para que el nombre coincida con // PersonaService y MecanicoService (así cualquier Controller los llama igual)
    public List<Propietario> listarTodos() {
        return propietarioRepository.findAll();
    }

    public Propietario obtenerPorId(Integer id) {
        return propietarioRepository.findById(id).orElse(null);
    }
    //sin encriptación de contraseña por ahora,
    public Propietario guardar(Propietario propietario) {
        return propietarioRepository.save(propietario);
    }



    //no estaba, pero lo necesitamos para que desde el panel 
    // // el propietario pueda editar su email, avatarColor y teléfono
    public Propietario actualizar(Integer id, Propietario datosActualizados) {
        Propietario existente = propietarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Propietario no encontrado"));

        existente.setEmail(datosActualizados.getEmail());
        existente.setAvatarColor(datosActualizados.getAvatarColor());
        existente.setTelefonoPropietario(datosActualizados.getTelefonoPropietario());

        return propietarioRepository.save(existente);
    }
}