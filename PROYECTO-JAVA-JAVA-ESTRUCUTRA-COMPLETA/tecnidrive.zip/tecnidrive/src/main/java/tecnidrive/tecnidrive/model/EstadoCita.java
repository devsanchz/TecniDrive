package tecnidrive.tecnidrive.model;

// Representa: ENUM('pendiente','confirmada','en_atencion','cancelada_propietario','cancelada_mecanico')
public enum EstadoCita {
    pendiente,
    confirmada,
    en_atencion,
    cancelada_propietario,
    cancelada_mecanico
}