package tecnidrive.tecnidrive.model;

import jakarta.persistence.Embeddable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

// @Embeddable: le dice a JPA que esta clase no es una tabla propia,
// sino un "paquete" de columnas que se puede incrustar dentro de otra entidad
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode // Necesario para que Java sepa comparar dos llaves compuestas correctamente
@Embeddable
public class CategoriaHasPropietarioId implements Serializable {

    @jakarta.persistence.Column(name = "categoria_licencia_id_categoria")
    private Integer idCategoria;

    @jakarta.persistence.Column(name = "propietarios_id_propietario")
    private Integer idPropietario;
}