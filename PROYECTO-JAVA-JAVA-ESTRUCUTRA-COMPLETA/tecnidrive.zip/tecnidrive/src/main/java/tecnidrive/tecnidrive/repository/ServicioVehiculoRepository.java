package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.ServicioVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicioVehiculoRepository extends JpaRepository<ServicioVehiculo, Integer> {
}