package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.repository.MecanicoRepository;

import java.util.List;

@Service
public class MecanicoService {

    // CORRECCIÓN: mismo cambio que en los otros dos Services, para
    // mantener consistencia en todo el proyecto
    @Autowired
    private MecanicoRepository mecanicoRepository;

    public List<Mecanico> listarTodos() {
        return mecanicoRepository.findAll();
    }

    public Mecanico obtenerPorId(Integer id) {
        return mecanicoRepository.findById(id).orElse(null);
    }

    public Mecanico guardar(Mecanico mecanico) {
        return mecanicoRepository.save(mecanico);
    }

    public Mecanico actualizar(Integer id, Mecanico datosActualizados) {
        Mecanico existente = mecanicoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Mecánico no encontrado"));

        existente.setEmail(datosActualizados.getEmail());
        existente.setAvatarColor(datosActualizados.getAvatarColor());
        existente.setTelefonoMecanico(datosActualizados.getTelefonoMecanico());

        return mecanicoRepository.save(existente);
    }
}