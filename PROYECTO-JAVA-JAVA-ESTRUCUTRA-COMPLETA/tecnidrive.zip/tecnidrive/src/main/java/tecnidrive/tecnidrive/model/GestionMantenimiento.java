package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "gestion_mantenimiento")
public class GestionMantenimiento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_seguimiento")
    private Integer idSeguimiento;

    @OneToOne
    @JoinColumn(name = "cita_taller_id_cita", nullable = false, unique = true)
    private CitaTaller citaTaller;

    @Column(name = "observaciones_tecnico", columnDefinition = "TEXT")
    private String observacionesTecnico;

    @Column(name = "precio_total")
    private BigDecimal precioTotal;

    @Column(name = "garantia_vigencia")
    private LocalDateTime garantiaVigencia;

    @Column(name = "texto_garantia", columnDefinition = "TEXT")
    private String textoGarantia;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado_mantenimiento", nullable = false)
    private EstadoMantenimiento estadoMantenimiento;

    @Column(name = "codigo_entrega", length = 10, unique = true)
    private String codigoEntrega;

    @Column(name = "fecha_cierre")
    private LocalDate fechaCierre;

    // AGREGADO: qué técnicos participaron en esta gestión de mantenimiento.
    // Sin columnas extra en la tabla intermedia, así que @ManyToMany simple
    @ManyToMany
    @JoinTable(
        name = "mantenimiento_has_tecnico",
        joinColumns = @JoinColumn(name = "gestion_mantenimiento_id_seguimiento"),
        inverseJoinColumns = @JoinColumn(name = "tecnicos_id_tecnico")
    )
    private Set<Tecnico> tecnicos;
}