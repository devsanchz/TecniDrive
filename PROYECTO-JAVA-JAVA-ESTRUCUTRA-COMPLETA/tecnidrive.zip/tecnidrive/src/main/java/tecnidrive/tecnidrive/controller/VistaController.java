package tecnidrive.tecnidrive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class VistaController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    //===============================
    //ENDPOINTS PARA AUTENTIFICAR
    //===============================
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/registro")
    public String registro() {
        return "registro";
    }

    @GetMapping("/rol")
    public String rol() {
        return "rol";
    }

    //===============================
    //ENDPOINTS PARA PROPIETARIO
    //===============================
    // CORRECCIÓN: ahora viven dentro de templates/propietario/,
    // para mantener el proyecto organizado por rol
    @GetMapping("/propietario/vehiculo")
    public String propietarioVehiculo() {
        return "propietario/propietario-vehiculo";
    }

    @GetMapping("/propietario/taller")
    public String propietarioTaller() {
        return "propietario/propietario-taller";
    }

    @GetMapping("/propietario/cita")
    public String propietarioCita() {
        return "propietario/propietario-cita";
    }

    //===============================
    //ENDPOINTS PARA MECANICO
    //===============================
    @GetMapping("/mecanico/taller")
    public String mecanicoTaller() {
        return "mecanico/mecanico-taller";
    }

    @GetMapping("/mecanico/cita")
    public String mecanicoCita() {
        return "mecanico/mecanico-cita";
    }

    @GetMapping("/mecanico/control")
    public String mecanicoControl() {
        return "mecanico/mecanico-control";
    }
}
