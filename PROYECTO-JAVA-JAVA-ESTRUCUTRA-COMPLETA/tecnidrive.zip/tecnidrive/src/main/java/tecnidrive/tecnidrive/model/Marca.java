package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "marcas")
public class Marca {

    // Con @GeneratedValue: a diferencia de los catálogos fijos anteriores,
    // las marcas se pueden ir agregando con el tiempo, por eso sí autoincrementa
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_marca")
    private Integer idMarca;

    @Column(name = "nombre_marca", length = 25, nullable = false)
    private String nombreMarca;
}
