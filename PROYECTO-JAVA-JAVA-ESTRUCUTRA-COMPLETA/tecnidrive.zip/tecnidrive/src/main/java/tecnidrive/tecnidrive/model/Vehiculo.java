package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "vehiculo")
public class Vehiculo {

    // Llave primaria natural: la placa, no un número autogenerado.
    // Por eso NO lleva @GeneratedValue, el valor lo define quien registra el vehículo
    @Id
    @Column(name = "placa", length = 6)
    private String placa;

    @Column(name = "model_year", length = 4, nullable = false)
    private String modelYear;

    // Igual que en Persona: la fecha la genera MySQL con DEFAULT CURRENT_TIMESTAMP,
    // insertable = false le dice a Hibernate que no la mande en el INSERT
    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "estado_vehi", nullable = false)
    private Boolean estadoVehi;

    @Column(name = "motivo_estado", length = 100)
    private String motivoEstado;

    // ¿De quién es el vehículo?
    @ManyToOne
    @JoinColumn(name = "propietarios_id_propietario", nullable = false)
    private Propietario propietario;

    // ¿Carro o moto?
    @ManyToOne
    @JoinColumn(name = "tipos_vehiculo_id_tipo_vehi", nullable = false)
    private TipoVehiculo tipoVehiculo;

    // ¿Qué modelo (Corolla, Spark, etc.)?
    @ManyToOne
    @JoinColumn(name = "modelos_id_modelo", nullable = false)
    private Modelo modelo;

    // ¿Particular o público?
    @ManyToOne
    @JoinColumn(name = "servicio_vehiculo_id_tipo_servicio", nullable = false)
    private ServicioVehiculo servicioVehiculo;
}