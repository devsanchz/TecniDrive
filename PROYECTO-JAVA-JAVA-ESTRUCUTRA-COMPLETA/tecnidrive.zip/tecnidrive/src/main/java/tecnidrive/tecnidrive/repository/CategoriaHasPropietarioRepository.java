package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CategoriaHasPropietario;
import tecnidrive.tecnidrive.model.CategoriaHasPropietarioId;
import org.springframework.data.jpa.repository.JpaRepository;

// El segundo parámetro genérico ahora es la clase de la llave compuesta,
// no un Integer/Long como en los demás Repositories
public interface CategoriaHasPropietarioRepository extends JpaRepository<CategoriaHasPropietario, CategoriaHasPropietarioId> {
}
