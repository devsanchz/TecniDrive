package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.PapelVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PapelVehiculoRepository extends JpaRepository<PapelVehiculo, Integer> {

    // Para mostrar todos los papeles (SOAT, tecnomecánica) de un vehículo específico,
    // al ver el detalle o el registro completo de ese vehículo
    List<PapelVehiculo> findByVehiculo_Placa(String placa);
}