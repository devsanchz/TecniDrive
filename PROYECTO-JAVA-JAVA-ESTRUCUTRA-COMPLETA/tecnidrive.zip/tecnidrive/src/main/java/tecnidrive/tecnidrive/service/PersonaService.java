package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.repository.PersonaRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PersonaService {
    // CORRECCIÓN anteriro: El archivo tenía la interfaz PersonaService y también el PersonaController juntos,
    // por eso los separé para mantener cada capa en su carpeta correspondiente.
    // También tenía PersonaResponseDTO y PersonaRequestDTO, pero esas clases no estaban creadas,
    //  así que por ahora trabajamos directamente con el modelo Persona.


    // CORRECCIÓN final: cambiamos de inyección por constructor a @Autowired en el
    // campo, para mantener el mismo estilo que usamos en AuthController y
    // PanelController en todo el resto del proyecto
    @Autowired
    private PersonaRepository personaRepository;

    public List<Persona> listarTodos() {
        return personaRepository.findAll();
    }

    public Optional<Persona> buscarPorEmail(String email) {
        return personaRepository.findByEmail(email);
    }

    public Persona obtenerPorId(Integer id) {
        return personaRepository.findById(id).orElse(null);
    }

    // Sin encriptación por ahora (temporal)
    public Persona guardar(Persona persona) {
        return personaRepository.save(persona);
    }

    public void eliminar(Integer id) {
        personaRepository.deleteById(id);
    }

    public Persona actualizar(Integer id, Persona datosActualizados) {
        Persona existente = personaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));

        existente.setEmail(datosActualizados.getEmail());
        existente.setAvatarColor(datosActualizados.getAvatarColor());

        return personaRepository.save(existente);
    }
}