package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.Tecnico;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TecnicoRepository extends JpaRepository<Tecnico, Integer> {

    // Para listar los técnicos de un taller específico
    List<Tecnico> findByTaller_IdTaller(Integer idTaller);
}