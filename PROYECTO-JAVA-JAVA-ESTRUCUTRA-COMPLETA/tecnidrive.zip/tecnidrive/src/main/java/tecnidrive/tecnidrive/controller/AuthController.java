package tecnidrive.tecnidrive.controller;

import tecnidrive.tecnidrive.dto.LoginRequestDTO;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.model.Rol;
import tecnidrive.tecnidrive.service.PersonaService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private PersonaService personaService;

    // CORRECCIÓN TEMPORAL: quitamos PasswordEncoder por ahora, mientras
    // estabilizamos el proyecto después de integrar las partes del equipo.
    // La contraseña se compara en texto plano por el momento.
    // PENDIENTE: reactivar encriptación con BCrypt antes de la entrega final.

    // CORRECCIÓN: agregado @Valid antes de @RequestBody. Sin esto, las
    // anotaciones @NotBlank y @Email que puso mi compañero en LoginRequestDTO
    // no se ejecutan solas — @Valid es lo que le dice a Spring "revisa esas
    // reglas antes de entrar al método". Si algo falla, Spring corta la
    // petición automáticamente con un error 400, antes de llegar aquí.
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @Valid @RequestBody LoginRequestDTO datosLogin,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        // 1. Buscamos la persona por email
        // CORRECCIÓN: LoginRequestDTO es un "record" (lo hizo mi compañero),
        // así que sus getters no llevan el prefijo "get" — se llaman
        // directamente igual que el campo: email() y password()
        Optional<Persona> personaOpt = personaService.buscarPorEmail(datosLogin.email());

        // 2. Si no existe, mensaje genérico
        if (personaOpt.isEmpty()) {
            respuesta.put("mensaje", "Correo o contraseña incorrectos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        Persona persona = personaOpt.get();

        // 3. CORRECCIÓN TEMPORAL: comparación directa en texto plano,
        // sin PasswordEncoder, mientras dejamos el proyecto estable de nuevo
        boolean passwordCorrecto = persona.getPasswordHash().equals(datosLogin.password());

        if (!passwordCorrecto) {
            respuesta.put("mensaje", "Correo o contraseña incorrectos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        // 4. Tomamos el primer (y único, por ahora) rol de la persona
        Rol rolPersona = persona.getRoles().iterator().next();

        // 5. Guardamos los datos importantes en la sesión
        // CORRECCIÓN: gettexto_rol() no existe; Lombok genera getTextoRol()
        // a partir del nombre del atributo "textoRol" en la clase Rol
        session.setAttribute("idPersona", persona.getIdPersona());
        session.setAttribute("email", persona.getEmail());
        session.setAttribute("rol", rolPersona.getTextoRol());

        // 6. Decidimos a qué panel redirigir según el rol de la persona
        String redirectUrl;
        switch (rolPersona.getTextoRol()) {
            case "Administrador":
                redirectUrl = "/panel-admin";
                break;
            case "Propietario":
                redirectUrl = "/panel-propietario";
                break;
            case "Mecanico":
                redirectUrl = "/panel-mecanico";
                break;
            default:
                redirectUrl = "/login";
        }

        // 7. Respondemos con éxito
        respuesta.put("mensaje", "Login exitoso");
        respuesta.put("rol", rolPersona.getTextoRol());
        respuesta.put("nombre", persona.getPrimerNombre());
        respuesta.put("redirectUrl", redirectUrl);

        return ResponseEntity.ok(respuesta);
    }

    @GetMapping("/sesion")
    public ResponseEntity<Map<String, Object>> verSesion(HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Object idPersona = session.getAttribute("idPersona");

        if (idPersona == null) {
            respuesta.put("mensaje", "No hay una sesión activa");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        respuesta.put("idPersona", idPersona);
        respuesta.put("email", session.getAttribute("email"));
        respuesta.put("rol", session.getAttribute("rol"));

        return ResponseEntity.ok(respuesta);
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        session.invalidate();

        respuesta.put("mensaje", "Sesión cerrada correctamente");
        return ResponseEntity.ok(respuesta);
    }
}