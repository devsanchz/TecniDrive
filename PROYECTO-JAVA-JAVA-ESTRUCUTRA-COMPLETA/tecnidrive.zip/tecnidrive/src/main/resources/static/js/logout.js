// Script compartido por los 3 paneles para cerrar sesión.
// Busca el botón por su id y, al hacer clic, llama al endpoint de logout.
document.getElementById('btnCerrarSesion').addEventListener('click', async function (event) {
    event.preventDefault(); // evita que el <a href="#"> intente navegar

    try {
        const response = await fetch('/api/auth/logout', {
            method: 'POST'
        });

        if (response.ok) {
            // Sesión cerrada correctamente en el servidor, ahora sí navegamos al login
            window.location.href = '/login';
        } else {
            console.error('No se pudo cerrar la sesión correctamente.');
        }

    } catch (error) {
        console.error('Error de red al cerrar sesión:', error);
    }
});