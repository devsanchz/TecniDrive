package tecnidrive.tecnidrive.dto;

// Solo el nombre, que es lo único que la plantilla necesita mostrar
public record TecnicoDTO(String nombreTecnico) {
}