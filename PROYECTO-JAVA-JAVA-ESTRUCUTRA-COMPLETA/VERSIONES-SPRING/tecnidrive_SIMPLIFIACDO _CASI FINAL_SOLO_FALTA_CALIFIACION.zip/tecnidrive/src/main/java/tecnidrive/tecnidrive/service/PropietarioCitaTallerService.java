package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tecnidrive.tecnidrive.dto.PropietarioCitaDTO;
import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.*;

import java.time.LocalDateTime;
import java.util.*;

// CORRECCIÓN: separado de CitaTallerService. Contiene únicamente lo que
// necesita el propietario: agendar, ver sus citas y cancelarlas
@Service
public class PropietarioCitaTallerService {

    @Autowired
    private CitaTallerRepository citaTallerRepository;

    @Autowired
    private CitaHasServicioRepository citaHasServicioRepository;

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private PropietarioVehiculoService vehiculoService;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    @Autowired
    private GestionMantenimientoRepository gestionMantenimientoRepository;

    private static final List<EstadoCita> ESTADOS_ACTIVOS = Arrays.asList(
            EstadoCita.pendiente, EstadoCita.confirmada, EstadoCita.en_atencion
    );

    public boolean tieneCitaActiva(String placa) {
        return citaTallerRepository.findAll().stream()
                .filter(c -> c.getVehiculo().getPlaca().equals(placa))
                .filter(c -> ESTADOS_ACTIVOS.contains(c.getEstadoCita()))
                .anyMatch(c -> gestionMantenimientoRepository.findByCitaTaller_IdCita(c.getIdCita())
                        .map(g -> g.getEstadoMantenimiento() != EstadoMantenimiento.finalizada)
                        .orElse(true));
    }

    @Transactional
    public void agendarCita(
            Integer idTaller, String placa, String fechaCita, String horaCita,
            String problema, List<Integer> servicios, Integer idPropietario) {

        Vehiculo vehiculo = vehiculoService.obtenerSiEsDelPropietario(placa, idPropietario);
        if (vehiculo == null) throw new IllegalArgumentException("vehiculo-invalido");
        if (tieneCitaActiva(placa)) throw new IllegalArgumentException("vehiculo-ocupado");

        Taller taller = tallerRepository.findById(idTaller)
                .orElseThrow(() -> new IllegalArgumentException("taller-invalido"));

        LocalDateTime fechaHora = LocalDateTime.parse(fechaCita + "T" + horaCita + ":00");

        CitaTaller cita = new CitaTaller();
        cita.setFechaCita(fechaHora);
        cita.setProblemaContexto((problema == null || problema.isBlank()) ? null : problema.trim());
        cita.setEstadoCita(EstadoCita.pendiente);
        cita.setTaller(taller);
        cita.setVehiculo(vehiculo);

        CitaTaller citaGuardada = citaTallerRepository.save(cita);

        if (servicios != null) {
            for (Integer idServicio : servicios) {
                CitaHasServicioId id = new CitaHasServicioId();
                id.setIdCita(citaGuardada.getIdCita());
                id.setIdTaller(idTaller);
                id.setIdServicio(idServicio);

                CitaHasServicio relacion = new CitaHasServicio();
                relacion.setId(id);
                citaHasServicioRepository.save(relacion);
            }
        }
    }

    public List<PropietarioCitaDTO> listarCitasDelPropietario(Integer idPropietario) {
        List<CitaTaller> citas = citaTallerRepository
                .findByVehiculo_Propietario_IdPersonaOrderByFechaCitaDesc(idPropietario);
        List<PropietarioCitaDTO> resultado = new ArrayList<>();

        for (CitaTaller cita : citas) {
            PropietarioCitaDTO vista = new PropietarioCitaDTO();
            vista.setIdCita(cita.getIdCita());
            vista.setFechaCita(cita.getFechaCita());
            vista.setFechaRegistro(cita.getFechaRegistro());
            vista.setEstadoCita(cita.getEstadoCita().name());
            vista.setClaseEstado(cita.getEstadoCita().getClase());
            vista.setTextoEstado(cita.getEstadoCita().getTexto());
            vista.setCodigoConfirmacion(cita.getCodigoConfirmacion());
            vista.setProblemaContexto(cita.getProblemaContexto());
            vista.setMotivoCancelacion(cita.getMotivoCancelacion());

            Taller taller = cita.getTaller();
            vista.setNombreTaller(taller.getNombreTaller());
            vista.setDireccionTaller(taller.getDireccionTaller());
            vista.setMecanicoNombre(taller.getMecanico().getPrimerNombre());
            vista.setMecanicoApellido(taller.getMecanico().getPrimerApellido());
            vista.setTelefonoMecanico(taller.getMecanico().getTelefonoMecanico());

            Vehiculo vehiculo = cita.getVehiculo();
            vista.setPlaca(vehiculo.getPlaca());
            vista.setModelYear(vehiculo.getModelYear());
            vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
            vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

            vista.setServicios(obtenerServiciosConPrecio(cita));

           gestionMantenimientoRepository.findByCitaTaller_IdCita(cita.getIdCita())
        .ifPresent(mant -> {
            vista.setEstadoMantenimiento(mant.getEstadoMantenimiento().name());
            vista.setObservacionesTecnico(mant.getObservacionesTecnico());
            vista.setPrecioTotal(mant.getPrecioTotal());
            vista.setCodigoEntrega(mant.getCodigoEntrega());
            // AGREGADO:
            vista.setTextoGarantia(mant.getTextoGarantia());
            vista.setGarantiaVigencia(mant.getGarantiaVigencia());
        });

            resultado.add(vista);
        }

        return resultado;
    }

    @Transactional
    public void cancelarCitaPropietario(Integer idCita, Integer idPropietario, String motivo) {
        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (!cita.getVehiculo().getPropietario().getIdPersona().equals(idPropietario)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        if (cita.getEstadoCita() != EstadoCita.pendiente) {
            throw new IllegalArgumentException("cita-no-cancelable");
        }

        cita.setEstadoCita(EstadoCita.cancelada_propietario);
        cita.setMotivoCancelacion(motivo);
        citaTallerRepository.save(cita);
    }

    // CORRECCIÓN: nombre alineado con las llamadas (antes había un
    // mezcladero de "obtenerServiciosPrecioDTO" que no coincidía)
    private List<ServicioPrecioDTO> obtenerServiciosConPrecio(CitaTaller cita) {
        List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
        List<ServicioPrecioDTO> servicios = new ArrayList<>();

        for (CitaHasServicio rel : relaciones) {
            Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
            if (servicio == null) continue;

            TallerHasServicioId thsId = new TallerHasServicioId();
            thsId.setIdTaller(rel.getId().getIdTaller());
            thsId.setIdServicio(rel.getId().getIdServicio());

            java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
                    .map(TallerHasServicio::getPrecioServicio)
                    .orElse(java.math.BigDecimal.ZERO);

            servicios.add(new ServicioPrecioDTO(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
        }

        return servicios;
    }
}