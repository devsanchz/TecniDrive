package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import tecnidrive.tecnidrive.dto.RegistroRequestDTO;
import tecnidrive.tecnidrive.service.RegistroService;


@Controller
public class RegistroController {

    @Autowired
    private RegistroService registroService;

//METODO 1: Mostrar informacion en la plantilla
    @GetMapping("/registro")
    public String mostrarFormulario(Model model) {
        model.addAttribute("datos", new RegistroRequestDTO());
        return "registro";
    }

    // FLUJO:
    // 1. Validamos los datos con las anotaciones del DTO (@Valid).
    // 2. Revisamos si el correo ya existe.
    // 3. Si algo falló, volvemos a mostrar el formulario con los errores.
    // 4. Si todo está bien, guardamos los datos en sesión y pasamos a elegir rol.

//METODO 2: poner datos en el formulario parte 1 del registro    
    @PostMapping("/registro")
    public String registrarDatos(
            @Valid @ModelAttribute("datos") RegistroRequestDTO datos,
            BindingResult resultado,
            HttpSession session) {

        if (registroService.emailYaRegistrado(datos.getEmail())) {
            // rejectValue asocia el error directamente al campo "email",
            // así th:errors="*{email}" lo muestra debajo del campo correcto
            resultado.rejectValue("email", "email.duplicado", "Este correo ya está registrado");
        }

        if (resultado.hasErrors()) {
            return "registro";
        }

        session.setAttribute("primerNombre", datos.getPrimerNombre());
        session.setAttribute("segundoNombre", datos.getSegundoNombre());
        session.setAttribute("primerApellido", datos.getPrimerApellido());
        session.setAttribute("segundoApellido", datos.getSegundoApellido());
        session.setAttribute("telefono", Long.parseLong(datos.getTelefono()));
        session.setAttribute("email", datos.getEmail());
        session.setAttribute("password", datos.getPassword());

        return "redirect:/rol";
    }

//METODO 3: Moatrar informacion en la plantilla parte 2 del regsitro 
    @GetMapping("/rol")
    public String mostrarRoles() {
        return "rol";
    }

    // FLUJO:
    // 1. Validamos que se haya elegido un rol.
    // 2. Recuperamos los datos guardados en sesión.
    // 3. Registramos según el rol (propietario o mecánico).
    // 4. Cerramos la sesión y redirigimos al login.

//METODO 4: Poner datos en el formulario para finalizar registro  
    @PostMapping("/rol")
    public String finalizarRegistro(
            @RequestParam(required = false) Integer rol,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        if (rol == null) {
            redirectAttributes.addFlashAttribute("error", "Debes seleccionar un rol");
            return "redirect:/rol";
        }

        String primerNombre = (String) session.getAttribute("primerNombre");
        String segundoNombre = (String) session.getAttribute("segundoNombre");
        String primerApellido = (String) session.getAttribute("primerApellido");
        String segundoApellido = (String) session.getAttribute("segundoApellido");
        Long telefono = (Long) session.getAttribute("telefono");
        String email = (String) session.getAttribute("email");
        String password = (String) session.getAttribute("password");

        if (primerNombre == null || email == null || password == null) {
            redirectAttributes.addFlashAttribute("error", "La sesión expiró, vuelve a completar el formulario");
            return "redirect:/registro";
        }

        if (rol == 2) {
            registroService.registrarPropietario(primerNombre, segundoNombre, primerApellido, segundoApellido, telefono, email, password);
        } else if (rol == 3) {
            registroService.registrarMecanico(primerNombre, segundoNombre, primerApellido, segundoApellido, telefono, email, password);
        } else {
            redirectAttributes.addFlashAttribute("error", "Rol no válido");
            return "redirect:/rol";
        }

        session.invalidate();

        return "redirect:/login?registro=exitoso";
    }
}