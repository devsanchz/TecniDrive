package tecnidrive.tecnidrive.model;

// Cada estado ya sabe cómo debe verse en la vista (texto y clase CSS),
// para no repetir esa lógica en cada Controller que necesite mostrarla
public enum EstadoCita {
    pendiente("Pendiente", "pendiente"),
    confirmada("Confirmada", "confirmada"),
    en_atencion("En atención", "en-atencion"),
    cancelada_propietario("Cancelada por cliente", "cancelada"),
    cancelada_mecanico("Cancelada por mí", "cancelada");

    private final String texto;
    private final String clase;

    EstadoCita(String texto, String clase) {
        this.texto = texto;
        this.clase = clase;
    }

    public String getTexto() {
        return texto;
    }

    public String getClase() {
        return clase;
    }
}