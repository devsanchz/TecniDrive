package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class NuevaPasswordDTO {

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 8, message = "La contraseña debe tener al menos 8 caracteres")
    private String password;

    @NotBlank(message = "Debes confirmar la contraseña")
    private String repassword;

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRepassword() { return repassword; }
    public void setRepassword(String repassword) { this.repassword = repassword; }
}