package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.service.MecanicoService;
import tecnidrive.tecnidrive.service.MecanicoTallerService;

@Controller
public class MecanicoTallerController {

    @Autowired
    private MecanicoTallerService mecanicoTallerService;

    @Autowired
    private MecanicoService mecanicoService;

    @GetMapping("/mecanico/taller")
    public String verTaller(
            @RequestParam(value = "registro", required = false) String registro,
            @RequestParam(value = "error", required = false) String error,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) {
            return "redirect:/login";
        }

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        model.addAttribute("taller", taller);

        if (taller != null) {
            model.addAttribute("especialidades", new ArrayList<>(taller.getEspecialidades()));
            List<ServicioPrecioDTO> servicios = mecanicoTallerService.obtenerServiciosDelTaller(taller.getIdTaller());
            model.addAttribute("servicios", servicios);
        }

        if ("exitoso".equals(registro)) {
            model.addAttribute("exito", "¡Taller registrado correctamente!");
        }
        if (error != null) {
            model.addAttribute("error", traducirError(error));
        }

        return "mecanico/mecanico-taller";
    }

    @PostMapping("/mecanico/taller/registrar")
    public String registrarTaller(
            @RequestParam("nombre") String nombre,
            @RequestParam("especialidad") String especialidad,
            @RequestParam("descripcion") String descripcion,
            @RequestParam("ubicacion") String ubicacion,
            @RequestParam("dias[]") String[] dias,
            @RequestParam("horas[]") String[] horas,
            @RequestParam("servicio[]") String[] servicios,
            @RequestParam("precio[]") String[] precios,
            @RequestParam(value = "foto", required = false) MultipartFile foto,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) {
            return "redirect:/login";
        }

        Mecanico mecanico = mecanicoService.obtenerPorId(idPersona);
        if (mecanico == null) {
            return "redirect:/login";
        }

        if (mecanicoTallerService.obtenerTallerDelMecanico(idPersona) != null) {
            return "redirect:/mecanico/taller?error=ya-tienes-taller";
        }

        Taller taller = new Taller();
        taller.setNombreTaller(nombre.trim());
        taller.setDescripcionTaller(descripcion.trim());
        taller.setDireccionTaller(ubicacion.trim());
        taller.setEstadoTaller(true);
        taller.setMecanico(mecanico);

        String horario = mecanicoTallerService.construirHorarioTexto(dias, horas);
        taller.setHorarioTaller(horario);

        try {
            mecanicoTallerService.registrarTaller(taller, especialidad.trim(), servicios, precios, foto);
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/taller?error=" + e.getMessage();
        }

        return "redirect:/mecanico/taller?registro=exitoso";
    }

    private String traducirError(String codigo) {
        return switch (codigo) {
            case "ya-tienes-taller" -> "Ya tienes un taller registrado.";
            case "tipo-invalido" -> "Solo se permiten imágenes JPG, PNG o WEBP.";
            case "imagen-grande" -> "La imagen no puede superar 2MB.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
}