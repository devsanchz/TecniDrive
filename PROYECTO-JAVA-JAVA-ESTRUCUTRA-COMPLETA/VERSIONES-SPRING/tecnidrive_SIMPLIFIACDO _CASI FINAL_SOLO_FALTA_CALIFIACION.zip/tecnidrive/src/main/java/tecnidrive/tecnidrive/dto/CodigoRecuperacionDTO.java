package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

// CORRECCIÓN: ya no pide "email". El correo viaja en la sesión
// desde el paso 1, así que este DTO solo necesita el código
public class CodigoRecuperacionDTO {

    @NotBlank(message = "El código es obligatorio")
    @Size(min = 6, max = 6, message = "El código debe tener 6 dígitos")
    private String codigo;

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
}