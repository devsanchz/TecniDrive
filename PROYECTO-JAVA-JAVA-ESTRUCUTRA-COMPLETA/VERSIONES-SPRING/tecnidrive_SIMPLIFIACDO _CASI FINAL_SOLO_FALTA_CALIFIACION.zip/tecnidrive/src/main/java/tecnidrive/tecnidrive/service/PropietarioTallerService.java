package tecnidrive.tecnidrive.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.dto.PropietarioTallerDTO;
import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Servicio;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.model.TallerHasServicio;
import tecnidrive.tecnidrive.repository.ServicioRepository;
import tecnidrive.tecnidrive.repository.TallerHasServicioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;

@Service
public class PropietarioTallerService {

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    public List<PropietarioTallerDTO> listarActivosParaPropietario() {
        List<Taller> talleres = tallerRepository.findByEstadoTallerTrue();
        List<PropietarioTallerDTO> resultado = new ArrayList<>();

        for (Taller taller : talleres) {
            PropietarioTallerDTO vista = new PropietarioTallerDTO();
            vista.setIdTaller(taller.getIdTaller());
            vista.setNombreTaller(taller.getNombreTaller());
            vista.setDescripcionTaller(taller.getDescripcionTaller());
            vista.setDireccionTaller(taller.getDireccionTaller());

            String foto = taller.getFotoTaller();
            vista.setFotoTaller(
                (foto != null && !foto.isBlank())
                    ? "/uploads/talleres/" + foto
                    : "/img/taller-placeholder.jpg"
            );

            List<Especialidad> especialidades = new ArrayList<>(taller.getEspecialidades());
            if (especialidades.isEmpty()) {
                Especialidad sinEspecialidad = new Especialidad();
                sinEspecialidad.setNombreEspecialidad("Sin especialidad");
                especialidades.add(sinEspecialidad);
            }
            vista.setEspecialidades(especialidades);

            vista.setServicios(obtenerServiciosDelTaller(taller.getIdTaller()));
            vista.setHorarios(taller.getHorarios());
            resultado.add(vista);
        }

        return resultado;
    }

    private List<ServicioPrecioDTO> obtenerServiciosDelTaller(Integer idTaller) {
        List<TallerHasServicio> relaciones = tallerHasServicioRepository.findById_IdTaller(idTaller);
        List<ServicioPrecioDTO> resultado = new ArrayList<>();

        for (TallerHasServicio relacion : relaciones) {
            Servicio servicio = servicioRepository.findById(relacion.getId().getIdServicio())
                    .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

            resultado.add(new ServicioPrecioDTO(
                    servicio.getIdServicio(),
                    servicio.getNombreServicio(),
                    relacion.getPrecioServicio()
            ));
        }

        return resultado;
    }
}