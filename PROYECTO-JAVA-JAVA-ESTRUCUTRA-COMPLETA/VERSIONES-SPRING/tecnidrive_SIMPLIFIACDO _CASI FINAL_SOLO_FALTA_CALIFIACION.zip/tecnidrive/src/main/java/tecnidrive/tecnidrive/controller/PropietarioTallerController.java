package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.PropietarioTallerDTO;
import tecnidrive.tecnidrive.dto.VehiculoDTO;
import tecnidrive.tecnidrive.service.PropietarioCitaTallerService;
import tecnidrive.tecnidrive.service.PropietarioTallerService;
import tecnidrive.tecnidrive.service.PropietarioVehiculoService;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class PropietarioTallerController {

    @Autowired
    private PropietarioTallerService propietarioTallerService;

    @Autowired
    private PropietarioVehiculoService vehiculoService;

    // CORRECCIÓN: ya no necesita el service completo de citas, solo
    // tieneCitaActiva() para marcar los vehículos ocupados en el formulario
    @Autowired
    private PropietarioCitaTallerService propietarioCitaTallerService;

    @GetMapping("/propietario/taller")
    public String verTalleres(HttpSession session, Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) {
            return "redirect:/login";
        }

        List<PropietarioTallerDTO> talleres = propietarioTallerService.listarActivosParaPropietario();
        model.addAttribute("talleres", talleres);
        model.addAttribute("total", talleres.size());

        List<String> especialidadesUnicas = talleres.stream()
                .flatMap(t -> t.getEspecialidades().stream())
                .map(e -> e.getNombreEspecialidad())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
        model.addAttribute("especialidadesUnicas", especialidadesUnicas);

        List<VehiculoDTO> misVehiculos = vehiculoService.obtenerVistaPorPropietario(idPersona);

        for (VehiculoDTO v : misVehiculos) {
            v.setTieneCitaActiva(propietarioCitaTallerService.tieneCitaActiva(v.getPlaca()));
        }

        model.addAttribute("misVehiculos", misVehiculos);
        model.addAttribute("fechaMinimaCita", LocalDate.now().plusDays(1).toString());

        return "propietario/propietario-taller";
    }
}