package tecnidrive.tecnidrive.model;

//como lo hizo LAURA esta bien, pero se puede  simplificar en la llamada para importar las herramientas del JPA
import jakarta.persistence.*;

//LOMBOK DE DAVID
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "roles")

public class Rol {
@Id
@Column(name = "id_rol")
private Integer idRol;

@Column(name = "texto_rol", length = 15, nullable = false)
private String textoRol;
}
