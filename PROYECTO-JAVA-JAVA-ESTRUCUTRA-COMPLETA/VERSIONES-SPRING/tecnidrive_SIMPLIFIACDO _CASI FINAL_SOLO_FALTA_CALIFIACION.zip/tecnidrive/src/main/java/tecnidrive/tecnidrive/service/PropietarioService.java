package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.model.CategoriaHasPropietario;
import tecnidrive.tecnidrive.model.CategoriaHasPropietarioId;
import tecnidrive.tecnidrive.model.CategoriaLicencia;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.repository.CategoriaHasPropietarioRepository;
import tecnidrive.tecnidrive.repository.CategoriaLicenciaRepository;
import tecnidrive.tecnidrive.repository.PropietarioRepository;

import java.util.ArrayList;
import java.util.List;

//nuevo para el registro del vehiculo
import tecnidrive.tecnidrive.dto.CategoriaVigenteDTO;




@Service
public class PropietarioService {

    // CORRECCIÓN final: cambiamos de inyección por constructor a @Autowired en el
    // campo, para que quede igual al resto del proyecto (mismo criterio que
    // en PersonaService y en los Controllers)
    @Autowired
    private PropietarioRepository propietarioRepository;
        @Autowired
    private CategoriaLicenciaRepository categoriaLicenciaRepository;

    @Autowired
    private CategoriaHasPropietarioRepository categoriaHasPropietarioRepository;

    // AGREGADO: igual que tu PHP tieneLicencia(), revisa si ya tiene
    // un número de licencia guardado
    public boolean tieneLicencia(Integer idPropietario) {
        Propietario propietario = obtenerPorId(idPropietario);
        return propietario != null
                && propietario.getNumeroLicencia() != null
                && !propietario.getNumeroLicencia().isBlank();
    }

    // AGREGADO: guarda el número de licencia y cada categoría con su vigencia
   public void guardarLicencia(Integer idPropietario, String numeroLicencia, String[] categorias, String[] fechas) {
    // CORRECCIÓN: antes se usaba el resultado de obtenerPorId() sin
    // comprobar null, lo que causaba NullPointerException si el id de
    // sesión no correspondía a ningún propietario registrado
    Propietario propietario = obtenerPorId(idPropietario);
    if (propietario == null) {
        throw new IllegalArgumentException("propietario-no-encontrado");
    }

    propietario.setNumeroLicencia(numeroLicencia);
    propietarioRepository.save(propietario);

    for (int i = 0; i < categorias.length; i++) {
        String tipo = categorias[i] == null ? "" : categorias[i].trim().toUpperCase();
        if (tipo.isEmpty() || fechas[i] == null || fechas[i].isBlank()) continue;

        CategoriaLicencia categoria = categoriaLicenciaRepository.findByTipoCategoria(tipo)
                .orElseGet(() -> {
                    CategoriaLicencia nueva = new CategoriaLicencia();
                    nueva.setTipoCategoria(tipo);
                    return categoriaLicenciaRepository.save(nueva);
                });

        CategoriaHasPropietarioId id = new CategoriaHasPropietarioId();
        id.setIdCategoria(categoria.getIdCategoria());
        id.setIdPropietario(idPropietario);

        if (categoriaHasPropietarioRepository.existsById(id)) continue;

        CategoriaHasPropietario relacion = new CategoriaHasPropietario();
        relacion.setId(id);
        relacion.setVigenciaLice(java.time.LocalDate.parse(fechas[i]));
        relacion.setEstadoLice(true);
        categoriaHasPropietarioRepository.save(relacion);
    }
}

    // AGREGADO: junta cada categoría con su nombre real, para la vista
    public List<CategoriaVigenteDTO> obtenerCategoriasVigentes(Integer idPropietario) {
        List<CategoriaHasPropietario> relaciones = categoriaHasPropietarioRepository.findById_IdPropietario(idPropietario);
        List<CategoriaVigenteDTO> resultado = new ArrayList<>();

        for (CategoriaHasPropietario relacion : relaciones) {
            CategoriaLicencia categoria = categoriaLicenciaRepository.findById(relacion.getId().getIdCategoria())
                    .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
            resultado.add(new CategoriaVigenteDTO(categoria.getTipoCategoria(), relacion.getVigenciaLice()));
        }

        return resultado;
    }

    // CORRECCIÓN: renombrado de "listarPropietarios" a "listarTodos" y de // "buscarporId" a "obtenerPorId",
    // solo para que el nombre coincida con // PersonaService y MecanicoService (así cualquier Controller los llama igual)
    public List<Propietario> listarTodos() {
        return propietarioRepository.findAll();
    }

    public Propietario obtenerPorId(Integer id) {
        return propietarioRepository.findById(id).orElse(null);
    }
    //sin encriptación de contraseña por ahora,
    public Propietario guardar(Propietario propietario) {
        return propietarioRepository.save(propietario);
    }



    //no estaba, pero lo necesitamos para que desde el panel 
    // // el propietario pueda editar su email, avatarColor y teléfono
    public Propietario actualizar(Integer id, Propietario datosActualizados) {
        Propietario existente = propietarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Propietario no encontrado"));

        existente.setEmail(datosActualizados.getEmail());
        existente.setAvatarColor(datosActualizados.getAvatarColor());
        existente.setTelefonoPropietario(datosActualizados.getTelefonoPropietario());

        return propietarioRepository.save(existente);
    }
}