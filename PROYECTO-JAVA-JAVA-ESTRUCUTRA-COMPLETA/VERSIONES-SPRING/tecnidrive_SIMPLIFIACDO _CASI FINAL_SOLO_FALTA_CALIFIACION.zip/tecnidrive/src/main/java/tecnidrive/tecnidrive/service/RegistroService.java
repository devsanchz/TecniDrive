package tecnidrive.tecnidrive.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.model.Rol;
import tecnidrive.tecnidrive.repository.MecanicoRepository;
import tecnidrive.tecnidrive.repository.PersonaRepository;
import tecnidrive.tecnidrive.repository.PropietarioRepository;
import tecnidrive.tecnidrive.repository.RolRepository;

@Service
public class RegistroService {

    // CORRECCIÓN: se agrega PersonaRepository. No reemplaza a los otros dos,
    // se usa solo para la validación de email, que es un dato de la tabla padre
    @Autowired
    private PersonaRepository personaRepository;

    @Autowired
    private PropietarioRepository propietarioRepository;

    @Autowired
    private MecanicoRepository mecanicoRepository;

    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // CORRECCIÓN: antes consultaba dos repositorios (propietario y mecánico).
    // Como "email" vive en la tabla "personas" (la tabla padre), una sola
    // consulta contra PersonaRepository ya cubre ambos casos
    public boolean emailYaRegistrado(String email) {
        return personaRepository.existsByEmail(email);
    }

    public void registrarPropietario(
            String primerNombre,
            String segundoNombre,
            String primerApellido,
            String segundoApellido,
            Long telefono,
            String email,
            String password) {

        Rol rol = rolRepository.findById(2)
                .orElseThrow(() -> new RuntimeException("Rol Propietario no encontrado"));

        Propietario propietario = new Propietario();
        propietario.setPrimerNombre(primerNombre);
        propietario.setSegundoNombre(segundoNombre);
        propietario.setPrimerApellido(primerApellido);
        propietario.setSegundoApellido(segundoApellido);
        propietario.setEmail(email);
        propietario.setPasswordHash(passwordEncoder.encode(password));
        propietario.setTelefonoPropietario(telefono);

        Set<Rol> roles = new HashSet<>();
        roles.add(rol);
        propietario.setRoles(roles);

        // Sigue siendo necesario: guarda en la tabla "propietarios"
        propietarioRepository.save(propietario);
    }

    public void registrarMecanico(
            String primerNombre,
            String segundoNombre,
            String primerApellido,
            String segundoApellido,
            Long telefono,
            String email,
            String password) {

        Rol rol = rolRepository.findById(3)
                .orElseThrow(() -> new RuntimeException("Rol Mecánico no encontrado"));

        Mecanico mecanico = new Mecanico();
        mecanico.setPrimerNombre(primerNombre);
        mecanico.setSegundoNombre(segundoNombre);
        mecanico.setPrimerApellido(primerApellido);
        mecanico.setSegundoApellido(segundoApellido);
        mecanico.setEmail(email);
        mecanico.setPasswordHash(passwordEncoder.encode(password));
        mecanico.setTelefonoMecanico(telefono);

        Set<Rol> roles = new HashSet<>();
        roles.add(rol);
        mecanico.setRoles(roles);

        // Sigue siendo necesario: guarda en la tabla "mecanicos"
        mecanicoRepository.save(mecanico);
    }
}