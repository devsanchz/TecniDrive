package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.repository.PersonaRepository;

import java.util.Optional;

@Service
public class LoginService {

    @Autowired
    private PersonaRepository personaRepository;

    public Optional<Persona> buscarPorEmail(String email) {
        return personaRepository.findByEmail(email);
    }
}