package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tecnidrive.tecnidrive.dto.MecanicoControlDTO;
import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.dto.TecnicoDTO;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.*;

import java.util.*;

@Service
public class GestionMantenimientoService {

    @Autowired
    private CitaTallerRepository citaTallerRepository;

    @Autowired
    private CitaHasServicioRepository citaHasServicioRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    @Autowired
    private GestionMantenimientoRepository gestionMantenimientoRepository;

    @Autowired
    private TecnicoService tecnicoService;

    public List<MecanicoControlDTO> listarEnAtencion(Integer idTaller) {
        List<CitaTaller> citas = citaTallerRepository.findByTaller_IdTallerOrderByFechaCitaDesc(idTaller)
                .stream()
                .filter(c -> c.getEstadoCita() == EstadoCita.en_atencion)
                .toList();

        List<MecanicoControlDTO> resultado = new ArrayList<>();

        for (CitaTaller cita : citas) {
            MecanicoControlDTO vista = new MecanicoControlDTO();
            vista.setIdCita(cita.getIdCita());
            vista.setFechaCita(cita.getFechaCita());
            vista.setProblemaContexto(cita.getProblemaContexto());
            vista.setFechaRegistro(cita.getFechaRegistro());
            vista.setFechaInicioAtencion(cita.getFechaInicioAtencion());

            Vehiculo vehiculo = cita.getVehiculo();
            vista.setPlaca(vehiculo.getPlaca());
            vista.setModelYear(vehiculo.getModelYear());
            vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
            vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

            Propietario propietario = vehiculo.getPropietario();
            vista.setClienteNombre(propietario.getPrimerNombre());
            vista.setClienteApellido(propietario.getPrimerApellido());
            vista.setTelefonoPropietario(propietario.getTelefonoPropietario());

            vista.setServicios(obtenerServiciosConPrecio(cita));

            gestionMantenimientoRepository.findByCitaTaller_IdCita(cita.getIdCita())
                    .ifPresent(mant -> {
                        vista.setIdSeguimiento(mant.getIdSeguimiento());
                        vista.setEstadoMantenimiento(mant.getEstadoMantenimiento().name());
                        vista.setObservacionesTecnico(mant.getObservacionesTecnico());
                        vista.setTextoGarantia(mant.getTextoGarantia());
                        vista.setGarantiaVigencia(mant.getGarantiaVigencia());
                        vista.setPrecioTotal(mant.getPrecioTotal());

                        List<TecnicoDTO> tecnicos = new ArrayList<>();
                        for (Tecnico tec : mant.getTecnicos()) {
                            tecnicos.add(new TecnicoDTO(tec.getNombreTecnico()));
                        }
                        vista.setTecnicosAsignados(tecnicos);
                    });

            resultado.add(vista);
        }

        return resultado;
    }

    @Transactional
    public void cerrarMantenimiento(
            Integer idCita, Integer idSeguimiento, Integer idTaller,
            String observaciones, String textoGarantia, String vigencia,
            String precioRaw, List<Integer> idsTecnicos) {

        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (cita.getEstadoCita() != EstadoCita.en_atencion
                || !cita.getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        GestionMantenimiento gestion = gestionMantenimientoRepository.findById(idSeguimiento)
                .orElseThrow(() -> new IllegalArgumentException("gestion-invalida"));

        if (!gestion.getCitaTaller().getIdCita().equals(idCita)) {
            throw new IllegalArgumentException("gestion-invalida");
        }

        String precioLimpio = precioRaw == null ? "" : precioRaw.replaceAll("[^0-9]", "");
        if (precioLimpio.isEmpty()) {
            throw new IllegalArgumentException("precio-requerido");
        }
        java.math.BigDecimal precioTotal = new java.math.BigDecimal(precioLimpio);

        if (idsTecnicos == null || idsTecnicos.isEmpty()) {
            throw new IllegalArgumentException("tecnicos-requeridos");
        }

        for (Integer idTec : idsTecnicos) {
            if (!tecnicoService.perteneceATaller(idTec, idTaller)) {
                throw new IllegalArgumentException("tecnico-invalido");
            }
        }

        String obsFinal = (observaciones == null || observaciones.isBlank()) ? null : observaciones.trim();
        String garantiaFinal = (textoGarantia == null || textoGarantia.isBlank()) ? null : textoGarantia.trim();
        java.time.LocalDateTime vigenciaFinal = (garantiaFinal != null && vigencia != null && !vigencia.isBlank())
                ? java.time.LocalDateTime.parse(vigencia + "T00:00:00")
                : null;

        String codigoEntrega;
        do {
            codigoEntrega = generarCodigo();
        } while (gestionMantenimientoRepository.findByCodigoEntrega(codigoEntrega).isPresent());

        gestion.setObservacionesTecnico(obsFinal);
        gestion.setPrecioTotal(precioTotal);
        gestion.setTextoGarantia(garantiaFinal);
        gestion.setGarantiaVigencia(vigenciaFinal);
        gestion.setEstadoMantenimiento(EstadoMantenimiento.en_cierre);
        gestion.setCodigoEntrega(codigoEntrega);

        Set<Tecnico> tecnicos = new HashSet<>();
        for (Integer idTec : idsTecnicos) {
            tecnicoService.listarPorTaller(idTaller).stream()
                    .filter(t -> t.getIdTecnico().equals(idTec))
                    .findFirst()
                    .ifPresent(tecnicos::add);
        }
        gestion.setTecnicos(tecnicos);

        gestionMantenimientoRepository.save(gestion);
    }

    @Transactional
    public void verificarEntrega(String codigo, Integer idTaller) {
        String codigoNormalizado = codigo.trim().toUpperCase();

        GestionMantenimiento gestion = gestionMantenimientoRepository.findByCodigoEntrega(codigoNormalizado)
                .filter(g -> g.getEstadoMantenimiento() == EstadoMantenimiento.en_cierre)
                .orElseThrow(() -> new IllegalArgumentException("codigo-invalido"));

        if (!gestion.getCitaTaller().getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("codigo-invalido");
        }

        gestion.setEstadoMantenimiento(EstadoMantenimiento.finalizada);
        gestion.setFechaCierre(java.time.LocalDate.now());
        gestionMantenimientoRepository.save(gestion);
    }

    private List<ServicioPrecioDTO> obtenerServiciosConPrecio(CitaTaller cita) {
        List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
        List<ServicioPrecioDTO> servicios = new ArrayList<>();

        for (CitaHasServicio rel : relaciones) {
            Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
            if (servicio == null) continue;

            TallerHasServicioId thsId = new TallerHasServicioId();
            thsId.setIdTaller(rel.getId().getIdTaller());
            thsId.setIdServicio(rel.getId().getIdServicio());

            java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
                    .map(TallerHasServicio::getPrecioServicio)
                    .orElse(java.math.BigDecimal.ZERO);

            servicios.add(new ServicioPrecioDTO(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
        }

        return servicios;
    }

    private String generarCodigo() {
        byte[] bytesAleatorios = new byte[5];
        new java.security.SecureRandom().nextBytes(bytesAleatorios);
        StringBuilder hex = new StringBuilder();
        for (byte b : bytesAleatorios) {
            hex.append(String.format("%02x", b));
        }
        return hex.substring(0, 8).toUpperCase();
    }
}