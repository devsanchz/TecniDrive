package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.ActualizarPerfilDTO;
import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.service.MecanicoService;
import tecnidrive.tecnidrive.service.PersonaService;
import tecnidrive.tecnidrive.service.PropietarioService;

// CORRECCIÓN: fusiona PanelController y PerfilController en una sola clase,
// ya que ambos trabajan sobre el mismo panel (mostrar + actualizar)
@Controller
public class PanelesController {

    @Autowired
    private PersonaService personaService;

    @Autowired
    private PropietarioService propietarioService;

    @Autowired
    private MecanicoService mecanicoService;

    // FLUJO: solo lectura, el admin no tiene formulario de edición por ahora
    @GetMapping("/panel-admin")
    public String panelAdmin(HttpSession session, Model model) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Persona persona = personaService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(persona));
        model.addAttribute("rolTexto", session.getAttribute("rol"));
        model.addAttribute("email", persona.getEmail());
        model.addAttribute("avatarColor", persona.getAvatarColor());

        return "admin/panel-admin";
    }

    // FLUJO:
    // 1. Buscamos al propietario.
    // 2. Cargamos sus datos actuales en el DTO, para que el formulario aparezca ya rellenado.
    @GetMapping("/panel-propietario")
    public String panelPropietario(
            @RequestParam(required = false) String actualizado,
            HttpSession session, Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Propietario propietario = propietarioService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(propietario));
        model.addAttribute("rolTexto", session.getAttribute("rol"));

        if (!model.containsAttribute("datos")) {
            model.addAttribute("datos", desdePropietario(propietario));
        }

        if ("exitoso".equals(actualizado)) {
            model.addAttribute("perfilActualizado", true);
        }

        return "propietario/panel-propietario";
    }

    // FLUJO: igual que panelPropietario, pero para mecánico
    @GetMapping("/panel-mecanico")
    public String panelMecanico(
            @RequestParam(required = false) String actualizado,
            HttpSession session, Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Mecanico mecanico = mecanicoService.obtenerPorId(idPersona);

        model.addAttribute("nombreCompleto", construirNombreCompleto(mecanico));
        model.addAttribute("rolTexto", session.getAttribute("rol"));

        if (!model.containsAttribute("datos")) {
            model.addAttribute("datos", desdeMecanico(mecanico));
        }

        if ("exitoso".equals(actualizado)) {
            model.addAttribute("perfilActualizado", true);
        }

        return "mecanico/panel-mecanico";
    }

    // FLUJO:
    // 1. Validamos formato (@Valid).
    // 2. Vemos el rol guardado en sesión para saber a cuál servicio llamar.
    // 3. Actualizamos y redirigimos al panel correspondiente.
    @PostMapping("/panel/actualizar-perfil")
    public String actualizarPerfil(
            @Valid @ModelAttribute("datos") ActualizarPerfilDTO datos,
            BindingResult resultado,
            HttpSession session, Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        String rol = (String) session.getAttribute("rol");

        if (idPersona == null || rol == null) return "redirect:/login";

        if (resultado.hasErrors()) {
            // CORRECCIÓN: si hay errores, volvemos a mostrar el panel correcto,
            // reutilizando los mismos métodos GET (así no repetimos el código
            // que arma nombreCompleto/rolTexto)
            model.addAttribute("datos", datos); // conserva lo que el usuario escribió
            return "Propietario".equals(rol)
                    ? panelPropietario(null, session, model)
                    : panelMecanico(null, session, model);
        }

        Long telefono = Long.parseLong(datos.getTelefono());

        if ("Propietario".equals(rol)) {
            Propietario actualizado = new Propietario();
            actualizado.setEmail(datos.getEmail());
            actualizado.setAvatarColor(datos.getAvatarColor());
            actualizado.setTelefonoPropietario(telefono);
            propietarioService.actualizar(idPersona, actualizado);
            return "redirect:/panel-propietario?actualizado=exitoso";

        } else if ("Mecanico".equals(rol)) {
            Mecanico actualizado = new Mecanico();
            actualizado.setEmail(datos.getEmail());
            actualizado.setAvatarColor(datos.getAvatarColor());
            actualizado.setTelefonoMecanico(telefono);
            mecanicoService.actualizar(idPersona, actualizado);
            return "redirect:/panel-mecanico?actualizado=exitoso";
        }

        return "redirect:/login";
    }

    private ActualizarPerfilDTO desdePropietario(Propietario p) {
        ActualizarPerfilDTO datos = new ActualizarPerfilDTO();
        datos.setEmail(p.getEmail());
        datos.setTelefono(String.valueOf(p.getTelefonoPropietario()));
        datos.setAvatarColor(p.getAvatarColor());
        return datos;
    }

    private ActualizarPerfilDTO desdeMecanico(Mecanico m) {
        ActualizarPerfilDTO datos = new ActualizarPerfilDTO();
        datos.setEmail(m.getEmail());
        datos.setTelefono(String.valueOf(m.getTelefonoMecanico()));
        datos.setAvatarColor(m.getAvatarColor());
        return datos;
    }

    private String construirNombreCompleto(Persona persona) {
        String nombre = persona.getPrimerNombre();
        if (persona.getSegundoNombre() != null && !persona.getSegundoNombre().isBlank()) {
            nombre += " " + persona.getSegundoNombre();
        }
        nombre += " " + persona.getPrimerApellido() + " " + persona.getSegundoApellido();
        return nombre;
    }
}