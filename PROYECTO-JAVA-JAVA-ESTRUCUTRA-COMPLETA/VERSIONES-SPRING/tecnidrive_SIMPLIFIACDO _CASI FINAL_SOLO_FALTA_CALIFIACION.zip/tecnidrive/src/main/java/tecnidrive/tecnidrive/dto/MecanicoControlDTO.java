package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

// Datos de UNA cita para la pantalla de MANTENIMIENTO del mecánico
// (en_atencion / en_cierre / finalizada)
@Getter
@Setter
@NoArgsConstructor
public class MecanicoControlDTO {

    private Integer idCita;
    private Integer idSeguimiento;
    private LocalDateTime fechaCita;
    private LocalDateTime fechaRegistro;
    private LocalDate fechaInicioAtencion;

    private String clienteNombre;
    private String clienteApellido;
    private Long telefonoPropietario;

    private String placa;
    private String nombreMarca;
    private String nombreModelo;
    private String modelYear;
    private String textoTipoVehi;

    private String problemaContexto;
    private List<ServicioPrecioDTO> servicios;

    private String estadoMantenimiento;
    private List<TecnicoDTO> tecnicosAsignados;

    private String observacionesTecnico;
    private String textoGarantia;
    private LocalDateTime garantiaVigencia;
    private BigDecimal precioTotal;
}