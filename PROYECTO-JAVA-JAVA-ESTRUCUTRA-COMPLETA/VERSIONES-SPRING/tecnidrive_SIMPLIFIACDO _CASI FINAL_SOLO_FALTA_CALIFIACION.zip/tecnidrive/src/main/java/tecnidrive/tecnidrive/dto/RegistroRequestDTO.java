package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

// CORRECCIÓN: ya no es un "record". Un record no tiene getters/setters
// tradicionales (getPrimerNombre(), setPrimerNombre()), y Thymeleaf
// necesita esos métodos para poder usar th:field en el formulario.
public class RegistroRequestDTO {

    @NotBlank(message = "El primer nombre es obligatorio")
    @Pattern(regexp = "^[\\p{L} ]+$", message = "El nombre no debe contener números")
    private String primerNombre;

    // Opcional: puede venir vacío, pero si trae algo, tampoco debe tener números
    @Pattern(regexp = "^[\\p{L} ]*$", message = "El nombre no debe contener números")
    private String segundoNombre;

    @NotBlank(message = "El primer apellido es obligatorio")
    @Pattern(regexp = "^[\\p{L} ]+$", message = "El apellido no debe contener números")
    private String primerApellido;

    @NotBlank(message = "El segundo apellido es obligatorio")
    @Pattern(regexp = "^[\\p{L} ]+$", message = "El apellido no debe contener números")
    private String segundoApellido;

    // CORRECCIÓN: el teléfono ahora se valida aquí con una expresión regular
    // (solo números, entre 7 y 10 dígitos), así el Controller ya no necesita
    // hacer try/catch para convertirlo
    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = "^[0-9]{7,10}$", message = "El teléfono debe tener 10 números")
    private String telefono;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "El correo no tiene un formato válido")
    private String email;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String password;

    // Getters y setters (los necesita Thymeleaf y Spring para leer/escribir el formulario)

    public String getPrimerNombre() { return primerNombre; }
    public void setPrimerNombre(String primerNombre) { this.primerNombre = primerNombre; }

    public String getSegundoNombre() { return segundoNombre; }
    public void setSegundoNombre(String segundoNombre) { this.segundoNombre = segundoNombre; }

    public String getPrimerApellido() { return primerApellido; }
    public void setPrimerApellido(String primerApellido) { this.primerApellido = primerApellido; }

    public String getSegundoApellido() { return segundoApellido; }
    public void setSegundoApellido(String segundoApellido) { this.segundoApellido = segundoApellido; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}