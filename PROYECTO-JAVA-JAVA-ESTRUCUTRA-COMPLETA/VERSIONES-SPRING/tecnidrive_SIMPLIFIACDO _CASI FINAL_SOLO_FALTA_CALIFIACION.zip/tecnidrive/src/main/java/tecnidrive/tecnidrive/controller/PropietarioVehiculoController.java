package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.VehiculoDTO;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.ServicioVehiculoRepository;
import tecnidrive.tecnidrive.repository.TipoVehiculoRepository;
import tecnidrive.tecnidrive.service.PropietarioService;
import tecnidrive.tecnidrive.service.PropietarioVehiculoService;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PropietarioVehiculoController {

    @Autowired
    private PropietarioService propietarioService;

    // CORRECCIÓN: tipo y nombre actualizados
    @Autowired
    private PropietarioVehiculoService propietarioVehiculoService;

    @Autowired
    private TipoVehiculoRepository tipoVehiculoRepository;

    @Autowired
    private ServicioVehiculoRepository servicioVehiculoRepository;

    @GetMapping("/propietario/vehiculo")
    public String verVehiculos(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "errorVehiculo", required = false) String errorVehiculo,
            @RequestParam(value = "vehiculoGuardado", required = false) String vehiculoGuardado,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        boolean tieneLicencia = propietarioService.tieneLicencia(idPersona);
        model.addAttribute("tieneLicencia", tieneLicencia);

        if (tieneLicencia) {
            Propietario propietario = propietarioService.obtenerPorId(idPersona);
            model.addAttribute("numeroLicencia", propietario.getNumeroLicencia());
            model.addAttribute("misCategorias", propietarioService.obtenerCategoriasVigentes(idPersona));

            List<VehiculoDTO> misVehiculos = propietarioVehiculoService.obtenerVistaPorPropietario(idPersona);
            model.addAttribute("misVehiculos", misVehiculos);

            Map<String, Map<Integer, PapelVehiculo>> misDocumentos = new HashMap<>();
            for (VehiculoDTO v : misVehiculos) {
                List<PapelVehiculo> docs = propietarioVehiculoService.obtenerDocumentosDeVehiculo(v.getPlaca());
                Map<Integer, PapelVehiculo> mapaPorTipo = new HashMap<>();
                for (PapelVehiculo doc : docs) {
                    mapaPorTipo.put(doc.getTipoDocumento().getIdDocumento(), doc);
                }
                misDocumentos.put(v.getPlaca(), mapaPorTipo);
            }
            model.addAttribute("misDocumentos", misDocumentos);
        }

        if (error != null) model.addAttribute("error", "Revisa los datos de la licencia.");
        if (errorVehiculo != null) model.addAttribute("errorVehiculo", "Revisa los datos del vehículo.");
        if (vehiculoGuardado != null) model.addAttribute("vehiculoGuardado", true);

        return "propietario/propietario-vehiculo";
    }

   @PostMapping("/propietario/guardar-licencia")
public String guardarLicencia(
        @RequestParam("numero_licencia") String numeroLicencia,
        @RequestParam("categoria[]") String[] categorias,
        @RequestParam("fecha[]") String[] fechas,
        HttpSession session) {

    Integer idPersona = (Integer) session.getAttribute("idPersona");
    if (idPersona == null) return "redirect:/login";

    try {
        propietarioService.guardarLicencia(idPersona, numeroLicencia.trim(), categorias, fechas);
        return "redirect:/propietario/vehiculo";
    } catch (IllegalArgumentException e) {
        // CORRECCIÓN: en vez de dejar que la excepción llegue sin control
        // (pantalla de error 500), redirigimos con un mensaje claro
        return "redirect:/propietario/vehiculo?error=" + e.getMessage();
    }
}

    @PostMapping("/propietario/guardar-vehiculo")
    public String guardarVehiculo(
            @RequestParam("placa") String placa,
            @RequestParam("marca") String marca,
            @RequestParam("modelo") String modelo,
            @RequestParam("ano") String anio,
            @RequestParam("tipo_vehi") Integer idTipoVehi,
            @RequestParam("tipo_servicio") Integer idTipoServicio,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        String placaLimpia = placa.trim().toUpperCase();

        if (propietarioVehiculoService.existePlaca(placaLimpia)) {
            return "redirect:/propietario/vehiculo?errorVehiculo=placa-duplicada";
        }

        Propietario propietario = propietarioService.obtenerPorId(idPersona);
        TipoVehiculo tipoVehiculo = tipoVehiculoRepository.findById(idTipoVehi)
                .orElseThrow(() -> new RuntimeException("Tipo de vehículo no encontrado"));
        ServicioVehiculo servicioVehiculo = servicioVehiculoRepository.findById(idTipoServicio)
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

        propietarioVehiculoService.registrarVehiculo(
                placaLimpia, anio.trim(), idTipoVehi, idTipoServicio,
                marca, modelo, propietario, tipoVehiculo, servicioVehiculo
        );

        return "redirect:/propietario/vehiculo?vehiculoGuardado=1";
    }

    @PostMapping("/propietario/activar-vehiculo")
    public String activarVehiculo(@RequestParam("placa") String placa, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Vehiculo vehiculo = propietarioVehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo != null) {
            propietarioVehiculoService.activar(vehiculo);
        }

        return "redirect:/propietario/vehiculo";
    }

    @PostMapping("/propietario/desactivar-vehiculo")
    public String desactivarVehiculo(
            @RequestParam("placa") String placa,
            @RequestParam("motivo") String motivo,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        if (motivo == null || motivo.isBlank()) {
            return "redirect:/propietario/vehiculo?errorVehiculo=motivo-requerido";
        }

        Vehiculo vehiculo = propietarioVehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo != null) {
            propietarioVehiculoService.desactivar(vehiculo, motivo.trim());
        }

        return "redirect:/propietario/vehiculo";
    }

    @PostMapping("/propietario/guardar-documentos")
    public String guardarDocumentos(
            @RequestParam("placa") String placa,
            @RequestParam(value = "soat", required = false) String soat,
            @RequestParam(value = "tecnomecanica", required = false) String tecno,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Vehiculo vehiculo = propietarioVehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo == null) return "redirect:/propietario/vehiculo";

        if (soat != null && !soat.isBlank()) {
            propietarioVehiculoService.guardarDocumento(vehiculo, 1, LocalDate.parse(soat));
        }
        if (tecno != null && !tecno.isBlank()) {
            propietarioVehiculoService.guardarDocumento(vehiculo, 2, LocalDate.parse(tecno));
        }

        return "redirect:/propietario/vehiculo";
    }
}