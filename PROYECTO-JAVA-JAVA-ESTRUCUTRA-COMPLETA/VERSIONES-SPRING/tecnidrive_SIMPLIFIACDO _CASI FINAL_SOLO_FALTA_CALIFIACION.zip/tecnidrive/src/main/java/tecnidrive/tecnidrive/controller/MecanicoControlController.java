package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.MecanicoControlDTO;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.service.GestionMantenimientoService;
import tecnidrive.tecnidrive.service.MecanicoTallerService;
import tecnidrive.tecnidrive.service.TecnicoService;

import java.util.List;

@Controller
public class MecanicoControlController {

    @Autowired
    private MecanicoTallerService mecanicoTallerService;

    @Autowired
    private GestionMantenimientoService gestionMantenimientoService;

    @Autowired
    private TecnicoService tecnicoService;

    // FLUJO:
    // 1. Verificamos que el mecánico tenga taller.
    // 2. Listamos sus citas en atención/en_cierre/finalizada.
    // 3. Listamos sus técnicos, para el panel lateral y el checklist de cierre.
    @GetMapping("/mecanico/control")
    public String verControl(
            @RequestParam(value = "exito", required = false) String exito,
            @RequestParam(value = "error", required = false) String error,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        List<MecanicoControlDTO> citas = gestionMantenimientoService.listarEnAtencion(taller.getIdTaller());
        model.addAttribute("citas", citas);
        model.addAttribute("tecnicos", tecnicoService.listarPorTaller(taller.getIdTaller()));

        if (exito != null) model.addAttribute("exito", "Acción realizada correctamente.");
        if (error != null) model.addAttribute("error", traducirError(error));

        return "mecanico/mecanico-control";
    }

    @PostMapping("/mecanico/control/agregar-tecnico")
    public String agregarTecnico(@RequestParam("nombre_tecnico") String nombre, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        if (nombre == null || nombre.isBlank()) {
            return "redirect:/mecanico/control?error=nombre-requerido";
        }

        tecnicoService.agregar(taller, nombre);
        return "redirect:/mecanico/control?exito=1";
    }

    @PostMapping("/mecanico/control/eliminar-tecnico")
    public String eliminarTecnico(@RequestParam("id_tecnico") Integer idTecnico, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        try {
            tecnicoService.eliminar(idTecnico, taller.getIdTaller());
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=" + e.getMessage();
        }
    }

    @PostMapping("/mecanico/control/cerrar")
    public String cerrar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("id_seguimiento") Integer idSeguimiento,
            @RequestParam(value = "observaciones", required = false) String observaciones,
            @RequestParam(value = "texto_garantia", required = false) String textoGarantia,
            @RequestParam(value = "garantia_vigencia", required = false) String garantiaVigencia,
            @RequestParam("precio_total") String precioTotal,
            @RequestParam(value = "tecnicos[]", required = false) List<Integer> tecnicos,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        try {
            gestionMantenimientoService.cerrarMantenimiento(
                    idCita, idSeguimiento, taller.getIdTaller(),
                    observaciones, textoGarantia, garantiaVigencia, precioTotal, tecnicos
            );
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=" + e.getMessage();
        }
    }

    @PostMapping("/mecanico/control/verificar-entrega")
    public String verificarEntrega(@RequestParam("codigo") String codigo, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = mecanicoTallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        try {
            gestionMantenimientoService.verificarEntrega(codigo, taller.getIdTaller());
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=" + e.getMessage();
        }
    }

    private String traducirError(String codigo) {
        return switch (codigo) {
            case "nombre-requerido" -> "Escribe un nombre para el técnico.";
            case "tecnico-invalido" -> "El técnico seleccionado no pertenece a tu taller.";
            case "cita-invalida" -> "La cita seleccionada no es válida.";
            case "gestion-invalida" -> "El registro de mantenimiento no es válido.";
            case "precio-requerido" -> "Debes indicar el precio total del servicio.";
            case "tecnicos-requeridos" -> "Selecciona al menos un técnico que realizó el trabajo.";
            case "codigo-invalido" -> "Código incorrecto o la cita no está lista para entrega.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
}