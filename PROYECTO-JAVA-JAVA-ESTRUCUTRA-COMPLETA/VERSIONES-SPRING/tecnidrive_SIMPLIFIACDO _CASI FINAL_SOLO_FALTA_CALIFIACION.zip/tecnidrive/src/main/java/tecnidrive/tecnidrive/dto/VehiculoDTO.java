package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// CORRECCIÓN: renombrado de VehiculoVista a VehiculoDTO.
// "Aplana" los datos del Vehiculo para que la plantilla pueda leer
// directamente v.nombreMarca, v.nombreModelo, etc., sin navegar
// relaciones anidadas (v.modelo.marca.nombreMarca)
@Getter
@Setter
@NoArgsConstructor
public class VehiculoDTO {
    private String placa;
    private String modelYear;
    private Boolean estadoVehi;
    private String motivoEstado;
    private Integer tiposVehiculoIdTipoVehi;
    private Integer servicioVehiculoIdTipoServicio;
    private String nombreMarca;
    private String nombreModelo;

    // PENDIENTE: siempre en false hasta construir el módulo de Citas
    private Boolean tieneCitaActiva = false;
}