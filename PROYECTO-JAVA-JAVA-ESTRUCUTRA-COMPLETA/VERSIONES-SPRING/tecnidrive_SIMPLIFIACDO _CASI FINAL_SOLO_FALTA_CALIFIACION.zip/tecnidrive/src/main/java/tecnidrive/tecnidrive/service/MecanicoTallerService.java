package tecnidrive.tecnidrive.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Servicio;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.model.TallerHasServicio;
import tecnidrive.tecnidrive.model.TallerHasServicioId;
import tecnidrive.tecnidrive.repository.EspecialidadRepository;
import tecnidrive.tecnidrive.repository.ServicioRepository;
import tecnidrive.tecnidrive.repository.TallerHasServicioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;

// CORRECCIÓN: renombrado de TallerService. Se queda únicamente con lo
// que usa el mecánico (registrar y ver su propio taller). El método
// listarActivosParaPropietario() se movió a un TallerService reducido,
// que pertenece a otro módulo (propietario viendo talleres)
@Service
public class MecanicoTallerService {

    private static final String CARPETA_FOTOS = "uploads/talleres";

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private EspecialidadRepository especialidadRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    public Taller obtenerTallerDelMecanico(Integer idMecanico) {
        List<Taller> talleres = tallerRepository.findByMecanico_IdPersona(idMecanico);
        return talleres.isEmpty() ? null : talleres.get(0);
    }

    public String construirHorarioTexto(String[] dias, String[] horas) {
        StringBuilder horario = new StringBuilder();

        for (int i = 0; i < dias.length; i++) {
            String dia = dias[i] == null ? "" : dias[i].trim();
            if (dia.isEmpty()) continue;

            String hora = (horas.length > i && horas[i] != null) ? horas[i].trim() : "";

            if (horario.length() > 0) {
                horario.append(" | ");
            }
            horario.append(dia).append(": ").append(hora);
        }

        String texto = horario.toString();
        return texto.length() > 150 ? texto.substring(0, 150) : texto;
    }

    @Transactional
    public void registrarTaller(
            Taller taller,
            String nombreEspecialidad,
            String[] nombresServicios,
            String[] precios,
            MultipartFile foto) {

        String nombreFoto = null;
        if (foto != null && !foto.isEmpty()) {
            nombreFoto = guardarFoto(foto, taller.getMecanico().getIdPersona());
            taller.setFotoTaller(nombreFoto);
        }

        try {
            Especialidad especialidad = buscarOCrearEspecialidad(nombreEspecialidad);

            HashSet<Especialidad> especialidades = new HashSet<>();
            especialidades.add(especialidad);
            taller.setEspecialidades(especialidades);

            Taller tallerGuardado = tallerRepository.save(taller);

            for (int i = 0; i < nombresServicios.length; i++) {
                String nombreServicio = nombresServicios[i] == null ? "" : nombresServicios[i].trim();
                if (nombreServicio.isEmpty()) continue;

                Servicio servicio = buscarOCrearServicio(nombreServicio);
                BigDecimal precio = convertirPrecio(precios[i]);

                TallerHasServicio relacion = new TallerHasServicio();
                TallerHasServicioId id = new TallerHasServicioId();
                id.setIdTaller(tallerGuardado.getIdTaller());
                id.setIdServicio(servicio.getIdServicio());
                relacion.setId(id);
                relacion.setPrecioServicio(precio);

                tallerHasServicioRepository.save(relacion);
            }

        } catch (RuntimeException e) {
            if (nombreFoto != null) {
                borrarFoto(nombreFoto);
            }
            throw e;
        }
    }

    private String guardarFoto(MultipartFile foto, Integer idMecanico) {

        String tipo = foto.getContentType();
        if (tipo == null || !(tipo.equals("image/jpeg") || tipo.equals("image/png") || tipo.equals("image/webp"))) {
            throw new IllegalArgumentException("Solo se permiten imágenes JPG, PNG o WEBP");
        }

        if (foto.getSize() > 2_000_000) {
            throw new IllegalArgumentException("La imagen no puede superar 2MB");
        }

        String extension = tipo.equals("image/png") ? "png" : tipo.equals("image/webp") ? "webp" : "jpg";
        String nombreFoto = "taller_" + idMecanico + "_" + System.currentTimeMillis() + "." + extension;

        try {
            Path carpeta = Paths.get(CARPETA_FOTOS);
            Files.createDirectories(carpeta);
            foto.transferTo(carpeta.resolve(nombreFoto));
        } catch (IOException e) {
            throw new RuntimeException("No se pudo guardar la imagen", e);
        }

        return nombreFoto;
    }

    private void borrarFoto(String nombreFoto) {
        try {
            Files.deleteIfExists(Paths.get(CARPETA_FOTOS, nombreFoto));
        } catch (IOException ignored) {
        }
    }

    private Especialidad buscarOCrearEspecialidad(String nombre) {
        return especialidadRepository.findAll().stream()
                .filter(e -> e.getNombreEspecialidad().equalsIgnoreCase(nombre))
                .findFirst()
                .orElseGet(() -> {
                    Especialidad nueva = new Especialidad();
                    nueva.setNombreEspecialidad(nombre);
                    return especialidadRepository.save(nueva);
                });
    }

    private Servicio buscarOCrearServicio(String nombre) {
        return servicioRepository.findAll().stream()
                .filter(s -> s.getNombreServicio().equalsIgnoreCase(nombre))
                .findFirst()
                .orElseGet(() -> {
                    Servicio nuevo = new Servicio();
                    nuevo.setNombreServicio(nombre);
                    return servicioRepository.save(nuevo);
                });
    }

    private BigDecimal convertirPrecio(String precioTexto) {
        String limpio = precioTexto
                .replace("$", "")
                .replace(".", "")
                .replace(",", ".")
                .trim();

        return limpio.isEmpty() ? BigDecimal.ZERO : new BigDecimal(limpio);
    }

    public List<ServicioPrecioDTO> obtenerServiciosDelTaller(Integer idTaller) {
        List<TallerHasServicio> relaciones = tallerHasServicioRepository.findById_IdTaller(idTaller);
        List<ServicioPrecioDTO> resultado = new ArrayList<>();

        for (TallerHasServicio relacion : relaciones) {
            Servicio servicio = servicioRepository.findById(relacion.getId().getIdServicio())
                    .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

            resultado.add(new ServicioPrecioDTO(
                    servicio.getIdServicio(),
                    servicio.getNombreServicio(),
                    relacion.getPrecioServicio()
            ));
        }

        return resultado;
    }
}