package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.repository.PersonaRepository;

import java.time.LocalDateTime;
import java.util.Optional;

// CORRECCIÓN: se quitaron listarTodos(), guardar(), eliminar() y el
// actualizar() genérico — no los usaba ningún módulo del proyecto.
// Este service quedó enfocado en lo que realmente hace hoy: apoyar
// la recuperación de contraseña, más la consulta que usa el panel de admin
@Service
public class PersonaService {

    @Autowired
    private PersonaRepository personaRepository;

// Usado por PanelesController, en el panel de admin
    public Persona obtenerPorId(Integer id) {
        return personaRepository.findById(id).orElse(null);
    }

// Usado por RecuperarService (paso 1: buscar la cuenta por correo)
    public Optional<Persona> buscarPorEmail(String email) {
        return personaRepository.findByEmail(email);
    }

// Usado por RecuperarService (paso 1: guardar el código de 6 dígitos)
    public void guardarCodigoRecuperacion(Integer id, String codigo, LocalDateTime expiracion) {
        Persona persona = personaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));
        persona.setCodigoRecuperacion(codigo);
        persona.setFechaExpiracion(expiracion);
        personaRepository.save(persona);
    }

// Usado por RecuperarService (paso 2: código verificado, ya no sirve, se limpia)
    public void limpiarCodigoRecuperacion(Integer id) {
        Persona persona = personaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));
        persona.setCodigoRecuperacion(null);
        persona.setFechaExpiracion(null);
        personaRepository.save(persona);
    }

// Usado por RecuperarService (paso 3: guardar la nueva contraseña ya encriptada)
    public void actualizarPassword(Integer id, String passwordHashNuevo) {
        Persona persona = personaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));
        persona.setPasswordHash(passwordHashNuevo);
        personaRepository.save(persona);
    }
}