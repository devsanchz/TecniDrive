package tecnidrive.tecnidrive.dto;

import java.math.BigDecimal;

public record ServicioPrecioDTO(
        Integer serviciosIdServicio,
        String nombreServicio,
        BigDecimal precioServicio
) {
}