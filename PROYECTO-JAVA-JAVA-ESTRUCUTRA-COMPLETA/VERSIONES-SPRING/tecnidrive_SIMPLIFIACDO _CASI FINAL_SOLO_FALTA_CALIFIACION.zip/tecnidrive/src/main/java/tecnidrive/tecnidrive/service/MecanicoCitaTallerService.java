package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tecnidrive.tecnidrive.dto.MecanicoCitaDTO;
import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.*;

import java.util.ArrayList;
import java.util.List;

@Service
public class MecanicoCitaTallerService {

    @Autowired
    private CitaTallerRepository citaTallerRepository;

    @Autowired
    private CitaHasServicioRepository citaHasServicioRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    // CORRECCIÓN: tipo de retorno actualizado a MecanicoCitaDTO
    public List<MecanicoCitaDTO> listarCitasDelTaller(Integer idTaller) {
    // CORRECCIÓN: excluimos "en_atencion" — esas citas ya se gestionan
    // desde /mecanico/control, no tiene sentido que sigan apareciendo
    // también aquí en la agenda inicial
    List<CitaTaller> citas = citaTallerRepository.findByTaller_IdTallerOrderByFechaCitaDesc(idTaller)
            .stream()
            .filter(c -> c.getEstadoCita() != EstadoCita.en_atencion)
            .toList();

    List<MecanicoCitaDTO> resultado = new ArrayList<>();

    for (CitaTaller cita : citas) {
        MecanicoCitaDTO vista = new MecanicoCitaDTO();
        vista.setIdCita(cita.getIdCita());
        vista.setFechaCita(cita.getFechaCita());
        vista.setFechaRegistro(cita.getFechaRegistro());
        vista.setEstadoCita(cita.getEstadoCita().name());
        vista.setClaseEstado(cita.getEstadoCita().getClase());
        vista.setTextoEstado(cita.getEstadoCita().getTexto());
        vista.setCodigoConfirmacion(cita.getCodigoConfirmacion());
        vista.setProblemaContexto(cita.getProblemaContexto());
        vista.setMotivoCancelacion(cita.getMotivoCancelacion());

        Vehiculo vehiculo = cita.getVehiculo();
        vista.setPlaca(vehiculo.getPlaca());
        vista.setModelYear(vehiculo.getModelYear());
        vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
        vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
        vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

        Propietario propietario = vehiculo.getPropietario();
        vista.setClienteNombre(propietario.getPrimerNombre());
        vista.setClienteApellido(propietario.getPrimerApellido());
        vista.setTelefonoPropietario(propietario.getTelefonoPropietario());

        vista.setServicios(obtenerServiciosConPrecio(cita));
        resultado.add(vista);
    }

    return resultado;
}

    @Transactional
    public void confirmarCita(Integer idCita, Integer idTaller) {
        CitaTaller cita = obtenerSiEsDelTaller(idCita, idTaller);

        if (cita.getEstadoCita() != EstadoCita.pendiente) {
            throw new IllegalArgumentException("cita-no-confirmable");
        }

        cita.setEstadoCita(EstadoCita.confirmada);
        cita.setCodigoConfirmacion(generarCodigo());
        citaTallerRepository.save(cita);
    }

    @Transactional
    public void cancelarCita(Integer idCita, Integer idTaller, String motivo) {
        CitaTaller cita = obtenerSiEsDelTaller(idCita, idTaller);

        if (cita.getEstadoCita() != EstadoCita.pendiente
                && cita.getEstadoCita() != EstadoCita.confirmada) {
            throw new IllegalArgumentException("cita-no-cancelable");
        }

        cita.setEstadoCita(EstadoCita.cancelada_mecanico);
        cita.setMotivoCancelacion(motivo);
        citaTallerRepository.save(cita);
    }

    @Transactional
    public void verificarCodigoIniciarAtencion(String codigo, Integer idTaller) {
        String codigoNormalizado = codigo.trim().toUpperCase();

        CitaTaller cita = citaTallerRepository.findAll().stream()
                .filter(c -> codigoNormalizado.equals(c.getCodigoConfirmacion()))
                .filter(c -> c.getEstadoCita() == EstadoCita.confirmada)
                .filter(c -> c.getTaller().getIdTaller().equals(idTaller))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("codigo-invalido"));

        cita.setEstadoCita(EstadoCita.en_atencion);
        cita.setFechaInicioAtencion(java.time.LocalDate.now());
        citaTallerRepository.save(cita);
    }

    private CitaTaller obtenerSiEsDelTaller(Integer idCita, Integer idTaller) {
        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (!cita.getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        return cita;
    }

    private List<ServicioPrecioDTO> obtenerServiciosConPrecio(CitaTaller cita) {
        List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
        List<ServicioPrecioDTO> servicios = new ArrayList<>();

        for (CitaHasServicio rel : relaciones) {
            Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
            if (servicio == null) continue;

            TallerHasServicioId thsId = new TallerHasServicioId();
            thsId.setIdTaller(rel.getId().getIdTaller());
            thsId.setIdServicio(rel.getId().getIdServicio());

            java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
                    .map(TallerHasServicio::getPrecioServicio)
                    .orElse(java.math.BigDecimal.ZERO);

            servicios.add(new ServicioPrecioDTO(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
        }

        return servicios;
    }

    private String generarCodigo() {
        byte[] bytesAleatorios = new byte[5];
        new java.security.SecureRandom().nextBytes(bytesAleatorios);
        StringBuilder hex = new StringBuilder();
        for (byte b : bytesAleatorios) {
            hex.append(String.format("%02x", b));
        }
        return hex.substring(0, 8).toUpperCase();
    }
}