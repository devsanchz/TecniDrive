package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.CodigoRecuperacionDTO;
import tecnidrive.tecnidrive.dto.EmailRecuperacionDTO;
import tecnidrive.tecnidrive.dto.NuevaPasswordDTO;
import tecnidrive.tecnidrive.service.RecuperarService;

// CORRECCIÓN: de @RestController con JSON a @Controller tradicional,
// con un flujo de 3 pasos guiado por la sesión
@Controller
@RequestMapping("/recuperar")
public class RecuperarController {

    @Autowired
    private RecuperarService recuperarService;

// METODO 1:Mostramos el formulario de la plantilla para el correo
    @GetMapping
    public String mostrarPaso1(Model model) {
        model.addAttribute("datos", new EmailRecuperacionDTO());
        return "recuperar-email";
    }

    // FLUJO PASO 1:
    // 1. Validamos el formato del correo.
    // 2. Enviamos el código (exista o no el correo, sin revelar cuál es el caso).
    // 3. Guardamos el correo en sesión para los siguientes pasos.

// METODO 2: validamos el correo puesto si es correcto pasa al metodo 3
    @PostMapping
    public String procesarPaso1(
            @Valid @ModelAttribute("datos") EmailRecuperacionDTO datos,
            BindingResult resultado,
            HttpSession session) {

        if (resultado.hasErrors()) {
            return "recuperar-email";
        }

        recuperarService.enviarCodigo(datos.getEmail());
        session.setAttribute("recuperarEmail", datos.getEmail());

        return "redirect:/recuperar/verificar";
    }

// METODO 3:Mostramos el formulario para verificar el codigo 
    @GetMapping("/verificar")
    public String mostrarPaso2(HttpSession session, Model model) {

        if (session.getAttribute("recuperarEmail") == null) {
            return "redirect:/recuperar";
        }

        model.addAttribute("datos", new CodigoRecuperacionDTO());
        return "recuperar-codigo";
    }

 //METODO 4: 1. Validamos el código contra el que se guardó al enviarlo.
 // // 2. Si es correcto, guardamos el id de la persona en sesión y pasamos al metodo 5.
    @PostMapping("/verificar")
    public String procesarPaso2(
            @Valid @ModelAttribute("datos") CodigoRecuperacionDTO datos,
            BindingResult resultado,
            HttpSession session,
            Model model) {

        if (resultado.hasErrors()) {
            return "recuperar-codigo";
        }

        String email = (String) session.getAttribute("recuperarEmail");
        if (email == null) {
            return "redirect:/recuperar";
        }

        try {
            Integer idPersona = recuperarService.verificarCodigo(email, datos.getCodigo());
            session.setAttribute("recuperarId", idPersona);
            session.removeAttribute("recuperarEmail");
            return "redirect:/recuperar/nueva-clave";

        } catch (RuntimeException e) {
            model.addAttribute("errorCodigo", e.getMessage());
            return "recuperar-codigo";
        }
    }

//METODO 5: Mostramos el formulario para actualizar la contraseña
    @GetMapping("/nueva-clave")
    public String mostrarPaso3(HttpSession session, Model model) {

        if (session.getAttribute("recuperarId") == null) {
            return "redirect:/recuperar";
        }

        model.addAttribute("datos", new NuevaPasswordDTO());
        return "recuperar-clave";
    }

//Metodo 6: 1. Validamos formato de la contraseña (@Valid).
// 2. Validamos que coincida con la confirmación.
// 3. Guardamos la nueva contraseña encriptada y cerramos el proceso.
    @PostMapping("/nueva-clave")
    public String procesarPaso3(
            @Valid @ModelAttribute("datos") NuevaPasswordDTO datos,
            BindingResult resultado,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("recuperarId");
        if (idPersona == null) {
            return "redirect:/recuperar";
        }

        if (!datos.getPassword().equals(datos.getRepassword())) {
            resultado.rejectValue("repassword", "no.coincide", "Las contraseñas no coinciden");
        }

        if (resultado.hasErrors()) {
            return "recuperar-clave";
        }

        recuperarService.actualizarPassword(idPersona, datos.getPassword());
        session.removeAttribute("recuperarId");

        return "redirect:/login?recuperacion=exitoso";
    }
}