package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Taller;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class PropietarioTallerDTO {

    private Integer idTaller;
    private String nombreTaller;
    private String descripcionTaller;
    private String direccionTaller;
    private String fotoTaller;
    private List<Especialidad> especialidades;
    private List<ServicioPrecioDTO> servicios;
    private List<Taller.HorarioBloque> horarios;
}