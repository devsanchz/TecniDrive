package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

// Datos de UNA cita para la vista del MECÁNICO (agenda inicial: pendiente,
// confirmada, en_atencion, cancelada). No incluye datos de mantenimiento
// (garantía, técnicos, precio final) — eso es para el módulo de mantenimiento
@Getter
@Setter
@NoArgsConstructor
public class MecanicoCitaDTO {

    private Integer idCita;
    private LocalDateTime fechaCita;
    private LocalDateTime fechaRegistro;
    private String estadoCita;
    private String claseEstado;
    private String textoEstado;
    private String codigoConfirmacion;
    private String problemaContexto;
    private String motivoCancelacion;

    private String clienteNombre;
    private String clienteApellido;
    private Long telefonoPropietario;

    private String placa;
    private String nombreMarca;
    private String nombreModelo;
    private String modelYear;
    private String textoTipoVehi;

    private List<ServicioPrecioDTO> servicios;
}