// Funciones del modal, ya existían en tu HTML original con onclick="abrirModal()"
function abrirModal() {
    document.getElementById('modalPlanes').style.display = 'flex';
}

function cerrarModal() {
    document.getElementById('modalPlanes').style.display = 'none';
}