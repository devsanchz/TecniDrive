 function toggleCancelar(idCita) {
            const form = document.getElementById('formulario-' + idCita);
            form.classList.toggle('mostrar');
        }