// ── Toggle formulario de cancelación ─────────────────────────────────────
function toggleCancelar(idCita) {
    const form = document.getElementById('formulario-' + idCita);
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

// ── Toggle panel verificar código ────────────────────────────────────────
const btnVerificar  = document.getElementById('btnVerificar');
const formVerificar = document.getElementById('formVerificar');

btnVerificar.addEventListener('click', (e) => {
    e.stopPropagation();
    formVerificar.classList.toggle('mostrar');
});

document.addEventListener('click', (e) => {
    if (!btnVerificar.contains(e.target) && !formVerificar.contains(e.target)) {
        formVerificar.classList.remove('mostrar');
    }
});

// ── Filtro por estado ─────────────────────────────────────────────────────
document.getElementById('filtroEstado').addEventListener('change', function () {
    const valor    = this.value;
    const casillas = document.querySelectorAll('.casilla');

    casillas.forEach(casilla => {
        const estado = casilla.dataset.estado;
        casilla.style.display = (valor === 'todos' || estado === valor) ? '' : 'none';
    });
});