document.addEventListener("DOMContentLoaded", () => {

    const backdrop = document.getElementById("modalBackdrop");

    // ── Cerrar tarjeta ────────────────────────────────────────────────────
    function cerrarTarjeta(card) {
        const vistaCompacta = card.querySelector(".vista-compacta");
        const contenido     = card.querySelector(".contenido-taller");
        contenido.classList.remove("visible");
        card.classList.replace("expandida", "compacta");
        backdrop.classList.remove("activo");
        setTimeout(() => vistaCompacta.classList.remove("oculto"), 200);
    }

    // ── Expandir / colapsar cada tarjeta de taller ─────────────────────────
    document.querySelectorAll(".card-taller").forEach((card) => {
        const header        = card.querySelector(".header-taller");
        const btnCerrar     = card.querySelector(".btn-cerrar");
        const vistaCompacta = card.querySelector(".vista-compacta");
        const contenido     = card.querySelector(".contenido-taller");

        header.addEventListener("click", (e) => {
            if (e.target.closest(".btn-cerrar")) return;
            if (card.classList.contains("compacta")) {
                vistaCompacta.classList.add("oculto");
                card.classList.replace("compacta", "expandida");
                backdrop.classList.add("activo");
                setTimeout(() => contenido.classList.add("visible"), 80);
            }
        });

        btnCerrar.addEventListener("click", (e) => {
            e.stopPropagation();
            cerrarTarjeta(card);
        });
    });

    backdrop?.addEventListener("click", () => {
        const abierta = document.querySelector(".card-taller.expandida");
        if (abierta) cerrarTarjeta(abierta);
    });

    // ── Buscador y filtro por especialidad ─────────────────────────────────
    const buscador = document.querySelector(".buscador-wrapper input");
    const filtro    = document.getElementById("filtroEspecialidad");

    function filtrarTarjetas() {
        const texto = buscador?.value.toLowerCase() ?? "";
        const esp   = filtro?.value ?? "todos";

        document.querySelectorAll(".card-taller").forEach(card => {
            const nombre       = card.dataset.nombre       ?? "";
            const direccion    = card.dataset.direccion    ?? "";
            const especialidad = card.dataset.especialidad ?? "";

            const coincideTexto = texto === "" ||
                nombre.includes(texto) || direccion.includes(texto) ||
                especialidad.toLowerCase().includes(texto);
            const coincideEsp = esp === "todos" || especialidad === esp;

            card.style.display = (coincideTexto && coincideEsp) ? "" : "none";
        });
    }

    buscador?.addEventListener("input", filtrarTarjetas);
    filtro?.addEventListener("change", filtrarTarjetas);
});