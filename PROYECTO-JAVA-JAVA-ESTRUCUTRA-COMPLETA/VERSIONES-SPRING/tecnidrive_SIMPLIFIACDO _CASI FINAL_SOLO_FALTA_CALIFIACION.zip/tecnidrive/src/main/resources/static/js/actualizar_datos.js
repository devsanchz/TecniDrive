document.addEventListener("DOMContentLoaded", () => {

    const editButton   = document.getElementById("editButton");
    const saveButton   = document.getElementById("saveButton");

    const userEmail  = document.getElementById("userEmail");
    const emailInput = document.getElementById("emailInput");

    const userTelefono  = document.getElementById("usertelefono");
    const telefonoInput = document.getElementById("telefonoInput");

    const colorEditor   = document.getElementById("colorEditor");
    const avatarColor   = document.getElementById("avatarColor");
    const profileAvatar = document.getElementById("profileAvatar");
    const profileIcon   = document.getElementById("profileIcon");

    // FLUJO: al hacer clic en "Editar", mostramos los inputs y ocultamos
    // el texto de solo lectura — igual que antes, sin ningún cambio
    function activarModoEdicion() {
        userEmail.style.display     = "none";
        emailInput.style.display    = "inline-block";

        userTelefono.style.display  = "none";
        telefonoInput.style.display = "inline-block";

        colorEditor.style.display   = "block";

        editButton.style.display = "none";
        saveButton.style.display = "inline-block";
    }

    editButton.addEventListener("click", activarModoEdicion);

    // Cambio de color en vivo, mientras el usuario mueve el selector —
    // esto es solo visual, no necesita servidor
    avatarColor.addEventListener("input", () => {
        profileAvatar.style.borderColor = avatarColor.value;
        profileIcon.style.color = avatarColor.value;
    });

    // AGREGADO: si el formulario volvió con errores (por ejemplo, email
    // mal escrito), activamos el modo edición automáticamente, para que
    // el usuario vea el error directamente en el campo, sin tener que
    // darle clic a "Editar" primero
    const hayErrores = document.querySelector(".error-campo");
    if (hayErrores) {
        activarModoEdicion();
    }

    // CORRECCIÓN: se eliminó por completo saveButton.addEventListener con
    // fetch, guardarPerfil(), CSRF y el manejo de "data.ok"/"data.errores".
    // El botón "Listo" ahora es type="submit": el navegador envía el
    // formulario directo al Controller, sin JavaScript de por medio
});