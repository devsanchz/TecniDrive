package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.ActualizarPerfilDTO;
import tecnidrive.tecnidrive.model.Mecanico;
import tecnidrive.tecnidrive.model.Propietario;
import tecnidrive.tecnidrive.service.MecanicoService;
import tecnidrive.tecnidrive.service.PropietarioService;

import java.util.HashMap;
import java.util.Map;

@RestController
public class PerfilController {

    @Autowired
    private PropietarioService propietarioService;

    @Autowired
    private MecanicoService mecanicoService;

    @PostMapping("/api/propietario/perfil/actualizar")
    public ResponseEntity<Map<String, Object>> actualizarPropietario(
            @Valid @RequestBody ActualizarPerfilDTO datos,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        // Tomamos el id directamente de la sesión, NUNCA del body que
        // manda el navegador — así nadie puede editar el perfil de otra
        // persona modificando el JSON manualmente desde el navegador
        Integer idPersona = (Integer) session.getAttribute("idPersona");

        if (idPersona == null) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("general", "Sesión expirada"));
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        try {
            Propietario datosActualizados = new Propietario();
            datosActualizados.setEmail(datos.email());
            datosActualizados.setAvatarColor(datos.avatarColor());
            datosActualizados.setTelefonoPropietario(Long.parseLong(datos.telefono().replaceAll("\\s+", "")));

            Propietario actualizado = propietarioService.actualizar(idPersona, datosActualizados);

            respuesta.put("ok", true);
            respuesta.put("email", actualizado.getEmail());
            respuesta.put("telefono", actualizado.getTelefonoPropietario());
            respuesta.put("avatarColor", actualizado.getAvatarColor());
            return ResponseEntity.ok(respuesta);

        } catch (NumberFormatException e) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("telefono", "El teléfono debe contener solo números"));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);

        } catch (RuntimeException e) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("general", e.getMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }
    }

    @PostMapping("/api/mecanico/perfil/actualizar")
    public ResponseEntity<Map<String, Object>> actualizarMecanico(
            @Valid @RequestBody ActualizarPerfilDTO datos,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Integer idPersona = (Integer) session.getAttribute("idPersona");

        if (idPersona == null) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("general", "Sesión expirada"));
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        try {
            Mecanico datosActualizados = new Mecanico();
            datosActualizados.setEmail(datos.email());
            datosActualizados.setAvatarColor(datos.avatarColor());
            datosActualizados.setTelefonoMecanico(Long.parseLong(datos.telefono().replaceAll("\\s+", "")));

            Mecanico actualizado = mecanicoService.actualizar(idPersona, datosActualizados);

            respuesta.put("ok", true);
            respuesta.put("email", actualizado.getEmail());
            respuesta.put("telefono", actualizado.getTelefonoMecanico());
            respuesta.put("avatarColor", actualizado.getAvatarColor());
            return ResponseEntity.ok(respuesta);

        } catch (NumberFormatException e) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("telefono", "El teléfono debe contener solo números"));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);

        } catch (RuntimeException e) {
            respuesta.put("ok", false);
            respuesta.put("errores", Map.of("general", e.getMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }
    }
}
