package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CategoriaHasPropietario;
import tecnidrive.tecnidrive.model.CategoriaHasPropietarioId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

// El segundo parámetro genérico ahora es la clase de la llave compuesta,
// no un Integer/Long como en los demás Repositories
public interface CategoriaHasPropietarioRepository extends JpaRepository<CategoriaHasPropietario, CategoriaHasPropietarioId> {
    //nuevo par registro vehiculo
    List<CategoriaHasPropietario> findById_IdPropietario(Integer idPropietario);
}
