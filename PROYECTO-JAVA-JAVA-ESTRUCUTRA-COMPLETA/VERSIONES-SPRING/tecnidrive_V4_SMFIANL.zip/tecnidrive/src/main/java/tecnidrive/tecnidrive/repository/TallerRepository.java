package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.Taller;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TallerRepository extends JpaRepository<Taller, Integer> {

    // Necesario para cuando el mecánico logueado quiera ver
    // únicamente SU(s) taller(es), no los de todos
    List<Taller> findByMecanico_IdPersona(Integer idPersona);

       // AGREGADO: para listar solo los talleres activos (los que el
    // propietario debería poder ver y elegir)
    List<Taller> findByEstadoTallerTrue();
}