package tecnidrive.tecnidrive.dto;

import java.time.LocalDate;

// Junta el nombre de la categoría (ej: "B1") con su fecha de vigencia,
// para la tabla de "mis categorías" en la vista
public record CategoriaVigenteDTO (String tipoCategoria, LocalDate vigenciaLice)  {
    
}
