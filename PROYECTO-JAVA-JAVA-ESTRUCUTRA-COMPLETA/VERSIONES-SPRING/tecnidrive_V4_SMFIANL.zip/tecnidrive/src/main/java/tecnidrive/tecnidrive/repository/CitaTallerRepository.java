package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CitaTaller;
import tecnidrive.tecnidrive.model.EstadoCita;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitaTallerRepository extends JpaRepository<CitaTaller, Integer> {

    // Para "mis citas" del propietario, a través de su vehículo
    List<CitaTaller> findByVehiculo_Propietario_IdPersona(Integer idPersona);

    // Para la agenda del taller (mecánico)
    List<CitaTaller> findByTaller_IdTaller(Integer idTaller);

        // AGREGADO: equivalente a tienesCitaActiva() de tu PHP. "In" compara
    // contra una lista de estados en vez de uno solo
    boolean existsByVehiculo_PlacaAndEstadoCitaIn(String placa, List<EstadoCita> estados);

        // AGREGADO: para la agenda del mecánico, trae las citas de SU taller
    List<CitaTaller> findByTaller_IdTallerOrderByFechaCitaDesc(Integer idTaller);

        // AGREGADO: para "mis citas" del propietario, a través de su vehículo
    List<CitaTaller> findByVehiculo_Propietario_IdPersonaOrderByFechaCitaDesc(Integer idPersona);
}
