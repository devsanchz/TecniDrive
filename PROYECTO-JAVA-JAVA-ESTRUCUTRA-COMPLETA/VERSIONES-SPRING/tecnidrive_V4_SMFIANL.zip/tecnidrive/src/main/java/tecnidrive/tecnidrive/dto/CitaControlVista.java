package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CitaControlVista {
    private Integer idCita;
    private Integer idSeguimiento;
    private LocalDateTime fechaCita;
    // AGREGADO: la plantilla los necesita para mostrar fechas de registro y atención
    private LocalDateTime fechaRegistro;
    private LocalDate fechaInicioAtencion;

    private String clienteNombre;
    private String clienteApellido;
    // AGREGADO: se muestra junto al nombre del cliente
    private Long telefonoPropietario;

    private String placa;
    private String nombreMarca;
    private String nombreModelo;
    private String modelYear;
    private String textoTipoVehi;

    private String problemaContexto;
    private List<ServicioConPrecio> servicios;

    private String estadoMantenimiento;
    private List<TecnicoVista> tecnicosAsignados;

    // AGREGADO: datos del cierre, que la casilla "en_cierre" y "finalizada" muestran
    private String observacionesTecnico;
    private String textoGarantia;
    private LocalDateTime garantiaVigencia;
    private BigDecimal precioTotal;
}