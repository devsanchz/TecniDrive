package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.CitaVista;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.service.CitaTallerService;
import tecnidrive.tecnidrive.service.TallerService;

import java.util.List;

@Controller
public class MecanicoCitaController {

    @Autowired
    private TallerService tallerService;

    @Autowired
    private CitaTallerService citaTallerService;

    @GetMapping("/mecanico/cita")
    public String verCitas(
            @RequestParam(value = "exitoCita", required = false) String exitoCita,
            @RequestParam(value = "errorCita", required = false) String errorCita,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) {
            return "redirect:/mecanico/taller";
        }

        List<CitaVista> citas = citaTallerService.listarCitasDelTaller(taller.getIdTaller());
        model.addAttribute("citas", citas);

        if (exitoCita != null) model.addAttribute("exitoCita", "Acción realizada correctamente.");
        if (errorCita != null) model.addAttribute("errorCita", traducirError(errorCita));

        return "mecanico/mecanico-cita";
    }

    @PostMapping("/mecanico/cita/confirmar")
    public String confirmar(@RequestParam("id_cita") Integer idCita, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);

        try {
            citaTallerService.confirmarCita(idCita, taller.getIdTaller());
            return "redirect:/mecanico/cita?exitoCita=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/cita?errorCita=" + e.getMessage();
        }
    }

    @PostMapping("/mecanico/cita/cancelar")
    public String cancelar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("motivo") String motivo,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);

        try {
            citaTallerService.cancelarCita(idCita, taller.getIdTaller(), motivo);
            return "redirect:/mecanico/cita?exitoCita=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/cita?errorCita=" + e.getMessage();
        }
    }

    @PostMapping("/mecanico/cita/verificar-codigo")
    public String verificarCodigo(@RequestParam("codigo") String codigo, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);

        try {
            citaTallerService.verificarCodigoIniciarAtencion(codigo, taller.getIdTaller());
            return "redirect:/mecanico/cita?exitoCita=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/cita?errorCita=" + e.getMessage();
        }
    }

       private String traducirError(String codigo) {
        return switch (codigo) {
            case "cita-invalida" -> "La cita seleccionada no es válida.";
            case "cita-no-confirmable" -> "La cita no puede confirmarse.";
            case "cita-no-cancelable" -> "La cita no puede cancelarse.";
            case "codigo-invalido" -> "Código incorrecto o cita no confirmada.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
    }
