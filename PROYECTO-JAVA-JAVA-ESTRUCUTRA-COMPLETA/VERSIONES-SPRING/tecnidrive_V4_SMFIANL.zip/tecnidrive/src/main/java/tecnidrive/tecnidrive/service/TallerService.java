package tecnidrive.tecnidrive.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
//nuevo
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import tecnidrive.tecnidrive.dto.ServicioConPrecio;
import tecnidrive.tecnidrive.dto.TallerVista;
import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Servicio;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.model.TallerHasServicio;
import tecnidrive.tecnidrive.model.TallerHasServicioId;
import tecnidrive.tecnidrive.repository.EspecialidadRepository;
import tecnidrive.tecnidrive.repository.ServicioRepository;
import tecnidrive.tecnidrive.repository.TallerHasServicioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;
//nuevo
import tecnidrive.tecnidrive.dto.ServicioConPrecio;

@Service
public class TallerService {

    // AGREGADO: carpeta física fuera de resources/static, equivalente
    // a FCPATH . 'uploads/talleres' de tu CI4
    private static final String CARPETA_FOTOS = "uploads/talleres";

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private EspecialidadRepository especialidadRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    public Taller obtenerTallerDelMecanico(Integer idMecanico) {
        List<Taller> talleres = tallerRepository.findByMecanico_IdPersona(idMecanico);
        return talleres.isEmpty() ? null : talleres.get(0);
    }

    // AGREGADO: arma el texto del horario, igual que tu construirHorarioTexto()
    // de PHP — salta filas vacías y trunca a 150 caracteres (límite de la columna)
    public String construirHorarioTexto(String[] dias, String[] horas) {
        StringBuilder horario = new StringBuilder();

        for (int i = 0; i < dias.length; i++) {
            String dia = dias[i] == null ? "" : dias[i].trim();
            if (dia.isEmpty()) continue;

            String hora = (horas.length > i && horas[i] != null) ? horas[i].trim() : "";

            if (horario.length() > 0) {
                horario.append(" | ");
            }
            horario.append(dia).append(": ").append(hora);
        }

        String texto = horario.toString();
        return texto.length() > 150 ? texto.substring(0, 150) : texto;
    }

    @Transactional
    public void registrarTaller(
            Taller taller,
            String nombreEspecialidad,
            String[] nombresServicios,
            String[] precios,
            MultipartFile foto) {

        // AGREGADO: procesamos la foto ANTES de guardar el taller,
        // para tener el nombre del archivo listo antes del INSERT
        String nombreFoto = null;
        if (foto != null && !foto.isEmpty()) {
            nombreFoto = guardarFoto(foto, taller.getMecanico().getIdPersona());
            taller.setFotoTaller(nombreFoto);
        }

        try {
            Especialidad especialidad = buscarOCrearEspecialidad(nombreEspecialidad);

            HashSet<Especialidad> especialidades = new HashSet<>();
            especialidades.add(especialidad);
            taller.setEspecialidades(especialidades);

            Taller tallerGuardado = tallerRepository.save(taller);

            for (int i = 0; i < nombresServicios.length; i++) {

                // CORRECCIÓN: se saltan filas de servicio vacías; sin esto,
                // un campo en blanco intentaba guardarse o rompía el precio
                String nombreServicio = nombresServicios[i] == null ? "" : nombresServicios[i].trim();
                if (nombreServicio.isEmpty()) continue;

                Servicio servicio = buscarOCrearServicio(nombreServicio);
                BigDecimal precio = convertirPrecio(precios[i]);

                TallerHasServicio relacion = new TallerHasServicio();
                TallerHasServicioId id = new TallerHasServicioId();
                id.setIdTaller(tallerGuardado.getIdTaller());
                id.setIdServicio(servicio.getIdServicio());
                relacion.setId(id);
                relacion.setPrecioServicio(precio);

                tallerHasServicioRepository.save(relacion);
            }

        } catch (RuntimeException e) {
            // AGREGADO: si algo falla, la transacción de BD deshace sola
            // los cambios, pero el archivo físico de la foto NO —
            // hay que borrarlo a mano, igual que tu catch en PHP
            if (nombreFoto != null) {
                borrarFoto(nombreFoto);
            }
            throw e;
        }
    }

    private String guardarFoto(MultipartFile foto, Integer idMecanico) {

        String tipo = foto.getContentType();
        if (tipo == null || !(tipo.equals("image/jpeg") || tipo.equals("image/png") || tipo.equals("image/webp"))) {
            throw new IllegalArgumentException("Solo se permiten imágenes JPG, PNG o WEBP");
        }

        if (foto.getSize() > 2_000_000) {
            throw new IllegalArgumentException("La imagen no puede superar 2MB");
        }

        String extension = tipo.equals("image/png") ? "png" : tipo.equals("image/webp") ? "webp" : "jpg";
        String nombreFoto = "taller_" + idMecanico + "_" + System.currentTimeMillis() + "." + extension;

        try {
            Path carpeta = Paths.get(CARPETA_FOTOS);
            Files.createDirectories(carpeta); // crea la carpeta si no existe
            foto.transferTo(carpeta.resolve(nombreFoto));
        } catch (IOException e) {
            throw new RuntimeException("No se pudo guardar la imagen", e);
        }

        return nombreFoto;
    }

    private void borrarFoto(String nombreFoto) {
        try {
            Files.deleteIfExists(Paths.get(CARPETA_FOTOS, nombreFoto));
        } catch (IOException ignored) {
            // No bloqueamos el flujo si el borrado falla
        }
    }

    private Especialidad buscarOCrearEspecialidad(String nombre) {
        return especialidadRepository.findAll().stream()
                .filter(e -> e.getNombreEspecialidad().equalsIgnoreCase(nombre))
                .findFirst()
                .orElseGet(() -> {
                    Especialidad nueva = new Especialidad();
                    nueva.setNombreEspecialidad(nombre);
                    return especialidadRepository.save(nueva);
                });
    }

    private Servicio buscarOCrearServicio(String nombre) {
        return servicioRepository.findAll().stream()
                .filter(s -> s.getNombreServicio().equalsIgnoreCase(nombre))
                .findFirst()
                .orElseGet(() -> {
                    Servicio nuevo = new Servicio();
                    nuevo.setNombreServicio(nombre);
                    return servicioRepository.save(nuevo);
                });
    }

    private BigDecimal convertirPrecio(String precioTexto) {
        String limpio = precioTexto
                .replace("$", "")
                .replace(".", "")
                .replace(",", ".")
                .trim();

        return limpio.isEmpty() ? BigDecimal.ZERO : new BigDecimal(limpio);
    }
    // AGREGADO: junta cada TallerHasServicio con el nombre real del
    // Servicio correspondiente, para que la vista pueda mostrar ambos
       // CORRECCIÓN: ahora incluye el id del servicio, no solo nombre y precio
    public List<ServicioConPrecio> obtenerServiciosDelTaller(Integer idTaller) {
        List<TallerHasServicio> relaciones = tallerHasServicioRepository.findById_IdTaller(idTaller);
        List<ServicioConPrecio> resultado = new ArrayList<>();

        for (TallerHasServicio relacion : relaciones) {
            Servicio servicio = servicioRepository.findById(relacion.getId().getIdServicio())
                    .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

            resultado.add(new ServicioConPrecio(
                    servicio.getIdServicio(),
                    servicio.getNombreServicio(),
                    relacion.getPrecioServicio()
            ));
        }

        return resultado;
    }

    // AGREGADO: arma la lista de talleres para que el propietario los vea,
    // combinando el Taller real con sus servicios y horarios ya procesados
        // CORRECCIÓN: la plantilla ahora usa t.fotoTaller directamente como
    // src de la imagen, sin armar la ruta ella misma — por eso calculamos
    // aquí la ruta completa, con una imagen de respaldo si el taller
    // todavía no tiene foto
    public List<TallerVista> listarActivosParaPropietario() {
        List<Taller> talleres = tallerRepository.findByEstadoTallerTrue();
        List<TallerVista> resultado = new ArrayList<>();

        for (Taller taller : talleres) {
            TallerVista vista = new TallerVista();
            vista.setIdTaller(taller.getIdTaller());
            vista.setNombreTaller(taller.getNombreTaller());
            vista.setDescripcionTaller(taller.getDescripcionTaller());
            vista.setDireccionTaller(taller.getDireccionTaller());

            String foto = taller.getFotoTaller();
            vista.setFotoTaller(
                (foto != null && !foto.isBlank())
                    ? "/uploads/talleres/" + foto
                    : "/img/taller-placeholder.jpg"
            );

            // CORRECCIÓN: la plantilla accede a especialidades[0] sin
            // comprobar si la lista está vacía — si un taller no tiene
            // ninguna, la página completa se rompería. Garantizamos que
            // la lista nunca quede vacía
            List<Especialidad> especialidades = new ArrayList<>(taller.getEspecialidades());
            if (especialidades.isEmpty()) {
                Especialidad sinEspecialidad = new Especialidad();
                sinEspecialidad.setNombreEspecialidad("Sin especialidad");
                especialidades.add(sinEspecialidad);
            }
            vista.setEspecialidades(especialidades);

            vista.setServicios(obtenerServiciosDelTaller(taller.getIdTaller()));
            vista.setHorarios(taller.getHorarios());
            resultado.add(vista);
        }

        return resultado;
    }
}