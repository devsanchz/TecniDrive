package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "calificacion_taller")
public class CalificacionTaller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_calificacion")
    private Integer idCalificacion;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "puntuacion", nullable = false)
    private Integer puntuacion;

    // AGREGADO: campo nuevo, nullable (permite filtrar calificaciones,
    // por ejemplo por rango o categoría de puntuación en el reporte)
    @Column(name = "filtro_puntuacion", length = 50)
    private String filtroPuntuacion;

    @Column(name = "comentario", columnDefinition = "TEXT")
    private String comentario;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false)
    private EstadoCalificacion estado;

    // AGREGADO: campo nuevo, para que el Administrador (o el mecánico)
    // sepa si ya revisó esta calificación, sin necesidad de otra tabla
    @Column(name = "visto", nullable = false)
    private Boolean visto;

    @ManyToOne
    @JoinColumn(name = "taller_id_taller", nullable = false)
    private Taller taller;

    @ManyToOne
    @JoinColumn(name = "propietarios_id_propietario", nullable = false)
    private Propietario propietario;
}