package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// "Aplana" los datos del Vehiculo para que la plantilla pueda leer
// directamente v.nombreMarca, v.nombreModelo, etc., sin navegar
// relaciones anidadas (v.modelo.marca.nombreMarca)
@Getter
@Setter
@NoArgsConstructor
public class VehiculoVista {
    private String placa;
    private String modelYear;
    private Boolean estadoVehi;
    private String motivoEstado;
    private Integer tiposVehiculoIdTipoVehi;
    private Integer servicioVehiculoIdTipoServicio;
    private String nombreMarca;
    private String nombreModelo;
        // PENDIENTE: siempre en false hasta construir el módulo de Citas.
    // Cuando exista, se calculará revisando si el vehículo tiene una
    // cita en estado "pendiente", "confirmada" o "en_atencion"
    private Boolean tieneCitaActiva = false;
}