package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.PapelVehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface PapelVehiculoRepository extends JpaRepository<PapelVehiculo, Integer> {

    // Para mostrar todos los papeles (SOAT, tecnomecánica) de un vehículo específico,
    // al ver el detalle o el registro completo de ese vehículo
    List<PapelVehiculo> findByVehiculo_Placa(String placa);

    //nuevo para registro vehiculo
    Optional<PapelVehiculo> findByVehiculo_PlacaAndTipoDocumento_IdDocumento(String placa, Integer idDocumento);
}