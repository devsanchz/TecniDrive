package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.CategoriaVigenteDTO;
import tecnidrive.tecnidrive.dto.VehiculoVista;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.ServicioVehiculoRepository;
import tecnidrive.tecnidrive.repository.TipoVehiculoRepository;
import tecnidrive.tecnidrive.service.PropietarioService;
import tecnidrive.tecnidrive.service.VehiculoService;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PropietarioVehiculoController {

    @Autowired
    private PropietarioService propietarioService;

    @Autowired
    private VehiculoService vehiculoService;

    @Autowired
    private TipoVehiculoRepository tipoVehiculoRepository;

    @Autowired
    private ServicioVehiculoRepository servicioVehiculoRepository;

    @GetMapping("/propietario/vehiculo")
    public String verVehiculos(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "errorVehiculo", required = false) String errorVehiculo,
            @RequestParam(value = "vehiculoGuardado", required = false) String vehiculoGuardado,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        boolean tieneLicencia = propietarioService.tieneLicencia(idPersona);
        model.addAttribute("tieneLicencia", tieneLicencia);

        if (tieneLicencia) {
            Propietario propietario = propietarioService.obtenerPorId(idPersona);
            model.addAttribute("numeroLicencia", propietario.getNumeroLicencia());
            model.addAttribute("misCategorias", propietarioService.obtenerCategoriasVigentes(idPersona));

            List<VehiculoVista> misVehiculos = vehiculoService.obtenerVistaPorPropietario(idPersona);
            model.addAttribute("misVehiculos", misVehiculos);

            // AGREGADO: arma el mapa placa -> {1: soat, 2: tecnomecánica},
            // igual que hacía tu PHP con obtenerPorPlacas()
            Map<String, Map<Integer, PapelVehiculo>> misDocumentos = new HashMap<>();
            for (VehiculoVista v : misVehiculos) {
                List<PapelVehiculo> docs = vehiculoService.obtenerDocumentosDeVehiculo(v.getPlaca());
                Map<Integer, PapelVehiculo> mapaPorTipo = new HashMap<>();
                for (PapelVehiculo doc : docs) {
                    mapaPorTipo.put(doc.getTipoDocumento().getIdDocumento(), doc);
                }
                misDocumentos.put(v.getPlaca(), mapaPorTipo);
            }
            model.addAttribute("misDocumentos", misDocumentos);
        }

        if (error != null) model.addAttribute("error", "Revisa los datos de la licencia.");
        if (errorVehiculo != null) model.addAttribute("errorVehiculo", "Revisa los datos del vehículo.");
        if (vehiculoGuardado != null) model.addAttribute("vehiculoGuardado", true);

        return "propietario/propietario-vehiculo";
    }

    @PostMapping("/propietario/guardar-licencia")
    public String guardarLicencia(
            @RequestParam("numero_licencia") String numeroLicencia,
            @RequestParam("categoria[]") String[] categorias,
            @RequestParam("fecha[]") String[] fechas,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        propietarioService.guardarLicencia(idPersona, numeroLicencia.trim(), categorias, fechas);

        return "redirect:/propietario/vehiculo";
    }

    @PostMapping("/propietario/guardar-vehiculo")
    public String guardarVehiculo(
            @RequestParam("placa") String placa,
            @RequestParam("marca") String marca,
            @RequestParam("modelo") String modelo,
            @RequestParam("ano") String anio,
            @RequestParam("tipo_vehi") Integer idTipoVehi,
            @RequestParam("tipo_servicio") Integer idTipoServicio,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        String placaLimpia = placa.trim().toUpperCase();

        if (vehiculoService.existePlaca(placaLimpia)) {
            return "redirect:/propietario/vehiculo?errorVehiculo=placa-duplicada";
        }

        Propietario propietario = propietarioService.obtenerPorId(idPersona);
        TipoVehiculo tipoVehiculo = tipoVehiculoRepository.findById(idTipoVehi)
                .orElseThrow(() -> new RuntimeException("Tipo de vehículo no encontrado"));
        ServicioVehiculo servicioVehiculo = servicioVehiculoRepository.findById(idTipoServicio)
                .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

        vehiculoService.registrarVehiculo(
                placaLimpia, anio.trim(), idTipoVehi, idTipoServicio,
                marca, modelo, propietario, tipoVehiculo, servicioVehiculo
        );

        return "redirect:/propietario/vehiculo?vehiculoGuardado=1";
    }

    @PostMapping("/propietario/activar-vehiculo")
    public String activarVehiculo(@RequestParam("placa") String placa, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Vehiculo vehiculo = vehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo != null) {
            vehiculoService.activar(vehiculo);
        }

        return "redirect:/propietario/vehiculo";
    }

    @PostMapping("/propietario/desactivar-vehiculo")
    public String desactivarVehiculo(
            @RequestParam("placa") String placa,
            @RequestParam("motivo") String motivo,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        if (motivo == null || motivo.isBlank()) {
            return "redirect:/propietario/vehiculo?errorVehiculo=motivo-requerido";
        }

        Vehiculo vehiculo = vehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo != null) {
            vehiculoService.desactivar(vehiculo, motivo.trim());
        }

        return "redirect:/propietario/vehiculo";
    }

    @PostMapping("/propietario/guardar-documentos")
    public String guardarDocumentos(
            @RequestParam("placa") String placa,
            @RequestParam(value = "soat", required = false) String soat,
            @RequestParam(value = "tecnomecanica", required = false) String tecno,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Vehiculo vehiculo = vehiculoService.obtenerSiEsDelPropietario(placa, idPersona);
        if (vehiculo == null) return "redirect:/propietario/vehiculo";

        if (soat != null && !soat.isBlank()) {
            vehiculoService.guardarDocumento(vehiculo, 1, LocalDate.parse(soat));
        }
        if (tecno != null && !tecno.isBlank()) {
            vehiculoService.guardarDocumento(vehiculo, 2, LocalDate.parse(tecno));
        }

        return "redirect:/propietario/vehiculo";
    }
}