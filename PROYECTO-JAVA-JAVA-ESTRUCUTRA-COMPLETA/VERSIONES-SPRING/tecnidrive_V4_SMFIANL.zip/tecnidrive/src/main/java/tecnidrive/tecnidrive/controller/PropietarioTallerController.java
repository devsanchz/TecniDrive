package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.TallerVista;
import tecnidrive.tecnidrive.dto.VehiculoVista;
import tecnidrive.tecnidrive.service.CitaTallerService;
import tecnidrive.tecnidrive.service.TallerService;
import tecnidrive.tecnidrive.service.VehiculoService;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
public class PropietarioTallerController {

    @Autowired
    private TallerService tallerService;

    @Autowired
    private VehiculoService vehiculoService;

    @Autowired
    private CitaTallerService citaTallerService;

    @GetMapping("/propietario/taller")
    public String verTalleres(
            @RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "errorVehiculo", required = false) String errorVehiculo,
            @RequestParam(value = "vehiculoGuardado", required = false) String vehiculoGuardado,
            @RequestParam(value = "exitoCita", required = false) String exitoCita,
            @RequestParam(value = "errorCita", required = false) String errorCita,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) {
            return "redirect:/login";
        }

        List<TallerVista> talleres = tallerService.listarActivosParaPropietario();
        model.addAttribute("talleres", talleres);
        model.addAttribute("total", talleres.size());

        // Especialidades únicas para llenar el <select> del filtro
        List<String> especialidadesUnicas = talleres.stream()
                .flatMap(t -> t.getEspecialidades().stream())
                .map(e -> e.getNombreEspecialidad())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
        model.addAttribute("especialidadesUnicas", especialidadesUnicas);

        // PENDIENTE: se calculará de verdad con el módulo de Calificaciones
        Map<String, Integer> conteos = new HashMap<>();
        conteos.put("cinco", 0);
        conteos.put("medio", 0);
        conteos.put("bajo", 0);
        model.addAttribute("conteos", conteos);

        List<VehiculoVista> misVehiculos = vehiculoService.obtenerVistaPorPropietario(idPersona);

        // AGREGADO: el Controller sí puede usar ambos Services sin generar
        // dependencia circular, porque un Controller nunca es inyectado
        // dentro de un Service
        for (VehiculoVista v : misVehiculos) {
            v.setTieneCitaActiva(citaTallerService.tieneCitaActiva(v.getPlaca()));
        }

        model.addAttribute("misVehiculos", misVehiculos);
        model.addAttribute("fechaMinimaCita", LocalDate.now().plusDays(1).toString());
        model.addAttribute("propietarioId", idPersona);

        if (exitoCita != null) {
            model.addAttribute("exitoCita", "Cita agendada correctamente. Estado: pendiente de confirmación.");
        }
        if (errorCita != null) {
            model.addAttribute("errorCita", traducirErrorCita(errorCita));
        }

        return "propietario/propietario-taller";
    }

    @PostMapping("/propietario/taller/agendar-cita")
    public String agendarCita(
            @RequestParam("id_taller") Integer idTaller,
            @RequestParam("placa") String placa,
            @RequestParam("fecha_cita") String fechaCita,
            @RequestParam("hora_cita") String horaCita,
            @RequestParam(value = "problema", required = false) String problema,
            @RequestParam(value = "servicios[]", required = false) List<Integer> servicios,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        try {
            citaTallerService.agendarCita(
                    idTaller, placa.trim().toUpperCase(), fechaCita, horaCita,
                    problema, servicios, idPersona
            );
            return "redirect:/propietario/taller?exitoCita=1";

        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/taller?errorCita=" + e.getMessage();
        }
    }

    private String traducirErrorCita(String codigo) {
        return switch (codigo) {
            case "vehiculo-invalido" -> "El vehículo seleccionado no es válido.";
            case "vehiculo-ocupado" -> "Ese vehículo ya tiene una cita activa. Espera a que finalice antes de agendar otra.";
            case "taller-invalido" -> "El taller seleccionado no es válido.";
            default -> "Ocurrió un error al agendar la cita.";
        };
    }
}