package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CitaVista {
    private Integer idCita;
    private LocalDateTime fechaCita;
    private LocalDateTime fechaRegistro;
    private String estadoCita;
    private String claseEstado;
    private String textoEstado;
    private String codigoConfirmacion;
    private String problemaContexto;
    private String motivoCancelacion;

    private String clienteNombre;
    private String clienteApellido;
    private Long telefonoPropietario;

    // AGREGADO: datos del taller y del mecánico, para la vista del propietario
    private String nombreTaller;
    private String direccionTaller;
    private String mecanicoNombre;
    private String mecanicoApellido;
    private Long telefonoMecanico;

    private String placa;
    private String nombreMarca;
    private String nombreModelo;
    private String modelYear;
    private String textoTipoVehi;

    private List<ServicioConPrecio> servicios;

    // AGREGADO: datos de GestionMantenimiento, solo presentes si la cita
    // ya llegó al estado "en_atencion" (puede quedar todo en null si aún no)
    private String estadoMantenimiento;
    private String observacionesTecnico;
    private String textoGarantia;
    private LocalDateTime garantiaVigencia;
    private BigDecimal precioTotal;
    private String codigoEntrega;
    private List<TecnicoVista> tecnicos;
}