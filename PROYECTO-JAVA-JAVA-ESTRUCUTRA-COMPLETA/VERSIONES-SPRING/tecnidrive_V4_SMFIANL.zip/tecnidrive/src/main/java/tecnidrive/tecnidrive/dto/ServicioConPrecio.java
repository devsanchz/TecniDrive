package tecnidrive.tecnidrive.dto;

import java.math.BigDecimal;

// AGREGADO: el id del servicio, porque la plantilla lo necesita para
// el checkbox de "servicios a incluir en la cita" (name="servicios[]")
public record ServicioConPrecio(
        Integer serviciosIdServicio,
        String nombreServicio,
        BigDecimal precioServicio
) {
}