package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

// DTO compartido: sirve tanto para actualizar Propietario como Mecanico,
// ya que ambos editan exactamente los mismos 3 campos
public record ActualizarPerfilDTO(

        @NotBlank
        @Email
        String email,

        @NotBlank
        String telefono, // String, no Long: mismo motivo que en el registro,
                          // evitamos que espacios rompan la conversión antes de validar

        @NotBlank
        String avatarColor

) {
}