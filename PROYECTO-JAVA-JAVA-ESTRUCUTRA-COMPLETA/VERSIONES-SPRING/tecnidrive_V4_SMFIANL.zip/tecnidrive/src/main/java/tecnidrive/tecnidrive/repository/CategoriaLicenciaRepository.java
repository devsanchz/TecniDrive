package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.CategoriaLicencia;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.*;

public interface CategoriaLicenciaRepository extends JpaRepository<CategoriaLicencia, Integer> {

    //nuevo para vehiculo registro
    Optional<CategoriaLicencia> findByTipoCategoria(String tipoCategoria);
}