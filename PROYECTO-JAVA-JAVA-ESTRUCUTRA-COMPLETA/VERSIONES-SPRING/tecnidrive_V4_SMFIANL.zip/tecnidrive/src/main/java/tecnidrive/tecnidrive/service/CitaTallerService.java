package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tecnidrive.tecnidrive.dto.CitaControlVista;
import tecnidrive.tecnidrive.dto.CitaVista;
import tecnidrive.tecnidrive.dto.ServicioConPrecio;
import tecnidrive.tecnidrive.dto.TecnicoVista;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.CitaHasServicioRepository;
import tecnidrive.tecnidrive.repository.CitaTallerRepository;
import tecnidrive.tecnidrive.repository.GestionMantenimientoRepository;
import tecnidrive.tecnidrive.repository.ServicioRepository;
import tecnidrive.tecnidrive.repository.TallerHasServicioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class CitaTallerService {

    @Autowired
    private CitaTallerRepository citaTallerRepository;

    @Autowired
    private CitaHasServicioRepository citaHasServicioRepository;

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private VehiculoService vehiculoService;

    
    @Autowired
    private ServicioRepository servicioRepository;

//PARA EL PROPIETARIO VEA CITA
          @Autowired
    private GestionMantenimientoRepository gestionMantenimientoRepository;

 @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;


    @Autowired
    private TecnicoService tecnicoService;


    // Los mismos 3 estados que tu PHP consideraba "cita activa"
    private static final List<EstadoCita> ESTADOS_ACTIVOS = Arrays.asList(
            EstadoCita.pendiente, EstadoCita.confirmada, EstadoCita.en_atencion
    );

    // CitaTallerService.java
public boolean tieneCitaActiva(String placa) {
    return citaTallerRepository.findAll().stream()
            .filter(c -> c.getVehiculo().getPlaca().equals(placa))
            .filter(c -> ESTADOS_ACTIVOS.contains(c.getEstadoCita()))
            .anyMatch(c -> gestionMantenimientoRepository.findByCitaTaller_IdCita(c.getIdCita())
                    .map(g -> g.getEstadoMantenimiento() != EstadoMantenimiento.finalizada)
                    .orElse(true));
}
    @Transactional
    public void agendarCita(
            Integer idTaller,
            String placa,
            String fechaCita,
            String horaCita,
            String problema,
            List<Integer> servicios,
            Integer idPropietario) {

        // Verificación de dueño — mismo patrón que ya usamos en Vehiculo
        Vehiculo vehiculo = vehiculoService.obtenerSiEsDelPropietario(placa, idPropietario);
        if (vehiculo == null) {
            throw new IllegalArgumentException("vehiculo-invalido");
        }

        if (tieneCitaActiva(placa)) {
            throw new IllegalArgumentException("vehiculo-ocupado");
        }

        Taller taller = tallerRepository.findById(idTaller)
                .orElseThrow(() -> new IllegalArgumentException("taller-invalido"));

        // Combina fecha y hora en un solo LocalDateTime, igual que tu
        // PHP hacía con $fechaCita . ' ' . $horaCita . ':00'
        LocalDateTime fechaHora = LocalDateTime.parse(fechaCita + "T" + horaCita + ":00");

        CitaTaller cita = new CitaTaller();
        cita.setFechaCita(fechaHora);
        cita.setProblemaContexto((problema == null || problema.isBlank()) ? null : problema.trim());
        cita.setEstadoCita(EstadoCita.pendiente);
        cita.setTaller(taller);
        cita.setVehiculo(vehiculo);

        CitaTaller citaGuardada = citaTallerRepository.save(cita);

        if (servicios != null) {
            for (Integer idServicio : servicios) {
                CitaHasServicioId id = new CitaHasServicioId();
                id.setIdCita(citaGuardada.getIdCita());
                id.setIdTaller(idTaller);
                id.setIdServicio(idServicio);

                CitaHasServicio relacion = new CitaHasServicio();
                relacion.setId(id);
                citaHasServicioRepository.save(relacion);
            }
        }
    }

       

    // AGREGADO: arma la lista de citas para la vista del mecánico,
    // combinando CitaTaller con datos de Propietario y Vehiculo
    public List<CitaVista> listarCitasDelTaller(Integer idTaller) {
        List<CitaTaller> citas = citaTallerRepository.findByTaller_IdTallerOrderByFechaCitaDesc(idTaller);
        List<CitaVista> resultado = new ArrayList<>();

        for (CitaTaller cita : citas) {
            CitaVista vista = new CitaVista();
            vista.setIdCita(cita.getIdCita());
            vista.setFechaCita(cita.getFechaCita());
            vista.setFechaRegistro(cita.getFechaRegistro());
            vista.setEstadoCita(cita.getEstadoCita().name());
            vista.setClaseEstado(cita.getEstadoCita().getClase());
            vista.setTextoEstado(cita.getEstadoCita().getTexto());
            vista.setCodigoConfirmacion(cita.getCodigoConfirmacion());
            vista.setProblemaContexto(cita.getProblemaContexto());
            vista.setMotivoCancelacion(cita.getMotivoCancelacion());

            Vehiculo vehiculo = cita.getVehiculo();
            vista.setPlaca(vehiculo.getPlaca());
            vista.setModelYear(vehiculo.getModelYear());
            vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
            vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

            Propietario propietario = vehiculo.getPropietario();
            vista.setClienteNombre(propietario.getPrimerNombre());
            vista.setClienteApellido(propietario.getPrimerApellido());
            vista.setTelefonoPropietario(propietario.getTelefonoPropietario());

            

            List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
List<ServicioConPrecio> servicios = new ArrayList<>();
for (CitaHasServicio rel : relaciones) {
    Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
    // CORRECCIÓN: el precio real de la cita viene de TallerHasServicio
    // (el precio que ESE taller cobra por ese servicio), no de un valor
    // fijo — antes se mandaba "null" literal, por eso salía vacío
    TallerHasServicioId thsId = new TallerHasServicioId();
    thsId.setIdTaller(rel.getId().getIdTaller());
    thsId.setIdServicio(rel.getId().getIdServicio());

    java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
            .map(TallerHasServicio::getPrecioServicio)
            .orElse(java.math.BigDecimal.ZERO);

    if (servicio != null) {
        servicios.add(new ServicioConPrecio(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
    }
}
vista.setServicios(servicios);
        }

        return resultado;
    }

       @Transactional
    public void confirmarCita(Integer idCita, Integer idTaller) {
        CitaTaller cita = obtenerSiEsDelTaller(idCita, idTaller);

        // CORRECCIÓN: solo se puede confirmar si sigue pendiente —
        // esto faltaba, igual que validaba tu PHP
        if (cita.getEstadoCita() != EstadoCita.pendiente) {
            throw new IllegalArgumentException("cita-no-confirmable");
        }

        // AGREGADO: genera el código de confirmación, igual que tu PHP
        // (bin2hex(random_bytes(5)) recortado a 8 caracteres, en mayúsculas)
        String codigo = generarCodigo();

        cita.setEstadoCita(EstadoCita.confirmada);
        cita.setCodigoConfirmacion(codigo);
        citaTallerRepository.save(cita);
    }

    // AGREGADO: equivalente a bin2hex(random_bytes(5)) de PHP.
    // SecureRandom genera bytes verdaderamente aleatorios (no
    // predecibles), igual que hicimos para el código de recuperación
    // de contraseña
    private String generarCodigo() {
        byte[] bytesAleatorios = new byte[5];
        new java.security.SecureRandom().nextBytes(bytesAleatorios);

        StringBuilder hex = new StringBuilder();
        for (byte b : bytesAleatorios) {
            hex.append(String.format("%02x", b));
        }

        return hex.substring(0, 8).toUpperCase();
    }

        @Transactional
    public void cancelarCita(Integer idCita, Integer idTaller, String motivo) {
        CitaTaller cita = obtenerSiEsDelTaller(idCita, idTaller);

        // AGREGADO: solo se puede cancelar si está pendiente o confirmada,
        // igual que validaba tu PHP con in_array(...)
        if (cita.getEstadoCita() != EstadoCita.pendiente
                && cita.getEstadoCita() != EstadoCita.confirmada) {
            throw new IllegalArgumentException("cita-no-cancelable");
        }

        cita.setEstadoCita(EstadoCita.cancelada_mecanico);
        cita.setMotivoCancelacion(motivo);
        citaTallerRepository.save(cita);
    }
    
        @Transactional
    public void verificarCodigoIniciarAtencion(String codigo, Integer idTaller) {
        String codigoNormalizado = codigo.trim().toUpperCase();

        CitaTaller cita = citaTallerRepository.findAll().stream()
                .filter(c -> codigoNormalizado.equals(c.getCodigoConfirmacion()))
                .filter(c -> c.getEstadoCita() == EstadoCita.confirmada)
                .filter(c -> c.getTaller().getIdTaller().equals(idTaller))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("codigo-invalido"));

        cita.setEstadoCita(EstadoCita.en_atencion);
        cita.setFechaInicioAtencion(java.time.LocalDate.now());
        citaTallerRepository.save(cita);
    }

    // Verificación de dueño, mismo patrón que ya usamos en Vehiculo/Taller
    private CitaTaller obtenerSiEsDelTaller(Integer idCita, Integer idTaller) {
        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (!cita.getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        return cita;
    }

  

    // AGREGADO: arma la lista de citas para "mis citas" del propietario,
    // incluyendo los datos de mantenimiento cuando ya existen
    public List<CitaVista> listarCitasDelPropietario(Integer idPropietario) {
        List<CitaTaller> citas = citaTallerRepository
                .findByVehiculo_Propietario_IdPersonaOrderByFechaCitaDesc(idPropietario);
        List<CitaVista> resultado = new ArrayList<>();

        for (CitaTaller cita : citas) {
            CitaVista vista = new CitaVista();
            vista.setIdCita(cita.getIdCita());
            vista.setFechaCita(cita.getFechaCita());
            vista.setFechaRegistro(cita.getFechaRegistro());
            vista.setEstadoCita(cita.getEstadoCita().name());
            vista.setClaseEstado(cita.getEstadoCita().getClase());
            vista.setTextoEstado(cita.getEstadoCita().getTexto());
            vista.setCodigoConfirmacion(cita.getCodigoConfirmacion());
            vista.setProblemaContexto(cita.getProblemaContexto());
            vista.setMotivoCancelacion(cita.getMotivoCancelacion());

            Taller taller = cita.getTaller();
            vista.setNombreTaller(taller.getNombreTaller());
            vista.setDireccionTaller(taller.getDireccionTaller());
            vista.setMecanicoNombre(taller.getMecanico().getPrimerNombre());
            vista.setMecanicoApellido(taller.getMecanico().getPrimerApellido());
            vista.setTelefonoMecanico(taller.getMecanico().getTelefonoMecanico());

            Vehiculo vehiculo = cita.getVehiculo();
            vista.setPlaca(vehiculo.getPlaca());
            vista.setModelYear(vehiculo.getModelYear());
            vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
            vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

           List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
List<ServicioConPrecio> servicios = new ArrayList<>();
for (CitaHasServicio rel : relaciones) {
    Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
    // CORRECCIÓN: el precio real de la cita viene de TallerHasServicio
    // (el precio que ESE taller cobra por ese servicio), no de un valor
    // fijo — antes se mandaba "null" literal, por eso salía vacío
    TallerHasServicioId thsId = new TallerHasServicioId();
    thsId.setIdTaller(rel.getId().getIdTaller());
    thsId.setIdServicio(rel.getId().getIdServicio());

    java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
            .map(TallerHasServicio::getPrecioServicio)
            .orElse(java.math.BigDecimal.ZERO);

    if (servicio != null) {
        servicios.add(new ServicioConPrecio(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
    }
}
vista.setServicios(servicios);

            // AGREGADO: solo si ya existe la ficha de mantenimiento
            // (el trigger de MySQL la crea cuando la cita pasa a en_atencion)
            gestionMantenimientoRepository.findByCitaTaller_IdCita(cita.getIdCita())
                    .ifPresent(mant -> {
                        vista.setEstadoMantenimiento(mant.getEstadoMantenimiento().name());
                        vista.setObservacionesTecnico(mant.getObservacionesTecnico());
                        vista.setTextoGarantia(mant.getTextoGarantia());
                        vista.setGarantiaVigencia(mant.getGarantiaVigencia());
                        vista.setPrecioTotal(mant.getPrecioTotal());
                        vista.setCodigoEntrega(mant.getCodigoEntrega());

                        List<TecnicoVista> tecnicos = new ArrayList<>();
                        for (Tecnico tec : mant.getTecnicos()) {
                            tecnicos.add(new TecnicoVista(tec.getNombreTecnico()));
                        }
                        vista.setTecnicos(tecnicos);
                    });

            resultado.add(vista);
        }

        return resultado;
    }

    @Transactional
    public void cancelarCitaPropietario(Integer idCita, Integer idPropietario, String motivo) {
        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        // Verificación de dueño, igual patrón de siempre
        if (!cita.getVehiculo().getPropietario().getIdPersona().equals(idPropietario)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        // Solo se puede cancelar si sigue pendiente (igual que decía tu vista:
        // "Puedes cancelarla antes de que confirmen la reserva")
        if (cita.getEstadoCita() != EstadoCita.pendiente) {
            throw new IllegalArgumentException("cita-no-cancelable");
        }

        cita.setEstadoCita(EstadoCita.cancelada_propietario);
        cita.setMotivoCancelacion(motivo);
        citaTallerRepository.save(cita);
    }





        
    // AGREGADO: citas en_atencion del taller, con su ficha de gestión
    public List<CitaControlVista> listarEnAtencion(Integer idTaller) {
        List<CitaTaller> citas = citaTallerRepository.findByTaller_IdTallerOrderByFechaCitaDesc(idTaller)
                .stream()
                .filter(c -> c.getEstadoCita() == EstadoCita.en_atencion)
                .toList();

        List<CitaControlVista> resultado = new ArrayList<>();

        for (CitaTaller cita : citas) {
            CitaControlVista vista = new CitaControlVista();
            vista.setIdCita(cita.getIdCita());
            vista.setFechaCita(cita.getFechaCita());
            vista.setProblemaContexto(cita.getProblemaContexto());
                        vista.setFechaRegistro(cita.getFechaRegistro());
            vista.setFechaInicioAtencion(cita.getFechaInicioAtencion());

            Vehiculo vehiculo = cita.getVehiculo();
            vista.setPlaca(vehiculo.getPlaca());
            vista.setModelYear(vehiculo.getModelYear());
            vista.setNombreMarca(vehiculo.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(vehiculo.getModelo().getNombreModelo());
            vista.setTextoTipoVehi(vehiculo.getTipoVehiculo().getTextoTipoVehi());

            Propietario propietario = vehiculo.getPropietario();
            vista.setClienteNombre(propietario.getPrimerNombre());
            vista.setClienteApellido(propietario.getPrimerApellido());
                        vista.setTelefonoPropietario(propietario.getTelefonoPropietario());

            List<CitaHasServicio> relaciones = citaHasServicioRepository.findById_IdCita(cita.getIdCita());
List<ServicioConPrecio> servicios = new ArrayList<>();
for (CitaHasServicio rel : relaciones) {
    Servicio servicio = servicioRepository.findById(rel.getId().getIdServicio()).orElse(null);
    // CORRECCIÓN: el precio real de la cita viene de TallerHasServicio
    // (el precio que ESE taller cobra por ese servicio), no de un valor
    // fijo — antes se mandaba "null" literal, por eso salía vacío
    TallerHasServicioId thsId = new TallerHasServicioId();
    thsId.setIdTaller(rel.getId().getIdTaller());
    thsId.setIdServicio(rel.getId().getIdServicio());

    java.math.BigDecimal precio = tallerHasServicioRepository.findById(thsId)
            .map(TallerHasServicio::getPrecioServicio)
            .orElse(java.math.BigDecimal.ZERO);

    if (servicio != null) {
        servicios.add(new ServicioConPrecio(servicio.getIdServicio(), servicio.getNombreServicio(), precio));
    }
}
vista.setServicios(servicios);

                             gestionMantenimientoRepository.findByCitaTaller_IdCita(cita.getIdCita())
                    .ifPresent(mant -> {
                        vista.setIdSeguimiento(mant.getIdSeguimiento());
                        vista.setEstadoMantenimiento(mant.getEstadoMantenimiento().name());
                        // AGREGADO: la plantilla mecanico-control.html los necesita
                        // para mostrar el bloque "Detalles de cierre"
                        vista.setObservacionesTecnico(mant.getObservacionesTecnico());
                        vista.setTextoGarantia(mant.getTextoGarantia());
                        vista.setGarantiaVigencia(mant.getGarantiaVigencia());
                        vista.setPrecioTotal(mant.getPrecioTotal());

                        List<TecnicoVista> tecnicos = new ArrayList<>();
                        for (Tecnico tec : mant.getTecnicos()) {
                            tecnicos.add(new TecnicoVista(tec.getNombreTecnico()));
                        }
                        vista.setTecnicosAsignados(tecnicos);
                    });

            resultado.add(vista);
        }

        return resultado;
    }

    // AGREGADO: pasa la ficha de mantenimiento a "en_cierre", con los
    // datos del cierre y los técnicos asignados
    @Transactional
    public void cerrarMantenimiento(
            Integer idCita, Integer idSeguimiento, Integer idTaller,
            String observaciones, String textoGarantia, String vigencia,
            String precioRaw, List<Integer> idsTecnicos) {

        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (cita.getEstadoCita() != EstadoCita.en_atencion
                || !cita.getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        GestionMantenimiento gestion = gestionMantenimientoRepository.findById(idSeguimiento)
                .orElseThrow(() -> new IllegalArgumentException("gestion-invalida"));

        if (!gestion.getCitaTaller().getIdCita().equals(idCita)) {
            throw new IllegalArgumentException("gestion-invalida");
        }

        // Precio: solo dígitos, igual que preg_replace('/[^0-9]/', '', ...) de tu PHP
        String precioLimpio = precioRaw == null ? "" : precioRaw.replaceAll("[^0-9]", "");
        if (precioLimpio.isEmpty()) {
            throw new IllegalArgumentException("precio-requerido");
        }
        java.math.BigDecimal precioTotal = new java.math.BigDecimal(precioLimpio);

        if (idsTecnicos == null || idsTecnicos.isEmpty()) {
            throw new IllegalArgumentException("tecnicos-requeridos");
        }

        // Seguridad: todos los técnicos deben ser de este taller
        for (Integer idTec : idsTecnicos) {
            if (!tecnicoService.perteneceATaller(idTec, idTaller)) {
                throw new IllegalArgumentException("tecnico-invalido");
            }
        }

        String obsFinal = (observaciones == null || observaciones.isBlank()) ? null : observaciones.trim();
        String garantiaFinal = (textoGarantia == null || textoGarantia.isBlank()) ? null : textoGarantia.trim();
        // Garantía es opcional: si no hay texto, no se guarda vigencia
        java.time.LocalDateTime vigenciaFinal = (garantiaFinal != null && vigencia != null && !vigencia.isBlank())
                ? java.time.LocalDateTime.parse(vigencia + "T00:00:00")
                : null;

        // Código de entrega único, mismo criterio que codigoConfirmacion
        String codigoEntrega;
        do {
            codigoEntrega = generarCodigo();
        } while (gestionMantenimientoRepository.findByCodigoEntrega(codigoEntrega).isPresent());

        gestion.setObservacionesTecnico(obsFinal);
        gestion.setPrecioTotal(precioTotal);
        gestion.setTextoGarantia(garantiaFinal);
        gestion.setGarantiaVigencia(vigenciaFinal);
        gestion.setEstadoMantenimiento(EstadoMantenimiento.en_cierre);
        gestion.setCodigoEntrega(codigoEntrega);

        Set<Tecnico> tecnicos = new HashSet<>();
        for (Integer idTec : idsTecnicos) {
            tecnicoService.listarPorTaller(idTaller).stream()
                    .filter(t -> t.getIdTecnico().equals(idTec))
                    .findFirst()
                    .ifPresent(tecnicos::add);
        }
        gestion.setTecnicos(tecnicos);

        gestionMantenimientoRepository.save(gestion);
    }

    // AGREGADO: verifica el código de entrega, pasa la ficha a "finalizada".
    // IMPORTANTE (igual que tu PHP): estadoCita NO cambia, se queda en
    // en_atencion — el sub-estado real vive en GestionMantenimiento
    @Transactional
    public void verificarEntrega(String codigo, Integer idTaller) {
        String codigoNormalizado = codigo.trim().toUpperCase();

        GestionMantenimiento gestion = gestionMantenimientoRepository.findByCodigoEntrega(codigoNormalizado)
                .filter(g -> g.getEstadoMantenimiento() == EstadoMantenimiento.en_cierre)
                .orElseThrow(() -> new IllegalArgumentException("codigo-invalido"));

        // Seguridad: la cita asociada debe pertenecer a este taller
        if (!gestion.getCitaTaller().getTaller().getIdTaller().equals(idTaller)) {
            throw new IllegalArgumentException("codigo-invalido");
        }

        gestion.setEstadoMantenimiento(EstadoMantenimiento.finalizada);
        gestion.setFechaCierre(java.time.LocalDate.now());
        gestionMantenimientoRepository.save(gestion);
    }
    
}
