package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.CitaControlVista;
import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.model.Tecnico;
import tecnidrive.tecnidrive.service.CitaTallerService;
import tecnidrive.tecnidrive.service.TallerService;
import tecnidrive.tecnidrive.service.TecnicoService;

import java.util.List;

@Controller
public class MecanicoControlController {

    @Autowired
    private TallerService tallerService;

    @Autowired
    private TecnicoService tecnicoService;

    @Autowired
    private CitaTallerService citaTallerService;

    @GetMapping("/mecanico/control")
    public String verControl(
            @RequestParam(value = "exito", required = false) String exito,
            @RequestParam(value = "error", required = false) String error,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/taller";

        List<CitaControlVista> citas = citaTallerService.listarEnAtencion(taller.getIdTaller());
        model.addAttribute("citas", citas);

        List<Tecnico> tecnicos = tecnicoService.listarPorTaller(taller.getIdTaller());
        model.addAttribute("tecnicos", tecnicos);

        if (exito != null) model.addAttribute("exito", "Acción realizada correctamente.");
        if (error != null) model.addAttribute("error", traducirError(error));

        return "mecanico/mecanico-control";
    }

    @PostMapping("/mecanico/control/agregar-tecnico")
    public String agregarTecnico(@RequestParam("nombre_tecnico") String nombre, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/control";

        if (nombre.trim().isEmpty()) {
            return "redirect:/mecanico/control?error=nombre-requerido";
        }
        if (nombre.trim().length() > 100) {
            return "redirect:/mecanico/control?error=nombre-largo";
        }

        tecnicoService.agregar(taller, nombre.trim());
        return "redirect:/mecanico/control?exito=1";
    }

    @PostMapping("/mecanico/control/eliminar-tecnico")
    public String eliminarTecnico(@RequestParam("id_tecnico") Integer idTecnico, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/control";

        try {
            tecnicoService.eliminar(idTecnico, taller.getIdTaller());
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=tecnico-no-encontrado";
        }
    }

   @PostMapping("/mecanico/control/cerrar")
    public String cerrar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("id_seguimiento") Integer idSeguimiento,
            @RequestParam(value = "observaciones", required = false) String observaciones,
            @RequestParam(value = "texto_garantia", required = false) String textoGarantia,
            @RequestParam(value = "garantia_vigencia", required = false) String vigencia,
            @RequestParam("precio_total") String precioTotal,
            // CORRECCIÓN: el HTML manda "tecnicos[]", no "tecnicos" —
            // el nombre debe coincidir exactamente con lo que envía el navegador
            @RequestParam(value = "tecnicos[]", required = false) List<Integer> tecnicos,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/control";

        try {
            citaTallerService.cerrarMantenimiento(
                    idCita, idSeguimiento, taller.getIdTaller(),
                    observaciones, textoGarantia, vigencia, precioTotal, tecnicos
            );
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=" + e.getMessage();
        }
    }

    @PostMapping("/mecanico/control/verificar-entrega")
    public String verificarEntrega(@RequestParam("codigo") String codigo, HttpSession session) {
        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        Taller taller = tallerService.obtenerTallerDelMecanico(idPersona);
        if (taller == null) return "redirect:/mecanico/control";

        if (codigo.trim().isEmpty()) {
            return "redirect:/mecanico/control?error=codigo-requerido";
        }

        try {
            citaTallerService.verificarEntrega(codigo, taller.getIdTaller());
            return "redirect:/mecanico/control?exito=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/mecanico/control?error=" + e.getMessage();
        }
    }

    private String traducirError(String codigo) {
        return switch (codigo) {
            case "nombre-requerido" -> "El nombre del técnico es obligatorio.";
            case "nombre-largo" -> "El nombre es demasiado largo.";
            case "tecnico-no-encontrado" -> "Técnico no encontrado.";
            case "cita-invalida" -> "La cita no es válida para cerrar.";
            case "gestion-invalida" -> "Ficha de mantenimiento no válida.";
            case "precio-requerido" -> "Debes indicar el precio total.";
            case "tecnicos-requeridos" -> "Debes seleccionar al menos un técnico.";
            case "tecnico-invalido" -> "Técnico no válido.";
            case "codigo-invalido" -> "Código de entrega no válido.";
            case "codigo-requerido" -> "Debes ingresar el código de entrega.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
}