package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.model.Taller;
import tecnidrive.tecnidrive.model.Tecnico;
import tecnidrive.tecnidrive.repository.TecnicoRepository;

import java.util.List;

@Service
public class TecnicoService {

    @Autowired
    private TecnicoRepository tecnicoRepository;

    public List<Tecnico> listarPorTaller(Integer idTaller) {
        return tecnicoRepository.findByTaller_IdTaller(idTaller);
    }

    public void agregar(Taller taller, String nombre) {
        Tecnico tecnico = new Tecnico();
        tecnico.setTaller(taller);
        tecnico.setNombreTecnico(nombre.trim());
        tecnicoRepository.save(tecnico);
    }

    // Verificación de pertenencia, igual que perteneceATaller() de tu PHP
    public boolean perteneceATaller(Integer idTecnico, Integer idTaller) {
        return tecnicoRepository.existsByIdTecnicoAndTaller_IdTaller(idTecnico, idTaller);
    }

    public void eliminar(Integer idTecnico, Integer idTaller) {
        if (!perteneceATaller(idTecnico, idTaller)) {
            throw new IllegalArgumentException("tecnico-invalido");
        }
        tecnicoRepository.deleteById(idTecnico);
    }
}