package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.CitaVista;
import tecnidrive.tecnidrive.service.CitaTallerService;

import java.util.List;

@Controller
public class PropietarioCitaController {

    @Autowired
    private CitaTallerService citaTallerService;

    @GetMapping("/propietario/cita")
    public String verCitas(
            @RequestParam(value = "exitoCita", required = false) String exitoCita,
            @RequestParam(value = "errorCita", required = false) String errorCita,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        List<CitaVista> citas = citaTallerService.listarCitasDelPropietario(idPersona);
        model.addAttribute("citas", citas);

        if (exitoCita != null) model.addAttribute("exitoCita", "Cita cancelada correctamente.");
        if (errorCita != null) model.addAttribute("errorCita", traducirError(errorCita));

        return "propietario/propietario-cita";
    }

    @PostMapping("/propietario/cita/cancelar")
    public String cancelar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("motivo") String motivo,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        try {
            citaTallerService.cancelarCitaPropietario(idCita, idPersona, motivo);
            return "redirect:/propietario/cita?exitoCita=1";
        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/cita?errorCita=" + e.getMessage();
        }
    }

    private String traducirError(String codigo) {
        return switch (codigo) {
            case "cita-invalida" -> "La cita seleccionada no es válida.";
            case "cita-no-cancelable" -> "Solo puedes cancelar citas que aún estén pendientes.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
}