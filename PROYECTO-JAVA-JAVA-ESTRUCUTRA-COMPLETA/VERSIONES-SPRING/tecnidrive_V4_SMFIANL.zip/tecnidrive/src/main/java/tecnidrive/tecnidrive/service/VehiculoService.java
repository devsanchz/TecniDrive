package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.dto.VehiculoVista;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class VehiculoService {

    @Autowired
    private VehiculoRepository vehiculoRepository;

    @Autowired
    private MarcaRepository marcaRepository;

    @Autowired
    private ModeloRepository modeloRepository;

    @Autowired
    private PapelVehiculoRepository papelVehiculoRepository;

    @Autowired
    private TipoDocumentoRepository tipoDocumentoRepository;

    // CORRECCIÓN: se quitó @Autowired CitaTallerService de aquí — causaba
    // una dependencia circular (VehiculoService necesitaba a CitaTallerService,
    // y CitaTallerService necesitaba a VehiculoService). El cálculo de
    // "tieneCitaActiva" ahora lo hace el Controller, que sí puede usar
    // ambos Services sin problema

    public boolean existePlaca(String placa) {
        return vehiculoRepository.existsById(placa);
    }

    // Mismo patrón "buscar o crear" que usamos en TallerService
    // para especialidad/servicio
    private Marca buscarOCrearMarca(String nombre) {
        return marcaRepository.findAll().stream()
                .filter(m -> m.getNombreMarca().equalsIgnoreCase(nombre))
                .findFirst()
                .orElseGet(() -> {
                    Marca nueva = new Marca();
                    nueva.setNombreMarca(nombre);
                    return marcaRepository.save(nueva);
                });
    }

    private Modelo buscarOCrearModelo(String nombre, Marca marca) {
        return modeloRepository.findAll().stream()
                .filter(m -> m.getNombreModelo().equalsIgnoreCase(nombre)
                        && m.getMarca().getIdMarca().equals(marca.getIdMarca()))
                .findFirst()
                .orElseGet(() -> {
                    Modelo nuevo = new Modelo();
                    nuevo.setNombreModelo(nombre);
                    nuevo.setMarca(marca);
                    return modeloRepository.save(nuevo);
                });
    }

    public void registrarVehiculo(
            String placa, String anio, Integer idTipoVehi, Integer idTipoServicio,
            String nombreMarca, String nombreModelo,
            Propietario propietario, TipoVehiculo tipoVehiculo, ServicioVehiculo servicioVehiculo) {

        Marca marca = buscarOCrearMarca(nombreMarca.trim());
        Modelo modelo = buscarOCrearModelo(nombreModelo.trim(), marca);

        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setPlaca(placa);
        vehiculo.setModelYear(anio);
        vehiculo.setEstadoVehi(true);
        vehiculo.setPropietario(propietario);
        vehiculo.setTipoVehiculo(tipoVehiculo);
        vehiculo.setModelo(modelo);
        vehiculo.setServicioVehiculo(servicioVehiculo);

        vehiculoRepository.save(vehiculo);
    }

    // AGREGADO: ya no calcula tieneCitaActiva aquí — queda en su valor
    // por defecto (false) hasta que el Controller lo actualice con datos
    // reales, usando CitaTallerService por fuera de este Service
    public List<VehiculoVista> obtenerVistaPorPropietario(Integer idPropietario) {
        List<Vehiculo> vehiculos = vehiculoRepository.findByPropietario_IdPersona(idPropietario);
        List<VehiculoVista> resultado = new ArrayList<>();

        for (Vehiculo v : vehiculos) {
            VehiculoVista vista = new VehiculoVista();
            vista.setPlaca(v.getPlaca());
            vista.setModelYear(v.getModelYear());
            vista.setEstadoVehi(v.getEstadoVehi());
            vista.setMotivoEstado(v.getMotivoEstado());
            vista.setTiposVehiculoIdTipoVehi(v.getTipoVehiculo().getIdTipoVehi());
            vista.setServicioVehiculoIdTipoServicio(v.getServicioVehiculo().getIdTipoServicio());
            vista.setNombreMarca(v.getModelo().getMarca().getNombreMarca());
            vista.setNombreModelo(v.getModelo().getNombreModelo());
            resultado.add(vista);
        }

        return resultado;
    }

    // Verificación de dueño — nunca confiamos en el placa que manda el
    // formulario sin confirmar que le pertenece a esta persona
    public Vehiculo obtenerSiEsDelPropietario(String placa, Integer idPropietario) {
        Optional<Vehiculo> vehiculoOpt = vehiculoRepository.findById(placa);
        if (vehiculoOpt.isEmpty()) return null;

        Vehiculo vehiculo = vehiculoOpt.get();
        if (!vehiculo.getPropietario().getIdPersona().equals(idPropietario)) return null;

        return vehiculo;
    }

    public void activar(Vehiculo vehiculo) {
        vehiculo.setEstadoVehi(true);
        vehiculo.setMotivoEstado(null);
        vehiculoRepository.save(vehiculo);
    }

    public void desactivar(Vehiculo vehiculo, String motivo) {
        vehiculo.setEstadoVehi(false);
        vehiculo.setMotivoEstado(motivo);
        vehiculoRepository.save(vehiculo);
    }

    public void guardarDocumento(Vehiculo vehiculo, Integer idTipoDocumento, LocalDate fechaVencimiento) {
        TipoDocumento tipoDocumento = tipoDocumentoRepository.findById(idTipoDocumento)
                .orElseThrow(() -> new RuntimeException("Tipo de documento no encontrado"));

        PapelVehiculo papel = papelVehiculoRepository
                .findByVehiculo_PlacaAndTipoDocumento_IdDocumento(vehiculo.getPlaca(), idTipoDocumento)
                .orElseGet(() -> {
                    PapelVehiculo nuevo = new PapelVehiculo();
                    nuevo.setVehiculo(vehiculo);
                    nuevo.setTipoDocumento(tipoDocumento);
                    return nuevo;
                });

        papel.setFechaVencimiento(fechaVencimiento);
        papel.setEstadoPapel(fechaVencimiento.isAfter(LocalDate.now()));

        papelVehiculoRepository.save(papel);
    }

    public List<PapelVehiculo> obtenerDocumentosDeVehiculo(String placa) {
        return papelVehiculoRepository.findByVehiculo_Placa(placa);
    }
}