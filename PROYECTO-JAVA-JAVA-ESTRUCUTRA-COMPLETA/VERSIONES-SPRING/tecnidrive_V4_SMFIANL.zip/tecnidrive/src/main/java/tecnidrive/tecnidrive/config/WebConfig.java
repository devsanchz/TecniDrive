package tecnidrive.tecnidrive.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Paths;

// Le dice a Spring: "todo lo que esté físicamente en la carpeta
// uploads/talleres (fuera del proyecto compilado) debe poder verse
// a través de la URL /uploads/talleres/nombre-del-archivo"
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String rutaAbsoluta = Paths.get("uploads/talleres").toFile().getAbsolutePath();

        registry.addResourceHandler("/uploads/talleres/**")
                .addResourceLocations("file:" + rutaAbsoluta + "/");
    }
}