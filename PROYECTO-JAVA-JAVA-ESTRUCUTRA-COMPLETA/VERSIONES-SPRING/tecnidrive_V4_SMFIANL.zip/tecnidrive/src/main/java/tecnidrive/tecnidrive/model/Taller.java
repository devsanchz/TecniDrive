package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Set;
//nuevo para horario
import java.util.ArrayList;
import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "taller")
public class Taller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_taller")
    private Integer idTaller;

    @Column(name = "foto_taller", length = 255)
    private String fotoTaller;

    @Column(name = "nombre_taller", length = 80, nullable = false)
    private String nombreTaller;

    // CORRECCIÓN: length actualizado de 150 a 175, según el nuevo script SQL
    @Column(name = "descripcion_taller", length = 175, nullable = false)
    private String descripcionTaller;

    @Column(name = "direccion_taller", length = 80, nullable = false)
    private String direccionTaller;

    @Column(name = "horario_taller", length = 150, nullable = false)
    private String horarioTaller;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "estado_taller", nullable = false)
    private Boolean estadoTaller;

    @Column(name = "motivo_estado", length = 100)
    private String motivoEstado;

    @ManyToOne
    @JoinColumn(name = "mecanicos_id_mecanico", nullable = false)
    private Mecanico mecanico;

    // AGREGADO: campo nuevo de la BD, permite al Administrador bloquear
    // un taller (por ejemplo, si incumple normas), independiente de
    // estado_taller que probablemente maneje el propio mecánico
  @Column(name = "bloqueado_admin", nullable = false)
private Boolean bloqueadoAdmin = false;

    @ManyToMany
    @JoinTable(
        name = "taller_especialidad",
        joinColumns = @JoinColumn(name = "taller_id_taller"),
        inverseJoinColumns = @JoinColumn(name = "especialidades_id_especialidad")
    )
    private Set<Especialidad> especialidades;

        // AGREGADO: método "calculado" que convierte el texto guardado
    // ("Lunes: 8-4 | Martes: cerrado") en una lista de objetos, para
    // que Thymeleaf pueda hacer th:each="bloque : ${taller.horarios}".
    // Como el @Id de esta clase está en un campo (no en un getter),
    // Hibernate usa "acceso por campo" — por eso este método NO se
    // intenta guardar en la base de datos, es solo para la vista
    public List<HorarioBloque> getHorarios() {
        List<HorarioBloque> lista = new ArrayList<>();

        if (horarioTaller == null || horarioTaller.isBlank()) {
            return lista;
        }

        for (String bloque : horarioTaller.split("\\|")) {
            String texto = bloque.trim();
            int idx = texto.indexOf(": ");
            if (idx == -1) continue;

            String dia = texto.substring(0, idx).trim();
            String hora = texto.substring(idx + 2).trim();
            lista.add(new HorarioBloque(dia, hora));
        }

        return lista;
    }

    // Clase pequeña, solo para representar cada fila de horario en la vista
    @Getter
    @Setter
    public static class HorarioBloque {
        private String dia;
        private String hora;

        public HorarioBloque(String dia, String hora) {
            this.dia = dia;
            this.hora = hora;
        }
    }
}