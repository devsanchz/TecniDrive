package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import tecnidrive.tecnidrive.model.CalificacionTaller;
import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Taller;

import java.util.List;

// "Envoltorio" de solo lectura para la vista del propietario. Junta el
// Taller real con datos que la plantilla necesita mostrar, pero que no
// son responsabilidad del modelo (como si el propietario ya lo calificó).
@Getter
@Setter
@NoArgsConstructor
public class TallerVista {

    private Integer idTaller;
    private String nombreTaller;
    private String descripcionTaller;
    private String direccionTaller;
    private String fotoTaller;
    private List<Especialidad> especialidades;
    private List<ServicioConPrecio> servicios;
    private List<Taller.HorarioBloque> horarios;

    // PENDIENTE: quedan en su valor por defecto hasta construir el
    // módulo de Calificaciones. Así la plantilla no falla al buscarlos
    private Double promedio = 0.0;
    private List<CalificacionTaller> calificaciones = List.of();
    private CalificacionTaller miCalificacion = null;
    private String rango = "";
}