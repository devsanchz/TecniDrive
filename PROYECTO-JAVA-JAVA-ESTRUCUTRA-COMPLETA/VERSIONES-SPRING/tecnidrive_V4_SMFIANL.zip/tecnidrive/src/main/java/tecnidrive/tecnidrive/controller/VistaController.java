package tecnidrive.tecnidrive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class VistaController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    //===============================
    //ENDPOINTS PARA AUTENTIFICAR
    //===============================
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/registro")
    public String registro() {
        return "registro";
    }

    @GetMapping("/rol")
    public String rol() {
        return "rol";
    }

    // CORRECCIÓN: ya no usamos Model con "paso" — como el flujo ahora
    // es con fetch() + JavaScript, recuperar.js decide qué paso mostrar
    // leyendo el parámetro ?paso= de la URL con URLSearchParams
    @GetMapping("/recuperar")
    public String recuperar() {
        return "recuperar";
    }}
    

