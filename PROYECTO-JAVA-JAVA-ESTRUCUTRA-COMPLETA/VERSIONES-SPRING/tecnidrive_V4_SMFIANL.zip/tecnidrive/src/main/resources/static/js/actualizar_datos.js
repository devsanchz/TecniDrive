document.addEventListener("DOMContentLoaded", () => {

    const profileCard  = document.getElementById("profileCard");
    const editButton   = document.getElementById("editButton");
    const saveButton   = document.getElementById("saveButton");
    const perfilError  = document.getElementById("perfilError");

    const userEmail  = document.getElementById("userEmail");
    const emailInput = document.getElementById("emailInput");

    const userTelefono  = document.getElementById("usertelefono");
    const telefonoInput = document.getElementById("telefonoInput");

    const colorEditor   = document.getElementById("colorEditor");
    const avatarColor   = document.getElementById("avatarColor");
    const profileAvatar = document.getElementById("profileAvatar");
    const profileIcon   = document.getElementById("profileIcon");

    editButton.addEventListener("click", () => {
        profileCard.classList.add("editing");

        userEmail.style.display     = "none";
        emailInput.style.display    = "inline-block";

        userTelefono.style.display  = "none";
        telefonoInput.style.display = "inline-block";

        colorEditor.style.display   = "block";

        editButton.style.display = "none";
        saveButton.style.display = "inline-block";

        ocultarError();
    });

    avatarColor.addEventListener("input", () => {
        aplicarColor(avatarColor.value);
    });

    saveButton.addEventListener("click", async () => {
        ocultarError();

        saveButton.disabled    = true;
        saveButton.textContent = "Guardando…";

        // CORRECCIÓN: quitamos avatarcolor (minúsculas) por avatarColor,
        // para que coincida exactamente con el nombre del campo en
        // ActualizarPerfilDTO (record de Java, camelCase)
        const payload = {
            email:       emailInput.value.trim(),
            telefono:    telefonoInput.value.trim(),
            avatarColor: avatarColor.value,
        };

        try {
            const data = await guardarPerfil(payload);

            if (data.ok) {
                userEmail.textContent    = emailInput.value.trim();
                userTelefono.textContent = telefonoInput.value.trim();
                aplicarColor(avatarColor.value);

                salirModoEdicion();
            } else {
                const primerError = Object.values(data.errores ?? {})[0] ?? "Error al guardar.";
                mostrarError(primerError);
                saveButton.disabled    = false;
                saveButton.textContent = "Listo";
            }

        } catch (e) {
            mostrarError("No se pudo conectar con el servidor.");
            saveButton.disabled    = false;
            saveButton.textContent = "Listo";
        }
    });

    function aplicarColor(color) {
        if (profileAvatar) profileAvatar.style.borderColor = color;
        if (profileIcon)   profileIcon.style.color         = color;
    }

    function salirModoEdicion() {
        profileCard.classList.remove("editing");

        userEmail.style.display     = "inline";
        emailInput.style.display    = "none";

        userTelefono.style.display  = "inline";
        telefonoInput.style.display = "none";

        colorEditor.style.display   = "none";

        saveButton.disabled    = false;
        saveButton.textContent = "Listo";
        saveButton.style.display = "none";
        editButton.style.display = "inline-block";
    }

    function mostrarError(msg) {
        perfilError.textContent   = msg;
        perfilError.style.display = "block";
    }

    function ocultarError() {
        perfilError.textContent   = "";
        perfilError.style.display = "none";
    }

    // CORRECCIÓN: se eliminó toda la lógica de CSRF (obtenerCsrf, headers
    // X-CSRF-TOKEN, rotación de token). Ya no aplica porque en
    // SecurityConfig desactivamos CSRF (csrf.disable()) desde el inicio
    // del proyecto — Spring no exige ese token como sí lo hacía CI4
    async function guardarPerfil(datos) {
        const respuesta = await fetch(PERFIL_URL, {
            method:  "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(datos),
        });

        return await respuesta.json();
    }
});