package tecnidrive.tecnidrive.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.dto.CalificacionMostrarDTO;
import tecnidrive.tecnidrive.dto.PropietarioTallerDTO;
import tecnidrive.tecnidrive.dto.ServicioPrecioDTO;
import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.CalificacionTallerRepository;
import tecnidrive.tecnidrive.repository.ServicioRepository;
import tecnidrive.tecnidrive.repository.TallerHasServicioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;

@Service
public class PropietarioTallerService {

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private ServicioRepository servicioRepository;

    @Autowired
    private TallerHasServicioRepository tallerHasServicioRepository;

    // AGREGADO
    @Autowired
    private CalificacionTallerRepository calificacionTallerRepository;

    // CORRECCIÓN: ahora recibe idPropietario, para calcular calificadoPorMi
public List<PropietarioTallerDTO> listarActivosParaPropietario(Integer idPropietario) {
    List<Taller> talleres = tallerRepository.findByEstadoTallerTrue();
    List<PropietarioTallerDTO> resultado = new ArrayList<>();

    for (Taller taller : talleres) {
        PropietarioTallerDTO vista = new PropietarioTallerDTO();
        vista.setIdTaller(taller.getIdTaller());
        vista.setNombreTaller(taller.getNombreTaller());
        vista.setDescripcionTaller(taller.getDescripcionTaller());
        vista.setDireccionTaller(taller.getDireccionTaller());

        String foto = taller.getFotoTaller();
        vista.setFotoTaller(
            (foto != null && !foto.isBlank())
                ? "/uploads/talleres/" + foto
                : "/img/taller-placeholder.jpg"
        );

        List<Especialidad> especialidades = new ArrayList<>(taller.getEspecialidades());
        if (especialidades.isEmpty()) {
            Especialidad sinEspecialidad = new Especialidad();
            sinEspecialidad.setNombreEspecialidad("Sin especialidad");
            especialidades.add(sinEspecialidad);
        }
        vista.setEspecialidades(especialidades);

        vista.setServicios(obtenerServiciosDelTaller(taller.getIdTaller()));
        vista.setHorarios(taller.getHorarios());

        // CORRECCIÓN: se pasa idPropietario
vista.setCalificaciones(obtenerCalificaciones(taller.getIdTaller(), idPropietario));
vista.setPromedio(calcularPromedio(vista.getCalificaciones()));

        // AGREGADO
        vista.setCalificadoPorMi(
            calificacionTallerRepository.existsByTaller_IdTallerAndPropietario_IdPersona(
                    taller.getIdTaller(), idPropietario)
        );

        resultado.add(vista);
    }

    return resultado;
}

 // CORRECCIÓN: ahora recibe idPropietario, para calcular esMia
private List<CalificacionMostrarDTO> obtenerCalificaciones(Integer idTaller, Integer idPropietario) {
    List<CalificacionTaller> calificaciones = calificacionTallerRepository
            .findByTaller_IdTallerAndEstadoOrderByFechaRegistroDesc(idTaller, EstadoCalificacion.aprobada);

    List<CalificacionMostrarDTO> resultado = new ArrayList<>();
    for (CalificacionTaller c : calificaciones) {
        Propietario p = c.getPropietario();
        String nombre = p.getPrimerNombre() + " " + p.getPrimerApellido();
        boolean esMia = p.getIdPersona().equals(idPropietario);

        resultado.add(new CalificacionMostrarDTO(
                c.getIdCalificacion(),
                nombre,
                p.getAvatarColor(),
                c.getPuntuacion(),
                c.getComentario(),
                c.getFechaRegistro(),
                esMia,
                c.getFiltroPuntuacion() // AGREGADO
        ));
    }
    return resultado;
}

    private Double calcularPromedio(List<CalificacionMostrarDTO> calificaciones) {
        if (calificaciones.isEmpty()) return 0.0;

        double suma = calificaciones.stream()
                .mapToInt(CalificacionMostrarDTO::puntuacion)
                .sum();

        return Math.round((suma / calificaciones.size()) * 10.0) / 10.0;
    }

    private List<ServicioPrecioDTO> obtenerServiciosDelTaller(Integer idTaller) {
        List<TallerHasServicio> relaciones = tallerHasServicioRepository.findById_IdTaller(idTaller);
        List<ServicioPrecioDTO> resultado = new ArrayList<>();

        for (TallerHasServicio relacion : relaciones) {
            Servicio servicio = servicioRepository.findById(relacion.getId().getIdServicio())
                    .orElseThrow(() -> new RuntimeException("Servicio no encontrado"));

            resultado.add(new ServicioPrecioDTO(
                    servicio.getIdServicio(),
                    servicio.getNombreServicio(),
                    relacion.getPrecioServicio()
            ));
        }

        return resultado;
    }


    // AGREGADO: usa el procedimiento almacenado para agrupar talleres por
// rango de estrellas (redondeando el promedio a la estrella más cercana)
public Map<String, Integer> calcularConteos() {
    List<Object[]> filas = tallerRepository.obtenerPromediosCalificaciones(null);

    int cinco = 0;
    int medio = 0;
    int bajo = 0;

    for (Object[] fila : filas) {
        // Columnas del procedimiento, en orden:
        // 0=id_taller, 1=nombre_taller, 2=total_calificaciones,
        // 3=promedio_estrellas, 4=categoria_valoracion
        Object promedioObj = fila[3];

        // Si el taller no tiene ninguna calificación, promedio_estrellas
        // viene NULL (por el LEFT JOIN) — lo saltamos, no cuenta en ningún rango
        if (promedioObj == null) continue;

        double promedio = ((Number) promedioObj).doubleValue();
        long estrellasRedondeadas = Math.round(promedio);

        if (estrellasRedondeadas == 5) {
            cinco++;
        } else if (estrellasRedondeadas >= 3) {
            medio++;
        } else if (estrellasRedondeadas >= 1) {
            bajo++;
        }
    }

    Map<String, Integer> conteos = new HashMap<>();
    conteos.put("cinco", cinco);
    conteos.put("medio", medio);
    conteos.put("bajo", bajo);
    return conteos;
}
}