package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class PropietarioCitaDTO {

    private Integer idCita;
    private LocalDateTime fechaCita;
    private LocalDateTime fechaRegistro;
    private String estadoCita;
    private String claseEstado;
    private String textoEstado;
    private String codigoConfirmacion;
    private String problemaContexto;
    private String motivoCancelacion;

    // AGREGADO: necesario para el formulario de calificación (id_taller oculto)
    private Integer idTaller;

    private String nombreTaller;
    private String direccionTaller;
    private String mecanicoNombre;
    private String mecanicoApellido;
    private Long telefonoMecanico;

    private String placa;
    private String nombreMarca;
    private String nombreModelo;
    private String modelYear;
    private String textoTipoVehi;

    private List<ServicioPrecioDTO> servicios;

    private String estadoMantenimiento;
    private String observacionesTecnico;
    private BigDecimal precioTotal;
    private String codigoEntrega;

    private String textoGarantia;
    private LocalDateTime garantiaVigencia;

    // CORRECCIÓN: antes "yaCalificoTaller" — ahora es por cita, no por taller
private Boolean yaCalificoCita = false;
}