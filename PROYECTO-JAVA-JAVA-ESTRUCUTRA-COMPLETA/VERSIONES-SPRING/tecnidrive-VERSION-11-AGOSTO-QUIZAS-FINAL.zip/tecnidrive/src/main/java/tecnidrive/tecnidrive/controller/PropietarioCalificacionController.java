package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.service.PropietarioCalificacionService;

@Controller
public class PropietarioCalificacionController {

    @Autowired
    private PropietarioCalificacionService propietarioCalificacionService;

    @PostMapping("/propietario/calificacion/registrar")
    public String registrar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("id_taller") Integer idTaller,
            @RequestParam("puntuacion") Integer puntuacion,
            @RequestParam(value = "comentario", required = false) String comentario,
            @RequestParam(value = "filtro_motivo", required = false) String filtroMotivo,
            @RequestParam(value = "filtro_otro", required = false) String filtroOtro,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        String filtroFinal = "otro".equals(filtroMotivo) ? filtroOtro : filtroMotivo;

        try {
            propietarioCalificacionService.registrarCalificacion(
                    idCita, idTaller, idPersona, puntuacion, comentario, filtroFinal
            );
            return "redirect:/propietario/cita?exito=calificada";
        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/cita?error=" + e.getMessage();
        }
    }

    // AGREGADO
    @PostMapping("/propietario/calificacion/actualizar")
    public String actualizar(
            @RequestParam("id_calificacion") Integer idCalificacion,
            @RequestParam("puntuacion") Integer puntuacion,
            @RequestParam(value = "comentario", required = false) String comentario,
            @RequestParam(value = "filtro_motivo", required = false) String filtroMotivo,
            @RequestParam(value = "filtro_otro", required = false) String filtroOtro,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        String filtroFinal = "otro".equals(filtroMotivo) ? filtroOtro : filtroMotivo;

        try {
            propietarioCalificacionService.actualizarCalificacion(
                    idCalificacion, idPersona, puntuacion, comentario, filtroFinal
            );
            return "redirect:/propietario/taller?exito=actualizada";
        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/taller?error=" + e.getMessage();
        }
    }

    // AGREGADO
    @PostMapping("/propietario/calificacion/eliminar")
    public String eliminar(
            @RequestParam("id_calificacion") Integer idCalificacion,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        try {
            propietarioCalificacionService.eliminarCalificacion(idCalificacion, idPersona);
            return "redirect:/propietario/taller?exito=eliminada";
        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/taller?error=" + e.getMessage();
        }
    }
}