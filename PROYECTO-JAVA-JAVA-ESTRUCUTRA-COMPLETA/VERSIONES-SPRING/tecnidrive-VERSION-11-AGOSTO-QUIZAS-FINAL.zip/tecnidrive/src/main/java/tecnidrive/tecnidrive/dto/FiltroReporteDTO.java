package tecnidrive.tecnidrive.dto;

// DTO combinado SOLO PARA PRUEBA: junta los campos de los dos formularios
// (reporte general + reporte específico) en una sola clase, para no crear
// dos DTOs todavía. Cuando implementemos la lógica real, esto se separa
// en FiltroReporteGeneralDTO y FiltroReporteEspecificoDTO.
public class FiltroReporteDTO {

    // Campos del formulario "Reporte general"
    private String estado = "todos";
    private String fechaInicio;
    private String fechaFin;
    private Double promedioMinimo;
    private String ordenarPor = "promedio_desc";

    // Campos del formulario "Reporte específico"
    private Integer idServicio;
    private Integer puntuacionMaxima = 3;
    private String motivo;
    private Integer idTaller;

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(String fechaInicio) { this.fechaInicio = fechaInicio; }

    public String getFechaFin() { return fechaFin; }
    public void setFechaFin(String fechaFin) { this.fechaFin = fechaFin; }

    public Double getPromedioMinimo() { return promedioMinimo; }
    public void setPromedioMinimo(Double promedioMinimo) { this.promedioMinimo = promedioMinimo; }

    public String getOrdenarPor() { return ordenarPor; }
    public void setOrdenarPor(String ordenarPor) { this.ordenarPor = ordenarPor; }

    public Integer getIdServicio() { return idServicio; }
    public void setIdServicio(Integer idServicio) { this.idServicio = idServicio; }

    public Integer getPuntuacionMaxima() { return puntuacionMaxima; }
    public void setPuntuacionMaxima(Integer puntuacionMaxima) { this.puntuacionMaxima = puntuacionMaxima; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public Integer getIdTaller() { return idTaller; }
    public void setIdTaller(Integer idTaller) { this.idTaller = idTaller; }
}