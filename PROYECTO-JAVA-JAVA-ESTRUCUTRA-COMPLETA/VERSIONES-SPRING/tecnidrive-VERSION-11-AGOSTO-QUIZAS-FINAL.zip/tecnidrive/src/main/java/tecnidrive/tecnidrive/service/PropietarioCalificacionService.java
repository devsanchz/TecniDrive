package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tecnidrive.tecnidrive.model.*;
import tecnidrive.tecnidrive.repository.CalificacionTallerRepository;
import tecnidrive.tecnidrive.repository.CitaTallerRepository;
import tecnidrive.tecnidrive.repository.PropietarioRepository;
import tecnidrive.tecnidrive.repository.TallerRepository;

@Service
public class PropietarioCalificacionService {

    @Autowired
    private CalificacionTallerRepository calificacionTallerRepository;

    @Autowired
    private TallerRepository tallerRepository;

    @Autowired
    private PropietarioRepository propietarioRepository;

    @Autowired
    private CitaTallerRepository citaTallerRepository;

    public boolean yaCalifico(Integer idCita) {
        return calificacionTallerRepository.existsByCitaTaller_IdCita(idCita);
    }

    @Transactional
    public void registrarCalificacion(
            Integer idCita, Integer idTaller, Integer idPropietario,
            Integer puntuacion, String comentario, String filtroPuntuacion) {

        if (puntuacion == null || puntuacion < 1 || puntuacion > 5) {
            throw new IllegalArgumentException("puntuacion-invalida");
        }

        if (yaCalifico(idCita)) {
            throw new IllegalArgumentException("ya-calificado");
        }

        CitaTaller cita = citaTallerRepository.findById(idCita)
                .orElseThrow(() -> new IllegalArgumentException("cita-invalida"));

        if (!cita.getVehiculo().getPropietario().getIdPersona().equals(idPropietario)) {
            throw new IllegalArgumentException("cita-invalida");
        }

        Taller taller = tallerRepository.findById(idTaller)
                .orElseThrow(() -> new IllegalArgumentException("taller-invalido"));

        Propietario propietario = propietarioRepository.findById(idPropietario)
                .orElseThrow(() -> new IllegalArgumentException("propietario-invalido"));

        String comentarioLimpio = (comentario == null || comentario.isBlank()) ? null : comentario.trim();
        String filtroLimpio = (filtroPuntuacion == null || filtroPuntuacion.isBlank()) ? null : filtroPuntuacion.trim();

        CalificacionTaller calificacion = new CalificacionTaller();
        calificacion.setPuntuacion(puntuacion);
        calificacion.setComentario(comentarioLimpio);
        calificacion.setFiltroPuntuacion(filtroLimpio);
        calificacion.setEstado(comentarioLimpio != null ? EstadoCalificacion.pendiente : EstadoCalificacion.aprobada);
        calificacion.setVisto(false);
        calificacion.setTaller(taller);
        calificacion.setPropietario(propietario);
        calificacion.setCitaTaller(cita);

        calificacionTallerRepository.save(calificacion);
    }

    // AGREGADO:
    // FLUJO:
    // 1. Validamos puntuación.
    // 2. Buscamos la calificación.
    // 3. Verificamos que sea del propietario en sesión (nunca confiamos
    //    en el id que manda el formulario sin confirmar el dueño).
    // 4. Actualizamos, y si agrega/cambia comentario, vuelve a "pendiente"
    //    (mismo criterio que usaba tu PHP original).
    @Transactional
    public void actualizarCalificacion(
            Integer idCalificacion, Integer idPropietario,
            Integer puntuacion, String comentario, String filtroPuntuacion) {

        if (puntuacion == null || puntuacion < 1 || puntuacion > 5) {
            throw new IllegalArgumentException("puntuacion-invalida");
        }

        CalificacionTaller calificacion = calificacionTallerRepository.findById(idCalificacion)
                .orElseThrow(() -> new IllegalArgumentException("calificacion-invalida"));

        if (!calificacion.getPropietario().getIdPersona().equals(idPropietario)) {
            throw new IllegalArgumentException("calificacion-invalida");
        }

        String comentarioLimpio = (comentario == null || comentario.isBlank()) ? null : comentario.trim();
        String filtroLimpio = (filtroPuntuacion == null || filtroPuntuacion.isBlank()) ? null : filtroPuntuacion.trim();

        calificacion.setPuntuacion(puntuacion);
        calificacion.setComentario(comentarioLimpio);
        calificacion.setFiltroPuntuacion(filtroLimpio);
        calificacion.setEstado(comentarioLimpio != null ? EstadoCalificacion.pendiente : EstadoCalificacion.aprobada);

        calificacionTallerRepository.save(calificacion);
    }



    
    // AGREGADO: mismo criterio de verificación de dueño antes de borrar
    @Transactional
    public void eliminarCalificacion(Integer idCalificacion, Integer idPropietario) {
        CalificacionTaller calificacion = calificacionTallerRepository.findById(idCalificacion)
                .orElseThrow(() -> new IllegalArgumentException("calificacion-invalida"));

        if (!calificacion.getPropietario().getIdPersona().equals(idPropietario)) {
            throw new IllegalArgumentException("calificacion-invalida");
        }

        calificacionTallerRepository.deleteById(idCalificacion);
    }
}