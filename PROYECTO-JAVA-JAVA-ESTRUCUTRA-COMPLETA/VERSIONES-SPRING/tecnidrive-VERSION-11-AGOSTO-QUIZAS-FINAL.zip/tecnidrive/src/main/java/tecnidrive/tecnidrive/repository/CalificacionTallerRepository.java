package tecnidrive.tecnidrive.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tecnidrive.tecnidrive.model.CalificacionTaller;
import tecnidrive.tecnidrive.model.EstadoCalificacion;

import java.util.List;

public interface CalificacionTallerRepository extends JpaRepository<CalificacionTaller, Integer> {

    boolean existsByCitaTaller_IdCita(Integer idCita);

    // AGREGADO: solo las aprobadas, más recientes primero — para mostrarlas
    List<CalificacionTaller> findByTaller_IdTallerAndEstadoOrderByFechaRegistroDesc(
            Integer idTaller, EstadoCalificacion estado);

              // AGREGADO: para el botón "Mis puntuaciones de talleres" — pregunta a
    // nivel de taller (sin importar en cuál cita se hizo la calificación)
    boolean existsByTaller_IdTallerAndPropietario_IdPersona(Integer idTaller, Integer idPropietario);
}