package tecnidrive.tecnidrive.dto;

import java.time.LocalDateTime;

public record CalificacionMostrarDTO(
        Integer idCalificacion,
        String nombrePropietario,
        String avatarColor,
        Integer puntuacion,
        String comentario,
        LocalDateTime fechaRegistro,
        Boolean esMia,
        String filtroPuntuacion // AGREGADO: para prellenar el <select> al editar
) {
}