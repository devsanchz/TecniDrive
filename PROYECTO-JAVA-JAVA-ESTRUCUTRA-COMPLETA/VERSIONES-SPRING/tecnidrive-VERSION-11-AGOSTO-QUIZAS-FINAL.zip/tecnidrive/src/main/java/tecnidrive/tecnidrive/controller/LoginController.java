package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.LoginRequestDTO;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.model.Rol;
import tecnidrive.tecnidrive.service.LoginService;
import java.util.Optional;

// CORRECCIÓN: ya no queda ningún método JSON. La clase entera vuelve
// a ser un @Controller tradicional, sin @ResponseBody en ningún lado
@Controller
public class LoginController {

    @Autowired
    private LoginService loginService;

    @Autowired
    private PasswordEncoder passwordEncoder;


//METODO 1: crear model para mostrar datos con la plantilla
   @GetMapping("/login")
public String mostrarFormulario(
        @RequestParam(required = false) String registro,
        @RequestParam(required = false) String logout, //cerrar sesion
         @RequestParam(required = false) String recuperacion, // contraseña nueva
        Model model) {

    model.addAttribute("datos", new LoginRequestDTO());

    if ("exitoso".equals(registro)) {
        model.addAttribute("registroExitoso", true);
    }

    //mensaje cierrar seson
    if ("exitoso".equals(logout)) {
        model.addAttribute("logoutExitoso", true);
    }
      if ("exitoso".equals(recuperacion))
     model.addAttribute("recuperacionExitosa", true);

    return "login";
}
//METODO 2: Tomar los datos y verificar que esten bien 
    @PostMapping("/login")
    public String login(
            @Valid @ModelAttribute("datos") LoginRequestDTO datos,
            BindingResult resultado,
            HttpSession session,
            Model model) {

        if (resultado.hasErrors()) {
            return "login";
        }
        Optional<Persona> personaOpt = loginService.buscarPorEmail(datos.getEmail());

        boolean credencialesValidas = personaOpt.isPresent()
                && passwordEncoder.matches(datos.getPassword(), personaOpt.get().getPasswordHash());

        if (!credencialesValidas) {
            model.addAttribute("errorLogin", "Correo o contraseña incorrectos");
            return "login";
        }
       Persona persona = personaOpt.get();
        Rol rolPersona = persona.getRoles().iterator().next();

        session.setAttribute("idPersona", persona.getIdPersona());
        session.setAttribute("email", persona.getEmail());
        session.setAttribute("rol", rolPersona.getTextoRol());

        String redirectUrl = switch (rolPersona.getTextoRol()) {
            case "Administrador" -> "/panel-admin";
            case "Propietario" -> "/panel-propietario";
            case "Mecanico" -> "/panel-mecanico";
            default -> "/login";
        };

        return "redirect:" + redirectUrl;
    }

//METODO 3: Cerrar sesion el los paneles
   @PostMapping("/logout")
public String logout(HttpSession session) {
    session.invalidate();
    return "redirect:/login?logout=exitoso";
}
}