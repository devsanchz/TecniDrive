package tecnidrive.tecnidrive.model;

// Solo estos dos por ahora — "rechazada" se agrega cuando construyamos
// el módulo de aprobación (mecánico/admin revisando calificaciones)
public enum EstadoCalificacion {
    pendiente,
    aprobada
}