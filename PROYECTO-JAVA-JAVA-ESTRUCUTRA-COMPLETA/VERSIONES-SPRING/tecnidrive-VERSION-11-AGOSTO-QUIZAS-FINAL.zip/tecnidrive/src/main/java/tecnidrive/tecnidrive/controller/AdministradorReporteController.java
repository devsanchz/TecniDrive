package tecnidrive.tecnidrive.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import tecnidrive.tecnidrive.dto.FiltroReporteDTO;

import java.util.Collections;

@Controller
public class AdministradorReporteController {

    // Solo muestra la página con los formularios vacíos, sin resultados todavía
    @GetMapping("/admin/reporte")
    public String verReportes(Model model) {
        prepararModeloComun(model);
        model.addAttribute("filtroGeneral", new FiltroReporteDTO());
        model.addAttribute("filtroEspecifico", new FiltroReporteDTO());
        model.addAttribute("tabActivo", "general");
        return "admin/admin-reporte";
    }

    // Se ejecuta cuando se envía el formulario del reporte GENERAL
    @GetMapping("/administrador/reportes/talleres/general")
    public String reporteGeneral(@ModelAttribute("filtroGeneral") FiltroReporteDTO filtroGeneral,
                                  Model model) {

        prepararModeloComun(model);
        model.addAttribute("filtroEspecifico", new FiltroReporteDTO());
        model.addAttribute("tabActivo", "general");

        // TODO: cuando exista el Service, reemplazar por la consulta real
        model.addAttribute("resultadosGeneral", Collections.emptyList());

        return "admin/admin-reporte";
    }

    // Se ejecuta cuando se envía el formulario del reporte ESPECÍFICO
    @GetMapping("/administrador/reportes/talleres/especifico")
    public String reporteEspecifico(@ModelAttribute("filtroEspecifico") FiltroReporteDTO filtroEspecifico,
                                     Model model) {

        prepararModeloComun(model);
        model.addAttribute("filtroGeneral", new FiltroReporteDTO());
        model.addAttribute("tabActivo", "especifico");

        // TODO: cuando exista el Service, reemplazar por la consulta real
        model.addAttribute("resultadosEspecifico", Collections.emptyList());

        return "admin/admin-reporte";
    }

    // Listas que necesitan los <select> de servicios y talleres en las TRES rutas
    private void prepararModeloComun(Model model) {
        model.addAttribute("servicios", Collections.emptyList());
        model.addAttribute("talleres", Collections.emptyList());
    }
}