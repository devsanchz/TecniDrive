package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tecnidrive.tecnidrive.dto.PropietarioCitaDTO;
import tecnidrive.tecnidrive.service.PropietarioCalificacionService;
import tecnidrive.tecnidrive.service.PropietarioCitaTallerService;

import java.util.List;

@Controller
public class PropietarioCitaController {

    @Autowired
    private PropietarioCitaTallerService propietarioCitaTallerService;

    @Autowired
    private PropietarioCalificacionService propietarioCalificacionService;

    @GetMapping("/propietario/cita")
    public String verCitas(
            @RequestParam(value = "exito", required = false) String exito,
            @RequestParam(value = "error", required = false) String error,
            HttpSession session,
            Model model) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        List<PropietarioCitaDTO> citas = propietarioCitaTallerService.listarCitasDelPropietario(idPersona);

        // CORRECCIÓN: ahora se pregunta por la cita, no por el taller
        for (PropietarioCitaDTO c : citas) {
            if ("finalizada".equals(c.getEstadoMantenimiento())) {
                c.setYaCalificoCita(propietarioCalificacionService.yaCalifico(c.getIdCita()));
            }
        }

        model.addAttribute("citas", citas);

        if (exito != null) model.addAttribute("exitoCita", traducirExito(exito));
        if (error != null) model.addAttribute("errorCita", traducirError(error));

        return "propietario/propietario-cita";
    }

    @PostMapping("/propietario/cita/agendar")
    public String agendarCita(
            @RequestParam("id_taller") Integer idTaller,
            @RequestParam("placa") String placa,
            @RequestParam("fecha_cita") String fechaCita,
            @RequestParam("hora_cita") String horaCita,
            @RequestParam(value = "problema", required = false) String problema,
            @RequestParam(value = "servicios[]", required = false) List<Integer> servicios,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        try {
            propietarioCitaTallerService.agendarCita(
                    idTaller, placa.trim().toUpperCase(), fechaCita, horaCita,
                    problema, servicios, idPersona
            );
            return "redirect:/propietario/cita?exito=agendada";

        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/cita?error=" + e.getMessage();
        }
    }

    @PostMapping("/propietario/cita/cancelar")
    public String cancelar(
            @RequestParam("id_cita") Integer idCita,
            @RequestParam("motivo") String motivo,
            HttpSession session) {

        Integer idPersona = (Integer) session.getAttribute("idPersona");
        if (idPersona == null) return "redirect:/login";

        try {
            propietarioCitaTallerService.cancelarCitaPropietario(idCita, idPersona, motivo);
            return "redirect:/propietario/cita?exito=cancelada";
        } catch (IllegalArgumentException e) {
            return "redirect:/propietario/cita?error=" + e.getMessage();
        }
    }

    private String traducirExito(String codigo) {
        return switch (codigo) {
            case "agendada" -> "Cita agendada correctamente. Estado: pendiente de confirmación.";
            case "cancelada" -> "Cita cancelada correctamente.";
            case "calificada" -> "¡Gracias! Tu calificación fue registrada correctamente.";
            default -> "Operación realizada correctamente.";
        };
    }

    private String traducirError(String codigo) {
        return switch (codigo) {
            case "cita-invalida" -> "La cita seleccionada no es válida.";
            case "cita-no-cancelable" -> "Solo puedes cancelar citas que aún estén pendientes.";
            case "vehiculo-invalido" -> "El vehículo seleccionado no es válido.";
            case "vehiculo-ocupado" -> "Ese vehículo ya tiene una cita activa. Espera a que finalice antes de agendar otra.";
            case "taller-invalido" -> "El taller seleccionado no es válido.";
            case "puntuacion-invalida" -> "Selecciona una puntuación entre 1 y 5 estrellas.";
            case "ya-calificado" -> "Ya calificaste esta cita.";
            case "propietario-invalido" -> "No se pudo identificar tu cuenta.";
            default -> "Ocurrió un error al procesar la solicitud.";
        };
    }
}