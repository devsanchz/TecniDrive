package tecnidrive.tecnidrive.repository;

import tecnidrive.tecnidrive.model.Taller;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TallerRepository extends JpaRepository<Taller, Integer> {

    // Necesario para cuando el mecánico logueado quiera ver
    // únicamente SU(s) taller(es), no los de todos
    List<Taller> findByMecanico_IdPersona(Integer idPersona);

       // AGREGADO: para listar solo los talleres activos (los que el
    // propietario debería poder ver y elegir)
    List<Taller> findByEstadoTallerTrue();


    // AGREGADO: llama al procedimiento almacenado sp_promedio_calificaciones.
// Pasando null en idTaller, el procedimiento devuelve TODOS los talleres
// activos con su promedio (así está escrito el WHERE en tu SQL:
// "p_id_taller IS NULL OR t.id_taller = p_id_taller")
@Query(value = "CALL sp_promedio_calificaciones(:idTaller)", nativeQuery = true)
List<Object[]> obtenerPromediosCalificaciones(@Param("idTaller") Integer idTaller);
}