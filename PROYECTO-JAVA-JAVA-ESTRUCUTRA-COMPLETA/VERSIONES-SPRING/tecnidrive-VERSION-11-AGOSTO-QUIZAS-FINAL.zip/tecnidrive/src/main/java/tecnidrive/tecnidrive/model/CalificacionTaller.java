package tecnidrive.tecnidrive.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "calificacion_taller")
public class CalificacionTaller {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_calificacion")
    private Integer idCalificacion;

    @Column(name = "fecha_registro", nullable = false, updatable = false, insertable = false)
    private LocalDateTime fechaRegistro;

    @Column(name = "puntuacion", nullable = false)
    private Integer puntuacion;

    @Column(name = "filtro_puntuacion", length = 50)
    private String filtroPuntuacion;

    @Column(name = "comentario", columnDefinition = "TEXT")
    private String comentario;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false)
    private EstadoCalificacion estado;

    @Column(name = "visto", nullable = false)
    private Boolean visto;

    @ManyToOne
    @JoinColumn(name = "taller_id_taller", nullable = false)
    private Taller taller;

    @ManyToOne
    @JoinColumn(name = "propietarios_id_propietario", nullable = false)
    private Propietario propietario;

    // AGREGADO: la cita específica que se está calificando. @OneToOne +
    // unique en la BD garantiza que una cita no se pueda calificar dos veces
    @OneToOne
    @JoinColumn(name = "cita_taller_id_cita", nullable = false, unique = true)
    private CitaTaller citaTaller;
}