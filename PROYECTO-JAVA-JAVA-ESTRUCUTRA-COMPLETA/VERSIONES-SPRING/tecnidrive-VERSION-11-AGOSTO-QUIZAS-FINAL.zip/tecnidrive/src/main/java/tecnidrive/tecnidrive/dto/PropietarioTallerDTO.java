package tecnidrive.tecnidrive.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import tecnidrive.tecnidrive.model.Especialidad;
import tecnidrive.tecnidrive.model.Taller;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class PropietarioTallerDTO {

    private Integer idTaller;
    private String nombreTaller;
    private String descripcionTaller;
    private String direccionTaller;
    private String fotoTaller;
    private List<Especialidad> especialidades;
    private List<ServicioPrecioDTO> servicios;
    private List<Taller.HorarioBloque> horarios;

    // AGREGADO: promedio de estrellas y lista de reseñas aprobadas
    private Double promedio = 0.0;
    private List<CalificacionMostrarDTO> calificaciones;

    // AGREGADO: si el propietario en sesión ya calificó este taller
// (en cualquiera de sus citas), para el filtro "Mis puntuaciones"
private Boolean calificadoPorMi = false;
}