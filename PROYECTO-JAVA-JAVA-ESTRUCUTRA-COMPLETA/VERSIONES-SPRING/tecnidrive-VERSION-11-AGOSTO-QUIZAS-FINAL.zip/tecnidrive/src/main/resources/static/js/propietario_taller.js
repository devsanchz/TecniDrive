document.addEventListener("DOMContentLoaded", () => {

    const backdrop = document.getElementById("modalBackdrop");

    function cerrarTarjeta(card) {
        const vistaCompacta = card.querySelector(".vista-compacta");
        const contenido     = card.querySelector(".contenido-taller");
        contenido.classList.remove("visible");
        card.classList.replace("expandida", "compacta");
        backdrop.classList.remove("activo");
        setTimeout(() => vistaCompacta.classList.remove("oculto"), 200);
    }

    document.querySelectorAll(".card-taller").forEach((card) => {
        const header        = card.querySelector(".header-taller");
        const btnCerrar     = card.querySelector(".btn-cerrar");
        const vistaCompacta = card.querySelector(".vista-compacta");
        const contenido     = card.querySelector(".contenido-taller");

        header.addEventListener("click", (e) => {
            if (e.target.closest(".btn-cerrar")) return;
            if (card.classList.contains("compacta")) {
                vistaCompacta.classList.add("oculto");
                card.classList.replace("compacta", "expandida");
                backdrop.classList.add("activo");
                setTimeout(() => contenido.classList.add("visible"), 80);
            }
        });

        btnCerrar.addEventListener("click", (e) => {
            e.stopPropagation();
            cerrarTarjeta(card);
        });
    });

    backdrop?.addEventListener("click", () => {
        const abierta = document.querySelector(".card-taller.expandida");
        if (abierta) cerrarTarjeta(abierta);
    });

    const buscador      = document.querySelector(".buscador-wrapper input");
    const filtro        = document.getElementById("filtroEspecialidad");
    const btnMisResenas = document.querySelector(".misreseñas");
    let soloMisResenas  = false;

    // FLUJO: filtra las tarjetas combinando texto + especialidad + "solo mis reseñas"
    function filtrarTarjetas() {
        const texto = buscador?.value.toLowerCase() ?? "";
        const esp   = filtro?.value ?? "todos";

        document.querySelectorAll(".card-taller").forEach(card => {
            const nombre       = card.dataset.nombre       ?? "";
            const direccion    = card.dataset.direccion    ?? "";
            const especialidad = card.dataset.especialidad ?? "";

            const coincideTexto = texto === "" ||
                nombre.includes(texto) || direccion.includes(texto) ||
                especialidad.toLowerCase().includes(texto);
            const coincideEsp = esp === "todos" || especialidad === esp;
            // AGREGADO: si el filtro está activo, solo se muestran los calificados
            const coincideMio = !soloMisResenas || card.dataset.calificado === "1";

            card.style.display = (coincideTexto && coincideEsp && coincideMio) ? "" : "none";
        });
    }

    // AGREGADO: toggle del botón
    if (btnMisResenas) {
        btnMisResenas.addEventListener("click", () => {
            soloMisResenas = !soloMisResenas;
            btnMisResenas.classList.toggle("activo", soloMisResenas);
            filtrarTarjetas();
        });
    }

    buscador?.addEventListener("input", filtrarTarjetas);
    filtro?.addEventListener("change", filtrarTarjetas);
});


//==================================================
//PARA LA CALIFIACION
document.addEventListener("DOMContentLoaded", () => {

    document.querySelectorAll(".calificacion-estrellas").forEach((contenedor) => {

        const estrellas     = contenedor.querySelectorAll(".star");
        const inputPunt     = contenedor.querySelector(".input-puntuacion");
        const form          = contenedor.closest("form");
        const bloqueResena  = form ? form.querySelector(".bloque-resena") : null;
        const errorMsg      = form ? form.querySelector(".cali-error") : null;

        let puntuacionActual = inputPunt ? parseInt(inputPunt.value) : 0;

        // AGREGADO: pinta las estrellas ya elegidas apenas carga la página
        // (necesario para el formulario de EDICIÓN, que abre con un valor previo)
        pintarEstrellas(estrellas, puntuacionActual);

        estrellas.forEach((estrella) => {

            estrella.addEventListener("mouseover", () => {
                const valorHover = parseInt(estrella.dataset.value);
                pintarEstrellas(estrellas, valorHover);
            });

            estrella.addEventListener("mouseleave", () => {
                pintarEstrellas(estrellas, puntuacionActual);
            });

            estrella.addEventListener("click", () => {
                puntuacionActual = parseInt(estrella.dataset.value);
                if (inputPunt) inputPunt.value = puntuacionActual;

                pintarEstrellas(estrellas, puntuacionActual);

                if (bloqueResena) bloqueResena.classList.remove("oculto-js");
                if (errorMsg) errorMsg.style.display = "none";
            });
        });

        if (form) {
            form.addEventListener("submit", (e) => {
                if (puntuacionActual < 1) {
                    e.preventDefault();
                    if (errorMsg) {
                        errorMsg.textContent = "Selecciona al menos 1 estrella.";
                        errorMsg.style.display = "block";
                    }
                }
            });
        }
    });

    function pintarEstrellas(estrellas, hasta) {
        estrellas.forEach((e) => {
            const valor = parseInt(e.dataset.value);
            e.classList.toggle("activa", valor <= hasta);
        });
    }
});

// AGREGADO: muestra/oculta el formulario de edición de una calificación
function toggleEditarCalificacion(idCalificacion) {
    const div = document.getElementById('editar-cal-' + idCalificacion);
    if (div) div.classList.toggle('oculto-js');
}