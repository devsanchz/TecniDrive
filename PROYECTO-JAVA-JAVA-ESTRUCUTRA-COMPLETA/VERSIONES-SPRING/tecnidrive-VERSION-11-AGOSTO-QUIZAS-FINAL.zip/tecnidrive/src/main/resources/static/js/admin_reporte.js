 // Cambia entre el panel "general" y "especifico" sin recargar la página.
    // No depende de <details>, así que no hay que detectar cuál está abierto:
    // el atributo data-tab del botón nos dice directamente qué panel mostrar.
    document.addEventListener("DOMContentLoaded", () => {
        const botones = document.querySelectorAll(".tab-btn");
        const paneles = document.querySelectorAll(".panel");

        botones.forEach(boton => {
            boton.addEventListener("click", () => {
                botones.forEach(b => b.classList.remove("is-active"));
                paneles.forEach(p => p.classList.remove("is-active"));

                boton.classList.add("is-active");
                document.getElementById("panel-" + boton.dataset.tab).classList.add("is-active");
            });
        });
    });