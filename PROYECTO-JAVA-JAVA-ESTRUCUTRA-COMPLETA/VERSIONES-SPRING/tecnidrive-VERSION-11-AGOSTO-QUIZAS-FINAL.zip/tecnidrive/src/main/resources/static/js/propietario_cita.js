 function toggleCancelar(idCita) {
            const form = document.getElementById('formulario-' + idCita);
            form.classList.toggle('mostrar');
        }



        // ── Interacción de las estrellas para calificar un taller ─────────────────
// Puramente visual: colorea las estrellas seleccionadas y revela el
// bloque de reseña. El formulario se envía normal al servidor (sin fetch).
document.addEventListener("DOMContentLoaded", () => {

    document.querySelectorAll(".calificacion-estrellas").forEach((contenedor) => {

        const estrellas     = contenedor.querySelectorAll(".star");
        const inputPunt     = contenedor.querySelector(".input-puntuacion");
        const form          = contenedor.closest("form");
        const bloqueResena  = form ? form.querySelector(".bloque-resena") : null;
        const errorMsg      = form ? form.querySelector(".cali-error") : null;

        let puntuacionActual = inputPunt ? parseInt(inputPunt.value) : 0;

        estrellas.forEach((estrella) => {

            estrella.addEventListener("mouseover", () => {
                const valorHover = parseInt(estrella.dataset.value);
                pintarEstrellas(estrellas, valorHover);
            });

            estrella.addEventListener("mouseleave", () => {
                pintarEstrellas(estrellas, puntuacionActual);
            });

            estrella.addEventListener("click", () => {
                puntuacionActual = parseInt(estrella.dataset.value);
                if (inputPunt) inputPunt.value = puntuacionActual;

                pintarEstrellas(estrellas, puntuacionActual);

                if (bloqueResena) bloqueResena.classList.remove("oculto-js");
                if (errorMsg) errorMsg.style.display = "none";
            });
        });

        if (form) {
            form.addEventListener("submit", (e) => {
                if (puntuacionActual < 1) {
                    e.preventDefault();
                    if (errorMsg) {
                        errorMsg.textContent = "Selecciona al menos 1 estrella.";
                        errorMsg.style.display = "block";
                    }
                }
            });
        }
    });

    function pintarEstrellas(estrellas, hasta) {
        estrellas.forEach((e) => {
            const valor = parseInt(e.dataset.value);
            e.classList.toggle("activa", valor <= hasta);
        });
    }
});