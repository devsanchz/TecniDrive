document.getElementById('signForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    // Limpiamos errores previos de intentos anteriores
    document.querySelectorAll('.error-campo').forEach(span => span.textContent = '');
    document.getElementById('errorGeneral').style.display = 'none';

    const datos = {
        primerNombre: document.getElementById('primerNombre').value,
        segundoNombre: document.getElementById('segundoNombre').value,
        primerApellido: document.getElementById('primerApellido').value,
        segundoApellido: document.getElementById('segundoApellido').value,
        telefono: document.getElementById('telefonoReg').value,
        email: document.getElementById('usuarioReg').value,
        password: document.getElementById('passwordReg').value
    };

    try {
        const response = await fetch('/api/registro/datos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datos)
        });

        const data = await response.json();

        if (response.ok) {
            window.location.href = data.redirectUrl;
        } else {
            const errorGeneral = document.getElementById('errorGeneral');
            errorGeneral.textContent = data.mensaje;
            errorGeneral.style.display = 'block';
        }

    } catch (error) {
        const errorGeneral = document.getElementById('errorGeneral');
        errorGeneral.textContent = 'No se pudo conectar con el servidor.';
        errorGeneral.style.display = 'block';
        console.error('Error de red:', error);
    }
});