function mostrarPaso(numero) {
    [1, 2, 3].forEach(function (n) {
        const tarjeta = document.getElementById('paso' + n);
        if (tarjeta) tarjeta.style.display = (n === numero) ? 'flex' : 'none';
    });
}

// Al cargar la página, revisamos ?paso= y ?email= en la URL,
// para saber en qué punto del flujo estamos (mismo rol que
// cumplía la sesión/flashdata de PHP, pero visible en la URL)
document.addEventListener('DOMContentLoaded', function () {
    const parametros = new URLSearchParams(window.location.search);
    const paso = parseInt(parametros.get('paso')) || 1;
    const email = parametros.get('email');

    if (email) {
        document.getElementById('emailPaso2').value = email;
    }

    mostrarPaso(paso);
});

// PASO 1: enviar el correo con el código
document.getElementById('formPaso1').addEventListener('submit', async function (e) {
    e.preventDefault();

    const errorPaso1 = document.getElementById('errorPaso1');
    errorPaso1.style.display = 'none';

    const email = document.getElementById('emailPaso1').value;

    try {
        const response = await fetch('/api/recuperar/enviar-codigo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
        });

        const data = await response.json();

        if (response.ok) {
            window.location.href = data.redirectUrl;
        } else {
            errorPaso1.textContent = data.mensaje;
            errorPaso1.style.display = 'block';
        }

    } catch (error) {
        errorPaso1.textContent = 'No se pudo conectar con el servidor.';
        errorPaso1.style.display = 'block';
    }
});

// PASO 2: verificar el código de 6 dígitos
document.getElementById('formPaso2').addEventListener('submit', async function (e) {
    e.preventDefault();

    const errorPaso2 = document.getElementById('errorPaso2');
    errorPaso2.style.display = 'none';

    const email = document.getElementById('emailPaso2').value;
    const codigo = document.getElementById('codigoInput').value;

    try {
        const response = await fetch('/api/recuperar/verificar-codigo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email, codigo: codigo })
        });

        const data = await response.json();

        if (response.ok) {
            window.location.href = data.redirectUrl;
        } else {
            errorPaso2.textContent = data.mensaje;
            errorPaso2.style.display = 'block';
        }

    } catch (error) {
        errorPaso2.textContent = 'No se pudo conectar con el servidor.';
        errorPaso2.style.display = 'block';
    }
});

// PASO 3: guardar la nueva contraseña
document.getElementById('formPaso3').addEventListener('submit', async function (e) {
    e.preventDefault();

    const errorPaso3 = document.getElementById('errorPaso3');
    errorPaso3.style.display = 'none';

    const password = document.getElementById('passwordInput').value;
    const repassword = document.getElementById('repasswordInput').value;

    if (password !== repassword) {
        errorPaso3.textContent = 'Las contraseñas no coinciden';
        errorPaso3.style.display = 'block';
        return;
    }

    try {
        const response = await fetch('/api/recuperar/actualizar-pass', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password: password, repassword: repassword })
        });

        const data = await response.json();

        if (response.ok) {
            window.location.href = data.redirectUrl;
        } else {
            errorPaso3.textContent = data.mensaje;
            errorPaso3.style.display = 'block';
            if (data.redirectUrl) {
                window.location.href = data.redirectUrl;
            }
        }

    } catch (error) {
        errorPaso3.textContent = 'No se pudo conectar con el servidor.';
        errorPaso3.style.display = 'block';
    }
});