document.getElementById('rolForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const errorRol = document.getElementById('errorRol');
    errorRol.style.display = 'none';

    // Buscamos el radio button seleccionado (que no esté deshabilitado)
    const seleccionado = document.querySelector('input[name="rol"]:checked');

    if (!seleccionado) {
        errorRol.textContent = 'Debes seleccionar un rol para continuar';
        errorRol.style.display = 'block';
        return;
    }

    const datos = {
        rol: parseInt(seleccionado.value)
    };

    try {
        const response = await fetch('/api/registro/finalizar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(datos)
        });

        const data = await response.json();

        if (response.ok) {
            window.location.href = data.redirectUrl;
        } else {
            errorRol.textContent = data.mensaje;
            errorRol.style.display = 'block';

            // Si la sesión expiró, redirige de vuelta al registro
            if (data.redirectUrl) {
                window.location.href = data.redirectUrl;
            }
        }

    } catch (error) {
        errorRol.textContent = 'No se pudo conectar con el servidor.';
        errorRol.style.display = 'block';
        console.error('Error de red:', error);
    }
});

// Funciones del modal, ya existían en tu HTML original con onclick="abrirModal()"
function abrirModal() {
    document.getElementById('modalPlanes').style.display = 'flex';
}

function cerrarModal() {
    document.getElementById('modalPlanes').style.display = 'none';
}