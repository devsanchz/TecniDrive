// Al cargar la página de login, revisamos si venimos de un registro exitoso
document.addEventListener('DOMContentLoaded', function () {
    const parametros = new URLSearchParams(window.location.search);

    if (parametros.get('registro') === 'exitoso') {
        const mensajeExito = document.getElementById('mensajeExito');
        mensajeExito.textContent = '¡Cuenta creada correctamente! Ya puedes iniciar sesión.';
        mensajeExito.style.display = 'block';
    }
});
// Esperamos a que se envíe el formulario de login
document.getElementById('loginForm').addEventListener('submit', async function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorLogin = document.getElementById('errorLogin');

    // Ocultamos el mensaje de error por si quedó de un intento anterior
    errorLogin.style.display = 'none';

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email, password: password })
        });

        const data = await response.json();

        if (response.ok) {
            // El backend nos dice a qué panel redirigir según el rol
            window.location.href = data.redirectUrl;
        } else {
            errorLogin.textContent = data.mensaje;
            errorLogin.style.display = 'block';
        }

    } catch (error) {
        errorLogin.textContent = 'No se pudo conectar con el servidor.';
        errorLogin.style.display = 'block';
        console.error('Error de red:', error);
    }
});