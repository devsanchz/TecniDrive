package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

// DTO para el primer paso del registro (datos personales).
// Mismo patrón que LoginRequestDTO: un record con validaciones básicas
public record RegistroRequestDTO(

        @NotBlank
        String primerNombre,

        String segundoNombre, // opcional, sin @NotBlank

        @NotBlank
        String primerApellido,

        @NotBlank
        String segundoApellido,

        @NotBlank
        String telefono, // String, no Long: así evitamos que fetch/JSON rompa si hay espacios

        @NotBlank
        @Email
        String email,

        @NotBlank
        String password

) {
}