package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.CodigoRecuperacionDTO;
import tecnidrive.tecnidrive.dto.EmailRecuperacionDTO;
import tecnidrive.tecnidrive.dto.NuevaPasswordDTO;
import tecnidrive.tecnidrive.service.RecuperarService;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/recuperar")
public class RecuperarController {

    @Autowired
    private RecuperarService recuperarService;

    @PostMapping("/enviar-codigo")
    public ResponseEntity<Map<String, Object>> enviarCodigo(
            @Valid @RequestBody EmailRecuperacionDTO datos) {

        Map<String, Object> respuesta = new HashMap<>();

        // Se llama siempre, exista o no el correo — el mensaje de
        // respuesta es el mismo en ambos casos, para no revelar
        // si un correo está registrado (misma lógica que tu CI4)
        recuperarService.enviarCodigo(datos.email());

        respuesta.put("mensaje", "Si el correo está registrado, recibirás el código en breve.");
        respuesta.put("redirectUrl", "/recuperar?paso=2&email=" + datos.email());

        return ResponseEntity.ok(respuesta);
    }

    @PostMapping("/verificar-codigo")
    public ResponseEntity<Map<String, Object>> verificarCodigo(
            @Valid @RequestBody CodigoRecuperacionDTO datos,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        try {
            Integer idPersona = recuperarService.verificarCodigo(datos.email(), datos.codigo());

            // Guardamos el id en sesión, igual que hacía CI4 con
            // session()->set('recuperacion_id', ...), para usarlo
            // en el paso 3 sin volver a pedir credenciales
            session.setAttribute("recuperacionId", idPersona);

            respuesta.put("mensaje", "Código verificado correctamente");
            respuesta.put("redirectUrl", "/recuperar?paso=3");
            return ResponseEntity.ok(respuesta);

        } catch (RuntimeException e) {
            respuesta.put("mensaje", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }
    }

    @PostMapping("/actualizar-pass")
    public ResponseEntity<Map<String, Object>> actualizarPassword(
            @Valid @RequestBody NuevaPasswordDTO datos,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Integer idPersona = (Integer) session.getAttribute("recuperacionId");

        if (idPersona == null) {
            respuesta.put("mensaje", "Sesión expirada. Inicia el proceso de nuevo.");
            respuesta.put("redirectUrl", "/recuperar");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        if (!datos.password().equals(datos.repassword())) {
            respuesta.put("mensaje", "Las contraseñas no coinciden");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        recuperarService.actualizarPassword(idPersona, datos.password());

        session.removeAttribute("recuperacionId");

        respuesta.put("mensaje", "Contraseña actualizada correctamente");
        respuesta.put("redirectUrl", "/login?registro=exitoso");

        return ResponseEntity.ok(respuesta);
    }
}