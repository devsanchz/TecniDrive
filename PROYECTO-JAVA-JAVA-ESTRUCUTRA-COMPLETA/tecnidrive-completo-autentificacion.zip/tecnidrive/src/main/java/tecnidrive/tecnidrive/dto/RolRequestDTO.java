package tecnidrive.tecnidrive.dto;

// DTO para el segundo paso: solo el id del rol elegido
public record RolRequestDTO(
        Integer rol
) {
}
