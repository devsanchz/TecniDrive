package tecnidrive.tecnidrive.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import tecnidrive.tecnidrive.model.Persona;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class RecuperarService {

    @Autowired
    private PersonaService personaService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // JavaMailSender: la herramienta de Spring que realmente conecta
    // con el servidor SMTP y manda el correo, equivalente a
    // Config\Services::email() de tu CI4
    @Autowired
    private JavaMailSender mailSender;

    // PASO 1: genera el código, lo guarda, y envía el correo.
    // Devuelve true siempre que el proceso corra sin excepción, sin
    // revelar si el correo existe o no (misma lógica que tu CI4)
    public void enviarCodigo(String email) {

        Optional<Persona> personaOpt = personaService.buscarPorEmail(email);

        // Si no existe, simplemente no hacemos nada — el Controller
        // igual responde con el mismo mensaje genérico, para no revelar
        // si ese correo está registrado (misma idea que tenías en CI4)
        if (personaOpt.isEmpty()) {
            return;
        }

        Persona persona = personaOpt.get();

        // Generamos un código de 6 dígitos, igual que random_int(100000, 999999) en PHP.
        // SecureRandom es la clase recomendada en Java para generar números
        // aleatorios cuando importa la seguridad (a diferencia de Math.random())
        SecureRandom random = new SecureRandom();
        String codigo = String.valueOf(100000 + random.nextInt(900000));

        LocalDateTime expiracion = LocalDateTime.now().plusMinutes(5);

        personaService.guardarCodigoRecuperacion(persona.getIdPersona(), codigo, expiracion);

        enviarCorreo(persona.getEmail(), persona.getPrimerNombre(), codigo);
    }

    private void enviarCorreo(String destinatario, String nombre, String codigo) {
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setTo(destinatario);
        mensaje.setSubject("Código de recuperación — TECNIDRIVE");
        mensaje.setText(
            "Hola " + nombre + ",\n\n" +
            "Tu código para restablecer tu contraseña es: " + codigo + "\n\n" +
            "Válido por 5 minutos.\n\n" +
            "Si no solicitaste este cambio, ignora este mensaje.\n\n" +
            "— Equipo TECNIDRIVE"
        );
        mailSender.send(mensaje);
    }

    // PASO 2: verifica el código, y si es válido, limpia el código
    // de la BD y devuelve el id de la persona para usarlo en el paso 3
    public Integer verificarCodigo(String email, String codigoIngresado) {

        Persona persona = personaService.buscarPorEmail(email)
                .orElseThrow(() -> new RuntimeException("Código incorrecto o expirado"));

        if (persona.getFechaExpiracion() == null
                || persona.getFechaExpiracion().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("El código ha expirado. Solicita uno nuevo.");
        }

        if (!codigoIngresado.equals(persona.getCodigoRecuperacion())) {
            throw new RuntimeException("Código incorrecto. Verifica e intenta de nuevo.");
        }

        personaService.limpiarCodigoRecuperacion(persona.getIdPersona());

        return persona.getIdPersona();
    }

    // PASO 3: guarda la nueva contraseña, ya encriptada con BCrypt
    public void actualizarPassword(Integer idPersona, String nuevaPassword) {
        String hashNuevo = passwordEncoder.encode(nuevaPassword);
        personaService.actualizarPassword(idPersona, hashNuevo);
    }
}
