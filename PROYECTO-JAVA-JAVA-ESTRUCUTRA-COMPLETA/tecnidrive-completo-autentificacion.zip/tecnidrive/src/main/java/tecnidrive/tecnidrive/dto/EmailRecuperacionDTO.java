package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record EmailRecuperacionDTO(
        @NotBlank
        @Email
        String email
) {
}