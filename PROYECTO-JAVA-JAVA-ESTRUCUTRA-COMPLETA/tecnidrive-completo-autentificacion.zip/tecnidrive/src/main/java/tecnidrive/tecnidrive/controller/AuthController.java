package tecnidrive.tecnidrive.controller;

import tecnidrive.tecnidrive.dto.LoginRequestDTO;
import tecnidrive.tecnidrive.model.Persona;
import tecnidrive.tecnidrive.model.Rol;
import tecnidrive.tecnidrive.service.PersonaService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private PersonaService personaService;

    // AGREGADO: reactivamos PasswordEncoder para comparar contraseñas
    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @Valid @RequestBody LoginRequestDTO datosLogin,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Optional<Persona> personaOpt = personaService.buscarPorEmail(datosLogin.email());

        if (personaOpt.isEmpty()) {
            respuesta.put("mensaje", "Correo o contraseña incorrectos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        Persona persona = personaOpt.get();

        // CORRECCIÓN: ya no comparamos con .equals() (texto plano).
        // matches() compara el texto que escribió el usuario contra
        // el hash guardado, sin necesidad de desencriptar nada
        boolean passwordCorrecto = passwordEncoder.matches(
                datosLogin.password(),
                persona.getPasswordHash()
        );

        if (!passwordCorrecto) {
            respuesta.put("mensaje", "Correo o contraseña incorrectos");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        Rol rolPersona = persona.getRoles().iterator().next();

        session.setAttribute("idPersona", persona.getIdPersona());
        session.setAttribute("email", persona.getEmail());
        session.setAttribute("rol", rolPersona.getTextoRol());

        String redirectUrl;
        switch (rolPersona.getTextoRol()) {
            case "Administrador":
                redirectUrl = "/panel-admin";
                break;
            case "Propietario":
                redirectUrl = "/panel-propietario";
                break;
            case "Mecanico":
                redirectUrl = "/panel-mecanico";
                break;
            default:
                redirectUrl = "/login";
        }

        respuesta.put("mensaje", "Login exitoso");
        respuesta.put("rol", rolPersona.getTextoRol());
        respuesta.put("nombre", persona.getPrimerNombre());
        respuesta.put("redirectUrl", redirectUrl);

        return ResponseEntity.ok(respuesta);
    }

    // ... verSesion() y logout() quedan exactamente igual, sin cambios
    @GetMapping("/sesion")
    public ResponseEntity<Map<String, Object>> verSesion(HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Object idPersona = session.getAttribute("idPersona");

        if (idPersona == null) {
            respuesta.put("mensaje", "No hay una sesión activa");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(respuesta);
        }

        respuesta.put("idPersona", idPersona);
        respuesta.put("email", session.getAttribute("email"));
        respuesta.put("rol", session.getAttribute("rol"));

        return ResponseEntity.ok(respuesta);
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        session.invalidate();

        respuesta.put("mensaje", "Sesión cerrada correctamente");
        return ResponseEntity.ok(respuesta);
    }
}