package tecnidrive.tecnidrive.dto;

import jakarta.validation.constraints.NotBlank;

public record CodigoRecuperacionDTO(
        @NotBlank
        String email,

        @NotBlank
        String codigo
) {
}