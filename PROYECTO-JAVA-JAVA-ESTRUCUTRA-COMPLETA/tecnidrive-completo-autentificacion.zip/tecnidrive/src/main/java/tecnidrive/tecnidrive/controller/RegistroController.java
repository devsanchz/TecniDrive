package tecnidrive.tecnidrive.controller;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import tecnidrive.tecnidrive.dto.RegistroRequestDTO;
import tecnidrive.tecnidrive.dto.RolRequestDTO;
import tecnidrive.tecnidrive.service.RegistroService;

import java.util.HashMap;
import java.util.Map;

// CORRECCIÓN: cambiado de @Controller a @RestController, y de
// @RequestParam/redirect a @RequestBody/JSON, para seguir el mismo
// patrón que AuthController (login usa fetch + JSON, no un <form>
// tradicional con recarga de página)
@RestController
@RequestMapping("/api/registro")
public class RegistroController {

    @Autowired
    private RegistroService registroService;

    @PostMapping("/datos")
    public ResponseEntity<Map<String, Object>> registrarDatos(
            @Valid @RequestBody RegistroRequestDTO datos,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        // CORRECCIÓN: el teléfono ahora llega como String desde el DTO;
        // lo limpiamos de espacios y lo convertimos a Long aquí mismo,
        // donde podemos devolver un error claro si el formato es inválido
        Long telefono;
        try {
            telefono = Long.parseLong(datos.telefono().replaceAll("\\s+", ""));
        } catch (NumberFormatException e) {
            respuesta.put("mensaje", "El teléfono debe contener solo números");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        // Guardamos los datos en sesión, igual que hacía el Controller original,
        // mientras el usuario elige su rol en el siguiente paso
        session.setAttribute("primerNombre", datos.primerNombre());
        session.setAttribute("segundoNombre", datos.segundoNombre());
        session.setAttribute("primerApellido", datos.primerApellido());
        session.setAttribute("segundoApellido", datos.segundoApellido());
        session.setAttribute("telefono", telefono);
        session.setAttribute("email", datos.email());
        session.setAttribute("password", datos.password());

        respuesta.put("mensaje", "Datos guardados correctamente");
        respuesta.put("redirectUrl", "/rol");

        return ResponseEntity.ok(respuesta);
    }

    @PostMapping("/finalizar")
    public ResponseEntity<Map<String, Object>> finalizarRegistro(
            @RequestBody RolRequestDTO datosRol,
            HttpSession session) {

        Map<String, Object> respuesta = new HashMap<>();

        Integer idRol = datosRol.rol();

        if (idRol == null) {
            respuesta.put("mensaje", "Debes seleccionar un rol");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        String primerNombre = (String) session.getAttribute("primerNombre");
        String segundoNombre = (String) session.getAttribute("segundoNombre");
        String primerApellido = (String) session.getAttribute("primerApellido");
        String segundoApellido = (String) session.getAttribute("segundoApellido");
        Long telefono = (Long) session.getAttribute("telefono");
        String email = (String) session.getAttribute("email");
        String password = (String) session.getAttribute("password");

        if (primerNombre == null || email == null || password == null) {
            respuesta.put("mensaje", "La sesión expiró, vuelve a completar el formulario");
            respuesta.put("redirectUrl", "/registro");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        if (idRol == 2) {
            registroService.registrarPropietario(
                    primerNombre, segundoNombre, primerApellido, segundoApellido,
                    telefono, email, password
            );
        } else if (idRol == 3) {
            registroService.registrarMecanico(
                    primerNombre, segundoNombre, primerApellido, segundoApellido,
                    telefono, email, password
            );
        } else {
            respuesta.put("mensaje", "Rol no válido");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(respuesta);
        }

        session.invalidate();

respuesta.put("mensaje", "Registro completado correctamente");
// CORRECCIÓN: agregamos ?registro=exitoso a la URL, para que login.js
// pueda detectar que viene de un registro recién hecho y mostrar
// un mensaje de bienvenida, sin necesidad de guardar nada en el servidor
respuesta.put("redirectUrl", "/login?registro=exitoso");

        return ResponseEntity.ok(respuesta);
    }
}